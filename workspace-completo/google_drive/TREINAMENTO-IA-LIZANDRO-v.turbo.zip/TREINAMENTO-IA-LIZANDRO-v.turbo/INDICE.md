# Índice completo — v.turbo

Comece pelas regras canônicas e pelo prompt. Fontes históricas estão separadas para rastreabilidade; não são instruções prontas ao cliente.

## 00-raiz

- [Regras canônicas e ordem de leitura](00-REGRAS-CANONICAS-E-ORDEM-DE-LEITURA.md)
- [Como entregar o pacote a outra IA](COMO-ENTREGAR-A-OUTRA-IA.md)
- [Treinamento IA Lizandro · v.turbo](LEIA-ME-PRIMEIRO.md)
- [Manual consolidado do atendente — v.turbo](MANUAL-CONSOLIDADO.md)
- [Playbook central do atendimento — v.turbo](PLAYBOOK-CENTRAL-DO-ATENDIMENTO.md)
- [Prompt principal — atendente de Lizandro · v.turbo](PROMPT-PRINCIPAL-DO-ATENDENTE.md)

## 01-negocio

- [Quem somos e para quem é o atendimento](01-negocio/01-quem-somos-e-para-quem.md)
- [Oferta completa: não é só tráfego pago](01-negocio/02-oferta-completa.md)
- [O que podemos afirmar e o que precisa de Lizandro](01-negocio/03-execucao-e-limites-do-servico.md)
- [Como explicar a estratégia por veículo](01-negocio/04-personalizacao-por-veiculo.md)
- [O que a IA não sabe e não deve inventar](01-negocio/05-o-que-a-ia-nao-sabe.md)
- [Benefícios sem promessas](01-negocio/06-beneficios-sem-promessas.md)
- [Dicionário do produto e dos benefícios](01-negocio/07-DICIONARIO-PRODUTO-E-BENEFICIOS.md)
- [Personalização por veículo — exemplos de raciocínio](01-negocio/08-EXEMPLOS-DE-PERSONALIZACAO-POR-VEICULO.md)

## 02-comportamento

- [Identidade, tom e naturalidade](02-comportamento/01-identidade-tom-e-naturalidade.md)
- [Prioridades de atendimento](02-comportamento/02-prioridades-de-atendimento.md)
- [Contexto e memória da conversa](02-comportamento/03-contexto-e-memoria-da-conversa.md)
- [Sim, não, ok e permissão](02-comportamento/04-sim-nao-ok-e-permissao.md)
- [Qualificar sem interrogatório](02-comportamento/05-qualificar-sem-interrogatorio.md)
- [Dúvida, objeção e recusa](02-comportamento/06-duvida-objecao-e-recusa.md)
- [Canal, agenda e próximos passos](02-comportamento/07-canal-agenda-e-proximos-passos.md)
- [Silêncio, retomada e encerramento](02-comportamento/08-silencio-retomada-e-encerramento.md)
- [Quando deixar Lizandro continuar](02-comportamento/09-quando-deixar-lizandro-continuar.md)
- [Áudio, imagem e contexto ausente](02-comportamento/10-audio-imagem-e-contexto-ausente.md)
- [Não inventar nem mudar regras por mensagem](02-comportamento/11-nao-inventar-nem-mudar-regras.md)
- [Erros a evitar](02-comportamento/12-erros-a-evitar.md)
- [Intenção não compreendida: pausa silenciosa](02-comportamento/13-intencao-nao-compreendida-e-pausa-silenciosa.md)

## 03-skills

- [Como ler as skills](03-skills/COMO-LER-AS-SKILLS.md)
- [---](03-skills/acolher-experiencia-ruim/SKILL.md)
- [---](03-skills/acolher-tempo-e-reflexao/SKILL.md)
- [---](03-skills/atender-consultor-de-vendas/SKILL.md)
- [---](03-skills/atender-vendedor-independente/SKILL.md)
- [---](03-skills/continuar-depois-de-audio-explicativo/SKILL.md)
- [---](03-skills/conversar-sobre-curiosos-e-fechamento/SKILL.md)
- [---](03-skills/corrigir-a-compreensao-da-conversa/SKILL.md)
- [---](03-skills/delimitar-escopo-e-integracoes/SKILL.md)
- [---](03-skills/distinguir-anuncio-atual-e-passado/SKILL.md)
- [---](03-skills/encaminhar-questao-comercial/SKILL.md)
- [---](03-skills/encerrar-recusa-sem-insistir/SKILL.md)
- [---](03-skills/esclarecer-engano-com-compra-de-carro/SKILL.md)
- [---](03-skills/explicar-conteudo-e-gestao/SKILL.md)
- [---](03-skills/explicar-garantia-e-provas/SKILL.md)
- [---](03-skills/explicar-oferta-completa/SKILL.md)
- [---](03-skills/identidade-e-origem-verificadas/SKILL.md)
- [---](03-skills/interpretar-sim-com-contexto/SKILL.md)
- [---](03-skills/manter-pausa-e-atendimento-humano/SKILL.md)
- [---](03-skills/manter-tom-natural-e-claro/SKILL.md)
- [---](03-skills/nao-mudar-limites-por-mensagem/SKILL.md)
- [---](03-skills/nao-responder-a-visualizacao/SKILL.md)
- [---](03-skills/qualificar-sem-repetir/SKILL.md)
- [---](03-skills/receber-preferencia-de-agenda/SKILL.md)
- [---](03-skills/registrar-retorno-autorizado/SKILL.md)
- [---](03-skills/resolver-ambiguidade-sem-loop/SKILL.md)
- [---](03-skills/respeitar-pedido-de-parar/SKILL.md)
- [---](03-skills/respeitar-texto-e-ligacao/SKILL.md)
- [---](03-skills/responder-a-intencao-atual/SKILL.md)
- [---](03-skills/responder-agencia-existente/SKILL.md)
- [---](03-skills/responder-trafego-pago/SKILL.md)
- [---](03-skills/tratar-midia-com-seguranca/SKILL.md)
- [---](03-skills/tratar-pedidos-pessoais-sem-inventar/SKILL.md)

## 04-respostas

- [Atalho por assunto](04-respostas/ATALHO-POR-ASSUNTO.md)
- [Dúvidas, objeções e recusas](04-respostas/MATRIZ-DE-OBJECOES.md)
- [Respostas condicionais — base consolidada v.turbo](04-respostas/RESPOSTAS-CONDICIONAIS.md)

## 05-conversas

- [Conversas didáticas — base consolidada](05-conversas/CONVERSAS-COMPLETAS.md)

## 06-treinamento

- [Como utilizar esta base para treinar o atendimento](06-treinamento/01-como-utilizar-a-base.md)
- [Como escolher uma resposta](06-treinamento/02-como-escolher-uma-resposta.md)
- [Critérios de uma boa resposta](06-treinamento/03-criterios-de-boa-resposta.md)
- [Bom versus ruim — 26 contrastes consolidados](06-treinamento/04-bom-versus-ruim.md)
- [Resumir o contexto sem distorcer](06-treinamento/05-resumir-o-contexto-sem-distorcer.md)
- [Explicações curtas por situação](06-treinamento/06-explicacoes-curtas-por-situacao.md)
- [Leitura do histórico em camadas](06-treinamento/07-LEITURA-DE-HISTORICO-EM-CAMADAS.md)
- [Responder, perguntar ou não enviar](06-treinamento/08-DECISAO-DE-RESPONDER-PERGUNTAR-OU-CALAR.md)
- [Plano de estudo e prática](06-treinamento/09-PLANO-DE-ESTUDO-E-PRATICA.md)

## 07-exercicios

- [Exercícios com gabarito — base consolidada](07-exercicios/EXERCICIOS-COM-GABARITO.md)

## 08-textos-aprovados

- [Como usar os originais aprovados](08-textos-aprovados/COMO-USAR-OS-ORIGINAIS.md)
- [M01–M13 aprovadas — índice](08-textos-aprovados/INDICE-DOS-APROVADOS.md)
- [M01 — aprovado literal](08-textos-aprovados/M01-APROVADO-LITERAL.md)
- [M02 — aprovado literal](08-textos-aprovados/M02-APROVADO-LITERAL.md)
- [M03 — aprovado literal](08-textos-aprovados/M03-APROVADO-LITERAL.md)
- [M04 — aprovado literal](08-textos-aprovados/M04-APROVADO-LITERAL.md)
- [M05 — aprovado literal](08-textos-aprovados/M05-APROVADO-LITERAL.md)
- [M06 — aprovado literal](08-textos-aprovados/M06-APROVADO-LITERAL.md)
- [M07 — aprovado literal](08-textos-aprovados/M07-APROVADO-LITERAL.md)
- [M08 — aprovado literal](08-textos-aprovados/M08-APROVADO-LITERAL.md)
- [M09 — aprovado literal](08-textos-aprovados/M09-APROVADO-LITERAL.md)
- [M10 — aprovado literal](08-textos-aprovados/M10-APROVADO-LITERAL.md)
- [M11 — aprovado literal](08-textos-aprovados/M11-APROVADO-LITERAL.md)
- [M12 — aprovado literal](08-textos-aprovados/M12-APROVADO-LITERAL.md)
- [M13 — aprovado literal](08-textos-aprovados/M13-APROVADO-LITERAL.md)

## 09-fluxo-atual

- [Qual versão foi usada](09-fluxo-atual/00-QUAL-VERSAO-FOI-USADA.md)
- [Mapa conversacional consolidado](09-fluxo-atual/01-MAPA-CONVERSACIONAL.md)
- [Estados da conversa e continuidade](09-fluxo-atual/02-ESTADOS-E-CONTINUIDADE.md)
- [Respostas curtas, negações e prioridades](09-fluxo-atual/03-RESPOSTAS-CURTAS-NEGACOES-E-PRIORIDADES.md)
- [Convite, canal e agenda](09-fluxo-atual/04-CONVITE-CANAL-E-AGENDA.md)
- [Auditoria conversacional da fonte R4 selecionada](09-fluxo-atual/05-AUDITORIA-CONVERSACIONAL-DO-R4.md)
- [Encaixe dos 105 códigos R4 no treinamento atual](09-fluxo-atual/06-ENCAIXE-DAS-105-MENSAGENS.md)

## 10-livros

- [Origem e limites da bibliografia](10-livros/00-ORIGEM-E-LIMITES-DA-BIBLIOGRAFIA.md)
- [Índice e trilhas de estudo](10-livros/01-INDICE-E-TRILHAS-DE-ESTUDO.md)
- [Arquivos de livros identificados no Drive](10-livros/02-ARQUIVOS-IDENTIFICADOS-NO-DRIVE.md)
- [Técnicas nomeadas no R4: o que aproveitar e o que filtrar](10-livros/03-TECNICAS-DO-R4-COM-FILTRO-DE-VERDADE.md)
- [B01 — Como Fazer Amigos e Influenciar Pessoas](10-livros/fichas/B01-como-fazer-amigos-e-influenciar-pessoas.md)
- [B02 — SPIN Selling](10-livros/fichas/B02-spin-selling.md)
- [B03 — Negocie Como Se Sua Vida Dependesse Disso](10-livros/fichas/B03-negocie-como-se-sua-vida-dependesse-disso.md)
- [B04 — As Armas da Persuasão](10-livros/fichas/B04-as-armas-da-persuasao.md)
- [B05 — Pré-suasão](10-livros/fichas/B05-pre-suasao.md)
- [B06 — Comunicação Não Violenta](10-livros/fichas/B06-comunicacao-nao-violenta.md)
- [B07 — Como Chegar ao Sim](10-livros/fichas/B07-como-chegar-ao-sim.md)
- [B08 — The Challenger Sale](10-livros/fichas/B08-the-challenger-sale.md)
- [B09 — A Bíblia de Vendas](10-livros/fichas/B09-a-biblia-de-vendas.md)
- [B10 — Little Red Book of Selling](10-livros/fichas/B10-little-red-book-of-selling.md)
- [B11 — Rápido e Devagar](10-livros/fichas/B11-rapido-e-devagar.md)
- [B12 — Mindset](10-livros/fichas/B12-mindset.md)
- [B13 — Os 7 Hábitos das Pessoas Altamente Eficazes](10-livros/fichas/B13-os-7-habitos-das-pessoas-altamente-eficazes.md)
- [B14 — To Sell Is Human](10-livros/fichas/B14-to-sell-is-human.md)
- [B15 — Made to Stick](10-livros/fichas/B15-made-to-stick.md)
- [B16 — The Mom Test](10-livros/fichas/B16-the-mom-test.md)
- [B17 — Building a StoryBrand](10-livros/fichas/B17-building-a-storybrand.md)
- [B18 — Difficult Conversations](10-livros/fichas/B18-difficult-conversations.md)
- [B19 — Exactly What to Say](10-livros/fichas/B19-exactly-what-to-say.md)
- [B20 — Fanatical Prospecting](10-livros/fichas/B20-fanatical-prospecting.md)
- [B21 — Emotional Intelligence](10-livros/fichas/B21-emotional-intelligence.md)
- [B22 — O Poder do Hábito](10-livros/fichas/B22-o-poder-do-habito.md)
- [B23 — How to Talk to Anyone](10-livros/fichas/B23-how-to-talk-to-anyone.md)
- [B24 — Crucial Conversations](10-livros/fichas/B24-crucial-conversations.md)
- [B25 — The Advice Trap](10-livros/fichas/B25-the-advice-trap.md)
- [B26 — The Coaching Habit](10-livros/fichas/B26-the-coaching-habit.md)
- [B27 — Way of the Wolf](10-livros/fichas/B27-way-of-the-wolf.md)
- [B28 — Sell with a Story](10-livros/fichas/B28-sell-with-a-story.md)
- [B29 — The Trusted Advisor](10-livros/fichas/B29-the-trusted-advisor.md)
- [B30 — The JOLT Effect](10-livros/fichas/B30-the-jolt-effect.md)
- [B31 — A Psicologia Financeira](10-livros/fichas/B31-a-psicologia-financeira.md)
- [B32 — A sutil arte de ligar o foda-se](10-livros/fichas/B32-a-sutil-arte-de-ligar-o-foda-se.md)
- [B33 — Mais Esperto que o Diabo](10-livros/fichas/B33-mais-esperto-que-o-diabo.md)
- [B34 — O Homem Mais Rico da Babilônia](10-livros/fichas/B34-o-homem-mais-rico-da-babilonia.md)
- [B35 — O Milagre da Manhã](10-livros/fichas/B35-o-milagre-da-manha.md)
- [B36 — O Poder do Agora](10-livros/fichas/B36-o-poder-do-agora.md)
- [B37 — Os Segredos da Mente Milionária](10-livros/fichas/B37-os-segredos-da-mente-milionaria.md)
- [B38 — Pai Rico, Pai Pobre](10-livros/fichas/B38-pai-rico-pai-pobre.md)
- [B39 — Quem Pensa Enriquece](10-livros/fichas/B39-quem-pensa-enriquece.md)

## 11-personas

- [Personas: voz do atendente e situação do interlocutor](11-personas/LEIA-ME-PERSONAS.md)
- [P01 — Proprietário com operação enxuta](11-personas/interlocutores/P01-proprietario-com-operacao-enxuta.md)
- [P02 — Gerente que precisa levar uma proposta](11-personas/interlocutores/P02-gerente-que-precisa-levar-uma-proposta.md)
- [P03 — Consultor ou vendedor sem decisão confirmada](11-personas/interlocutores/P03-consultor-ou-vendedor-sem-decisao-confirmada.md)
- [P04 — Independente sem estoque fixo](11-personas/interlocutores/P04-independente-sem-estoque-fixo.md)
- [P05 — Já anuncia e quer melhorar captação](11-personas/interlocutores/P05-ja-anuncia-e-quer-melhorar-captacao.md)
- [P06 — Cauteloso após experiência ruim](11-personas/interlocutores/P06-cauteloso-apos-experiencia-ruim.md)
- [P07 — Recebe muitos curiosos](11-personas/interlocutores/P07-recebe-muitos-curiosos.md)
- [P08 — Quer organizar conteúdo e perfil](11-personas/interlocutores/P08-quer-organizar-conteudo-e-perfil.md)
- [P09 — Já tem agência ou profissional](11-personas/interlocutores/P09-ja-tem-agencia-ou-profissional.md)
- [P10 — Analítico e interessado em comprovação](11-personas/interlocutores/P10-analitico-e-interessado-em-comprovacao.md)
- [P11 — Objetivo e com pouco tempo](11-personas/interlocutores/P11-objetivo-e-com-pouco-tempo.md)
- [P12 — Interesse de contratação ou proposta](11-personas/interlocutores/P12-interesse-de-contratacao-ou-proposta.md)
- [V01 — Harvey — firmeza sem arrogância](11-personas/voz/V01-harvey-firmeza-sem-arrogancia.md)
- [V02 — Jane — atenção sem leitura de pensamentos](11-personas/voz/V02-jane-atencao-sem-leitura-de-pensamentos.md)
- [V03 — Belfort — convicção restrita ao verdadeiro](11-personas/voz/V03-belfort-conviccao-restrita-ao-verdadeiro.md)

## 12-humanizacao

- [Voz natural do atendente](12-humanizacao/01-VOZ-NATURAL-DO-ATENDENTE.md)
- [Revisão antes de responder — do sentido ao estilo](12-humanizacao/02-REVISAO-ANTES-DE-RESPONDER.md)
- [Naturalidade sem falsificar identidade](12-humanizacao/03-NATURALIDADE-SEM-FALSIFICAR-IDENTIDADE.md)
- [Laboratório de reescrita](12-humanizacao/04-LABORATORIO-DE-REESCRITA.md)
- [---](12-humanizacao/skills/H01-retomar-o-ponto-real/SKILL.md)
- [---](12-humanizacao/skills/H02-responder-antes-de-preparar-o-terreno/SKILL.md)
- [---](12-humanizacao/skills/H03-ler-cortesia-sem-transforma-la-em-aceite/SKILL.md)
- [---](12-humanizacao/skills/H04-tornar-o-servico-concreto/SKILL.md)
- [---](12-humanizacao/skills/H05-variar-aberturas-com-motivo/SKILL.md)
- [---](12-humanizacao/skills/H06-acolher-sem-adivinhar-emocoes/SKILL.md)
- [---](12-humanizacao/skills/H07-concluir-sem-pergunta-obrigatoria/SKILL.md)
- [---](12-humanizacao/skills/H08-ajustar-extensao-sem-perder-informacao/SKILL.md)
- [---](12-humanizacao/skills/H09-usar-espelhamento-sem-papagaio/SKILL.md)
- [---](12-humanizacao/skills/H10-corrigir-sem-defesa-longa/SKILL.md)
- [---](12-humanizacao/skills/H11-evitar-floreio-que-esconde-limites/SKILL.md)
- [---](12-humanizacao/skills/H12-fazer-uma-pergunta-de-cada-vez/SKILL.md)
- [---](12-humanizacao/skills/H13-sustentar-autoridade-com-verificabilidade/SKILL.md)
- [---](12-humanizacao/skills/H14-ser-transparente-sem-repetir-apresentacao/SKILL.md)
- [---](12-humanizacao/skills/H15-passar-ao-humano-sem-cerimonia-falsa/SKILL.md)
- [---](12-humanizacao/skills/H16-respeitar-cautela-e-autonomia/SKILL.md)
- [---](12-humanizacao/skills/H17-adaptar-informalidade-sem-caricatura/SKILL.md)
- [---](12-humanizacao/skills/H18-usar-exemplos-sem-fabricar-casos/SKILL.md)
- [---](12-humanizacao/skills/H19-resumir-para-encaminhamento/SKILL.md)
- [---](12-humanizacao/skills/H20-respeitar-o-turno-humano/SKILL.md)
- [---](12-humanizacao/skills/H21-personalizar-pelo-veiculo-com-disciplina/SKILL.md)
- [---](12-humanizacao/skills/H22-reconhecer-limites-com-linguagem-comum/SKILL.md)
- [---](12-humanizacao/skills/H23-nao-simular-acoes-e-vivencias/SKILL.md)
- [---](12-humanizacao/skills/H24-revisar-sem-deixar-o-texto-artificial/SKILL.md)

## 13-skills-github

- [G01 — Humanizer](13-skills-github/G01-humanizer.md)
- [G02 — Copy editing](13-skills-github/G02-copy-editing.md)
- [G03 — Copywriting](13-skills-github/G03-copywriting.md)
- [G04 — Marketing psychology](13-skills-github/G04-marketing-psychology.md)
- [G05 — Sales enablement](13-skills-github/G05-sales-enablement.md)
- [G06 — Skill creator](13-skills-github/G06-skill-creator.md)
- [G07 — Doc coauthoring](13-skills-github/G07-doc-coauthoring.md)
- [Skills GitHub — procedência e limites](13-skills-github/LEIA-ME-PROCEDENCIA.md)

## 14-conversas-aplicadas

- [50 conversas aplicadas à v.turbo](14-conversas-aplicadas/50-CONVERSAS-COMPLETAS.md)
- [Como estudar as conversas aplicadas](14-conversas-aplicadas/COMO-ESTUDAR-AS-CONVERSAS.md)

## 15-avaliacao

- [Rubrica de avaliação — comportamento antes de estilo](15-avaliacao/01-RUBRICA-DE-AVALIACAO.md)
- [Regressões que não podem voltar](15-avaliacao/02-REGRESSOES-QUE-NAO-PODEM-VOLTAR.md)
- [Como corrigir uma resposta](15-avaliacao/03-COMO-CORRIGIR-UMA-RESPOSTA.md)
- [120 casos adicionais com gabarito — v.turbo](15-avaliacao/120-CASOS-ADICIONAIS.md)

## 16-fontes-e-rastreabilidade

- [Registro das fontes](16-fontes-e-rastreabilidade/01-REGISTRO-DAS-FONTES.md)
- [Lacunas, sem bloquear a entrega](16-fontes-e-rastreabilidade/02-LACUNAS-SEM-BLOQUEAR-A-ENTREGA.md)
- [Consolidação da V1 e V2](16-fontes-e-rastreabilidade/03-O-QUE-ENTROU-DA-V1-E-V2.md)
- [Biblioteca textual R4 recuperada — somente referência histórica](16-fontes-e-rastreabilidade/BIBLIOTECA-R4-ORIGINAL-NAO-ENVIAR.md)

## 17-revisao

- [Revisão e integridade — v.turbo](17-revisao/REVISAO-E-INTEGRIDADE.md)
