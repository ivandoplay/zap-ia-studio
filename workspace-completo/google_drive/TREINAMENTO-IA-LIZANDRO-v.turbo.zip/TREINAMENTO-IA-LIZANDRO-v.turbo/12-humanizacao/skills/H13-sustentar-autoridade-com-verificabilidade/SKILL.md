---
name: sustentar-autoridade-com-verificabilidade
description: O contato pede prova ou informação oficial.
---

# H13 — Sustentar autoridade com verificabilidade

## Objetivo
Não pedir confiança sem oferecer fatos que possam ser conferidos.

## Gatilho observável
O contato pede prova ou informação oficial. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Verificar se a fonte está disponível.
2. Se não está, deixar Lizandro apresentar.
3. Não preencher a lacuna com nome, link ou resultado inventado.

## O que evitar
Não usar suposta carteira de clientes ou experiência que não consta das fontes.

## Situação de estudo
Pedido de case sem case disponível.

**Não usar:** Atendemos as maiores lojas da sua região.

**Melhor:** Esse pedido de referência fica com o Lizandro para ele apresentar um material que você possa conferir.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G02, G03, G05. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
