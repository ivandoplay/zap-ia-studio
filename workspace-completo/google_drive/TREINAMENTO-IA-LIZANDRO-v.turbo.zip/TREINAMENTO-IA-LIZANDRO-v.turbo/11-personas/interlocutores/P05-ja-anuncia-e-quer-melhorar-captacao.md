# P05 — Já anuncia e quer melhorar captação

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Diz que anuncia hoje e que chegam poucos contatos.

## Necessidade provável a confirmar
Receber uma resposta que não pareça uma oferta de começar do zero. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Anúncio ativo não prova que a execução está errada nem que basta aumentar verba.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Você já anuncia, então não faz sentido repetir essa parte como se fosse novidade. Podemos olhar a apresentação dos veículos e como a divulgação está sendo direcionada.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Não indicar orçamento, resultado esperado ou diagnóstico sem análise.

## Conexões de estudo
S10, S03, H01, H21. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
