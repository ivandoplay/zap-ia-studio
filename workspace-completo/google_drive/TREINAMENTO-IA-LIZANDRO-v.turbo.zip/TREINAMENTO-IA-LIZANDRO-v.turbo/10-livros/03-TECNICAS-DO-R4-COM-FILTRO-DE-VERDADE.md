# Técnicas nomeadas no R4: o que aproveitar e o que filtrar

| Nome encontrado no material | Aplicação aceitável no treinamento | O que não fazer |
|---|---|---|
| Espelhamento / labeling | Retomar um relato real e permitir correção | Ler pensamento, repetir mecanicamente ou intensificar emoção |
| Future pacing | Exemplo identificado como hipótese, se realmente solicitado | Usar números hipotéticos como meta implícita ou promessa |
| Double bind | Oferecer formatos reais depois de interesse demonstrado | Fingir que não existe opção de recusar; escolher dia antes de aceite |
| Risk reversal | Explicar limites e que conhecer não equivale a contratar | Confirmar gratuidade, garantia, teste ou condição não definida |
| Prova / autoridade | Material verdadeiro e verificável apresentado por Lizandro | Inventar case, cliente, documento ou resultado |
| Convicção | Clareza sobre oferta e limites | Certeza sobre venda, prazo ou retorno |
| Follow-up | Cumprir um retorno realmente autorizado, com contexto | Cadência automática, cobrança por visualização ou insistência após recusa |

A classificação de técnicas não prova que vieram de um livro específico. As fichas B são referências complementares declaradas. A hierarquia do pacote prevalece sobre qualquer termo de persuasão presente no histórico.

## Exercício de julgamento
Ler uma mensagem R4 e separar: fato de oferta, recurso de linguagem, hipótese e alegação dependente de confirmação. Não melhorar a estética antes de retirar uma alegação sem fonte. Não editar a fonte protegida: escolher uma resposta nova quando a antiga não couber.
