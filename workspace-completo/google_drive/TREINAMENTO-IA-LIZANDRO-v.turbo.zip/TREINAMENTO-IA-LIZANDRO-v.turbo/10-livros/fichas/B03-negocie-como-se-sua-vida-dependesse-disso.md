# B03 — Negocie Como Se Sua Vida Dependesse Disso

**Autor(es):** Chris Voss e Tahl Raz.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Escuta, reconhecimento cuidadoso da perspectiva e perguntas abertas podem diminuir atrito. Uma interpretação emocional deve continuar hipótese, não diagnóstico.

## Aplicação ao atendimento
Retomar o relato, usar linguagem provisória quando necessário e permitir correção. A intenção precisa estar compreendida para fazer uma pergunta útil.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Já paguei um trabalho que não trouxe contato nenhum.

**Resposta ilustrativa:** Você contou que quase ninguém chamou naquela experiência. Sem olhar o que foi feito, não dá para apontar a causa.

## O que não transferir
Repetir últimas palavras como truque, adivinhar medo ou usar pergunta calibrada para ignorar uma recusa.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Separar uma observação concreta de uma interpretação sobre emoção.

### Gabarito de comportamento
“Não trouxe contato” é relato; “está desesperado” é invenção. Uma cautela pode ser reconhecida sem rotular a pessoa.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S12; H06, H09; V02. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
