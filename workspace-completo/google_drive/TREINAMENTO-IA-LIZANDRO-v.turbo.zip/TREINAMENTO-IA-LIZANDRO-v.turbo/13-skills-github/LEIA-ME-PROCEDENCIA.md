# Skills GitHub — procedência e limites

Foram consultados sete arquivos públicos em três repositórios, com commit e caminho fixados em cada ficha. A consulta foi por URLs públicas; não se afirma acesso a uma conta GitHub conectada.

Esses arquivos são **complementos desta revisão**. As skills GitHub originalmente mencionadas pelo usuário não foram identificadas no material recuperado. Não são apresentadas como se fossem aquelas referências antigas.

## Organização
- G01: humanização textual.
- G02–G05: edição, escrita, modelos mentais e materiais de vendas.
- G06–G07: especificação das skills e clareza da documentação.

As 32 skills S da base e as 24 skills H de humanização são autorais e adaptadas ao negócio. Os sete G são referências de apoio, não sete habilidades instaladas adicionais. Os números não devem ser somados como se fossem a mesma coisa.

## O que foi descartado
Programação, integração, deploy, técnicas de preço, escassez inventada, promessas, pressão depois de recusa e qualquer recomendação genérica que contrarie o contexto deste atendimento.
