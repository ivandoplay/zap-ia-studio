# G04 — Marketing psychology

## Fonte pública consultada nesta revisão
- Repositório: `coreyhaines31/marketingskills`.
- Arquivo: `skills/marketing-psychology/SKILL.md`.
- Commit fixado: `e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b`.
- URL: https://github.com/coreyhaines31/marketingskills/blob/e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b/skills/marketing-psychology/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Reduzir fricção sem manipular.

## Adaptação autoral em português
Usar trabalho a resolver, limite de conhecimento, quantidade de escolhas e hipóteses para compreender a necessidade.

## Aplicação neste pacote
H03, H06, H12, H16, H21.

## Filtros aplicados
Excluir técnicas de preço, escassez fabricada, medo, dívida por reciprocidade e compromisso extraído de um “sim”. Um modelo mental é hipótese, não lei nem leitura de pessoa.

## Exemplo aplicado
Se o problema relatado é conteúdo, falar de conteúdo antes de propor mais anúncios.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
