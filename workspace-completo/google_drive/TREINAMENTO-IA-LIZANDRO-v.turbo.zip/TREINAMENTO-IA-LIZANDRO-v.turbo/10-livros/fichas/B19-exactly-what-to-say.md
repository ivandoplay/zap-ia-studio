# B19 — Exactly What to Say

**Autor(es):** Phil M. Jones.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A escolha de palavras e a construção de perguntas influenciam a facilidade de uma conversa. Frases prontas precisam ser submetidas ao contexto e à autonomia.

## Aplicação ao atendimento
Usar perguntas curtas com alternativas reais quando existe uma decisão clara pendente; permitir a pessoa recusar.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Pode ser essa conversa de 15 minutos.

**Resposta ilustrativa:** Você prefere por ligação ou seguir por mensagem aqui?

## O que não transferir
Usar escolha falsa, pressupor contratação ou perguntar terça ou quarta antes de a pessoa aceitar conversar.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Revisar um convite que pressupõe interesse ainda não demonstrado.

### Gabarito de comportamento
O convite só aparece após abertura e oferece texto como caminho válido.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S17, S17, S18; H12, H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
