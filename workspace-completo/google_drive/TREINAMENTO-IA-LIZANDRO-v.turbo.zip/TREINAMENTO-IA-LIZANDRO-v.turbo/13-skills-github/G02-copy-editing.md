# G02 — Copy editing

## Fonte pública consultada nesta revisão
- Repositório: `coreyhaines31/marketingskills`.
- Arquivo: `skills/copy-editing/SKILL.md`.
- Commit fixado: `e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b`.
- URL: https://github.com/coreyhaines31/marketingskills/blob/e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b/skills/copy-editing/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Editar com finalidade, preservando o conteúdo.

## Adaptação autoral em português
Revisões separadas de clareza, voz, especificidade e sustentação das afirmações; edição pontual não deve virar reescrita total.

## Aplicação neste pacote
H05, H08, H10, H11, H22, H24.

## Filtros aplicados
Não aumentar emoção, promessa ou sensação de garantia. A direção comercial da fonte foi subordinada aos limites do negócio.

## Exemplo aplicado
Uma pergunta sobre posts recebe resposta sobre produção/publicação, sem pacote de posts inventado.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
