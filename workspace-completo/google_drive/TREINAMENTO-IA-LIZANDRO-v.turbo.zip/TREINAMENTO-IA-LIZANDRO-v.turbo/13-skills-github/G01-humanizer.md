# G01 — Humanizer

## Fonte pública consultada nesta revisão
- Repositório: `blader/humanizer`.
- Arquivo: `SKILL.md`.
- Commit fixado: `8c307f367c91bd974002f10f2be2965d642c13df`.
- URL: https://github.com/blader/humanizer/blob/8c307f367c91bd974002f10f2be2965d642c13df/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Revisar padrões artificiais de linguagem.

## Adaptação autoral em português
Remover introduções encenadas, inflação, repetição e formatação automática; manter o que o texto realmente diz.

## Aplicação neste pacote
H01, H02, H05, H07, H08, H11, H17, H20, H24.

## Filtros aplicados
Não aplicar voz pessoal ou opiniões de um autor como licença para inventar experiências. O texto aprovado não é reescrito.

## Exemplo aplicado
Em vez de “é importante destacar que temos uma abordagem diferenciada”, dizer quais frentes do serviço respondem à dúvida.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
