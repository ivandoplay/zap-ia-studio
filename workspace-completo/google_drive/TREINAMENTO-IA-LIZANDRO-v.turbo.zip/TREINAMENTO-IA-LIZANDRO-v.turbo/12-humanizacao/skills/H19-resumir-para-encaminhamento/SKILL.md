---
name: resumir-para-encaminhamento
description: O interlocutor quer envolver sócio ou responsável.
---

# H19 — Resumir para encaminhamento

## Objetivo
Facilitar avaliação sem delegar pressão ao intermediário.

## Gatilho observável
O interlocutor quer envolver sócio ou responsável. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Usar um resumo que se sustente sozinho.
2. Incluir a oferta ampla e o próximo passo opcional.
3. Não pedir dados de terceiros como condição.

## O que evitar
Não transformar o intermediário em cobrador ou prometer condição que não conhece.

## Situação de estudo
Pedido de resumo para sócio.

**Não usar:** Passa o celular do dono que eu resolvo com ele.

**Melhor:** A assessoria reúne conteúdo e redes sociais, divulgação pensada por veículo e apoio às vendas. Dá para conhecer por mensagem ou em uma conversa de cerca de 15 minutos.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G05, G07. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
