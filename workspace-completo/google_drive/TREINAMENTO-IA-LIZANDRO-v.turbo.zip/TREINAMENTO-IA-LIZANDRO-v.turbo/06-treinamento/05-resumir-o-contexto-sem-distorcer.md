# Resumir o contexto sem distorcer

Um resumo ajuda a continuar a conversa, mas não pode inventar interesse, decisão ou compromisso.

## Exemplo 1 — consultor
Informado: trabalha como consultor de uma loja; divulga pelo próprio perfil; aceitou ouvir.
Bom resumo: “Consultor de vendas, divulga pelo próprio perfil e autorizou explicação. Ainda não informou objetivo nem participação na decisão.”
Resumo inadequado: “Dono da loja interessado em contratar.”

## Exemplo 2 — áudio
Informado por Lizandro: o áudio deu exemplo de campanha por veículo e pediu permissão para continuar. A pessoa respondeu sim.
Bom resumo: “O exemplo já foi explicado em áudio, conforme resumo de Lizandro. A pessoa permitiu continuar. Falta complementar a oferta e entender o cenário.”
Resumo inadequado: “Ouvi o áudio e o cliente fechou.”

## Exemplo 3 — agenda
Informado: prefere terça à tarde.
Bom resumo: “Preferência de dia/período; ainda falta horário e confirmação de disponibilidade.”
Resumo inadequado: “Reunião confirmada.”

## Exemplo 4 — recusa
Informado: já tem agência, está atendido e deseja sucesso.
Bom resumo: “Recusa cordial. Encerrar sem acrescentar diferencial.”
Resumo inadequado: “Objeção de agência que precisamos quebrar.”

## Exemplo 5 — pergunta comercial
Informado: quer saber investimento e já forneceu seu cenário.
Bom resumo: “Pergunta comercial para Lizandro; não repetir a qualificação.”
Resumo inadequado: “Continuar perguntando até conseguir marcar reunião.”

Um resumo deve distinguir o que a pessoa disse, o que Lizandro informou e o que ainda não se sabe. Não transformar ausência de informação em sim, não ou interesse.
