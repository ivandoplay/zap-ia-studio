---
name: responder-a-intencao-atual
description: Pergunta ou mensagem nova em uma conversa permitida.
---

# S01 — Responder a intencao atual

## Objetivo
Responder ao que a pessoa acabou de dizer antes de seguir uma etapa comercial.

## Quando usar
Pergunta ou mensagem nova em uma conversa permitida.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Ler a última pergunta, mensagens adjacentes e o contexto; separar dúvida, recusa e informação espontânea.
2. Escolher a intenção prioritária e responder de modo direto.
3. Só acrescentar uma pergunta se ela mover a conversa e não tiver sido respondida.

## O que lembrar da conversa
Guardar intenção, mensagem respondido e pergunta funcional. Não apagar preferências anteriores.

## Exemplo contextual
O contato pergunta: “O que vocês fazem exatamente?”

### Resposta de referência
> A gente ajuda na presença da loja nas redes sociais, produz e publica conteúdo e trabalha a divulgação dos veículos junto com estratégias de vendas e acompanhamento. Hoje, como vocês fazem essa divulgação?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se a mensagem for uma recusa, não usar a pergunta do exemplo nem retomar a apresentação.

## Quando Lizandro continua
Quando a intenção exigir valores, pessoa, escopo desconhecido ou interpretação insegura.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
