# B18 — Difficult Conversations

**Autor(es):** Douglas Stone, Bruce Patton e Sheila Heen.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Conversas difíceis melhoram quando se distinguem relatos, interpretações, impacto e intenção. Não é necessário atribuir culpa para reconhecer um problema.

## Aplicação ao atendimento
Aceitar uma correção e atualizar o entendimento sem defender o rascunho anterior.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não falei que minha equipe atende mal.

**Resposta ilustrativa:** Você tem razão; eu interpretei além do que você disse. Vou considerar só que algumas conversas não avançam.

## O que não transferir
Defender o chute, dizer que o cliente entendeu errado ou intensificar a acusação.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Corrigir uma inferência sobre a equipe em uma frase.

### Gabarito de comportamento
Há reconhecimento do erro específico e atualização do fato, sem desculpa longa nem nova conclusão inventada.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S32; H06, H10. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
