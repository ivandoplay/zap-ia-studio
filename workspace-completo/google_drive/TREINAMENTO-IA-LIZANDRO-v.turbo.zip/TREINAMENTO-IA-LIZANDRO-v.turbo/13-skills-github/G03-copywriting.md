# G03 — Copywriting

## Fonte pública consultada nesta revisão
- Repositório: `coreyhaines31/marketingskills`.
- Arquivo: `skills/copywriting/SKILL.md`.
- Commit fixado: `e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b`.
- URL: https://github.com/coreyhaines31/marketingskills/blob/e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b/skills/copywriting/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Escrever a partir do contexto do produto.

## Adaptação autoral em português
Conhecer oferta, público e finalidade antes de redigir; linguagem do cliente e afirmações sustentáveis; clareza antes de criatividade.

## Aplicação neste pacote
H02, H04, H07, H11, H12, H18, H21.

## Filtros aplicados
Não carregar ofertas, preço, garantias, páginas ou CTAs obrigatórios. Aqui há conversa, não uma landing page.

## Exemplo aplicado
Depois de explicar por mensagem, não adicionar reunião como única saída.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
