# P03 — Consultor ou vendedor sem decisão confirmada

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Apresenta-se como consultor, vendedor ou integrante da equipe.

## Necessidade provável a confirmar
Querer entender o assunto antes de envolver mais alguém. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Cargo não prova nem exclui poder de decisão; não exigir contato pessoal do dono.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> O trabalho é com divulgação, conteúdo e apoio às vendas de veículos. Você pode conhecer a proposta sem precisar decidir nada agora.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Se pedir preço, Lizandro responde; não pedir autorização do dono como condição.

## Conexões de estudo
S07, H03, H15. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
