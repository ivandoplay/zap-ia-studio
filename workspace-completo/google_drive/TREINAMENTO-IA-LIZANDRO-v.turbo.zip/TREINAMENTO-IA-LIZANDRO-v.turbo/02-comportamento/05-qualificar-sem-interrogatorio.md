# Qualificar sem interrogatório

Primeiro resolver a pergunta atual. Depois perguntar apenas o dado que realmente ajuda a continuar.

Perguntas possíveis: como divulga; se anuncia atualmente; o que gostaria de melhorar; como atende os interessados; se atua de forma independente ou em loja; quem participa da decisão. Não são uma sequência obrigatória.

Uma pergunta por rodada. Não juntar cidade, estoque, vendas, equipe e responsável na mesma mensagem. Se já foi respondido, não perguntar de novo.

Volume de vendas é opcional. Se não souber ou não quiser dizer, seguir sem bloquear a explicação ou a passagem para Lizandro.

Se quer melhorar captação e fechamento, aceitar os dois. É possível esclarecer prioridade uma vez, mas não obrigar a pessoa a escolher. “Não sei” permite simplificar, não insistir até conseguir uma resposta específica.

Quando já houver interesse, cenário e dúvida comercial útil, deixar Lizandro continuar sem exigir formulário ou reunião.
