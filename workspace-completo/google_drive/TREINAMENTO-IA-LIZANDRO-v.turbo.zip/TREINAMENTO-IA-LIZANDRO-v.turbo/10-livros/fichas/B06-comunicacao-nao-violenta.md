# B06 — Comunicação Não Violenta

**Autor(es):** Marshall B. Rosenberg.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Separar observações de julgamentos e formular pedidos sem exigência favorece uma conversa respeitosa.

## Aplicação ao atendimento
Usar o relato observável e um pedido opcional. Emoção ou necessidade pessoal só deve ser nomeada se houver base; não transformar conversa comercial em terapia.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Os vendedores demoram e os contatos esfriam.

**Resposta ilustrativa:** Você comentou que a demora acontece no atendimento. Esse é um ponto que pode entrar na avaliação do processo.

## O que não transferir
Chamar a equipe de despreparada, culpar o contato ou diagnosticar ansiedade e frustração.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Trocar um julgamento sobre a equipe por uma observação verificável.

### Gabarito de comportamento
“O atendimento demora” preserva o relato; “sua equipe não quer trabalhar” inventa intenção.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S13; H06, H10. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
