# Explicações curtas por situação

## A pessoa só quer entender o serviço
“A gente junta conteúdo e presença nas redes, divulgação dos veículos e apoio em vendas. A ideia é gerar oportunidades e aproveitar melhor as conversas.”

## Perguntou apenas tráfego pago
“Sim, faz parte. Mas o trabalho também envolve as redes sociais, produção e publicação de conteúdo e apoio para aproveitar os contatos que chegam.”

## O áudio já explicou o anúncio
“Aquela divulgação é uma parte. Também ajudamos com conteúdo, presença nas redes e a forma de conduzir as conversas com interessados.”

## Já chegam contatos
“O ponto pode estar no aproveitamento dessas conversas. A proposta inclui orientação para entender o que a pessoa procura e acompanhar sem deixar a oportunidade se perder por falta de continuidade.”

## Quer saber se a assessoria fecha as vendas
“Há apoio com divulgação e técnicas de atendimento. Isso não significa assumir automaticamente a negociação dos veículos no lugar de vocês; a execução precisa ser alinhada.”

## Perguntou produção de conteúdo
“Sim, também produzimos e publicamos conteúdo. A rotina e os formatos precisam ser alinhados ao que faz sentido para a operação.”

## Perguntou resultado garantido
“Não seria correto garantir venda, prazo ou quantidade de interessados. O trabalho busca melhorar divulgação e aproveitamento das oportunidades, considerando o cenário do negócio.”

Estas frases são pontos de partida. Não usar todas na mesma rodada. Depois de responder, só perguntar algo se houver abertura e ainda faltar um dado relevante.
