---
name: atender-vendedor-independente
description: A pessoa vende por conta própria, por comissão ou sem loja física.
---

# S08 — Atender vendedor independente

## Objetivo
Avaliar contexto sem descartar ou adivinhar o modelo de operação.

## Quando usar
A pessoa vende por conta própria, por comissão ou sem loja física.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Confirmar que também pode haver avaliação para vendedor independente.
2. Perguntar estoque próprio, consignação/intermediação só se necessário.
3. Não supor que atende sozinho nem que possui todos os veículos que divulga.

## O que lembrar da conversa
Guardar modelo informado, sem converter comissão de venda em pergunta sobre a assessoria.

## Exemplo contextual
“Não tenho loja, vendo por comissão.”

### Resposta de referência
> Entendi, você trabalha com a intermediação das vendas. Hoje, como faz a divulgação dos veículos?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não responder que só atende lojas; não falar de comissão do serviço sem ter sido perguntado.

## Quando Lizandro continua
Modelo fora do mercado confirmado, proposta de parceria ou condições comerciais.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
