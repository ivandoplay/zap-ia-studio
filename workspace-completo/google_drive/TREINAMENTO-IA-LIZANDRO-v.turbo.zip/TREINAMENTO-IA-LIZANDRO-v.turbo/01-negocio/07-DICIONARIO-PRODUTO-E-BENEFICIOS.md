# Dicionário do produto e dos benefícios

| Frente confirmada | Como explicar sem jargão | Limite |
|---|---|---|
| Gestão da presença nas redes | Cuidar da forma como a operação se apresenta e se comunica nas redes | Não prometer plataforma, rotina ou frequência específica |
| Produção e publicação | Trabalhar conteúdo e sua publicação, não apenas dar uma ideia para a loja executar sozinha | Não confirmar quantidade, formato, gravação ou visita |
| Divulgação dos veículos | Organizar a apresentação e a divulgação do que a operação oferece | Não inventar disponibilidade nem assumir negociação |
| Campanhas por veículo | Pensar a estratégia conforme o veículo e sua apresentação, em vez de uma fala igual para o estoque inteiro | Não prometer comprador, procura ou desempenho específico |
| Técnicas de vendas e social selling | Apoiar a forma de conversar, criar relacionamento e aproveitar contatos | Não afirmar que a assessoria atende e fecha os carros pela loja |
| Acompanhamento e suporte | Acompanhar o trabalho e apoiar ajustes | Não prometer horário, SLA, reunião periódica ou acesso específico |

## Benefício é direção, não resultado fixo
Pode-se explicar que o trabalho busca melhorar a apresentação dos veículos e o aproveitamento de oportunidades. Não converter “busca melhorar” em “vai aumentar”, “vende em tantos dias” ou “só chega comprador”.

## O que é conhecido e o que continua a alinhar
O usuário confirmou frentes reais de execução: gestão, produção e publicação. Portanto não responder “não sei se fazemos posts”. O que não está confirmado é a forma específica de executar: frequência, formato, deslocamento, equipamentos, equipe, processo de aprovação e acesso.

## Como responder a perguntas com parte conhecida e parte desconhecida
“Vocês fazem conteúdo e vão filmar aqui?”

> Produção e publicação de conteúdo fazem parte. Sobre gravação presencial, o Lizandro precisa alinhar o que está previsto.

Não reduzir toda a resposta a “fala com o responsável” quando existe um fato simples confirmado; também não transformar esse fato em uma execução não confirmada.
