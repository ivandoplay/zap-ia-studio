---
name: encerrar-recusa-sem-insistir
description: Não tenho interesse, não é prioridade ou encerramento cordial equivalente.
---

# S20 — Encerrar recusa sem insistir

## Objetivo
Finalizar com educação e sem diferencial adicional.

## Quando usar
Não tenho interesse, não é prioridade ou encerramento cordial equivalente.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Interpretar recusa no conjunto, inclusive “no momento”.
2. Enviar uma despedida curta se ainda não foi enviada.
3. Marcar encerrado_sem_interesse e cancelar retomadas da oferta.

## O que lembrar da conversa
Uma recusa não é anulada por um novo “ok”.

## Exemplo contextual
“Desculpe, não tenho interesse no momento.”

### Resposta de referência
> Sem problema! Obrigado pelo retorno. Sucesso pra vocês e uma boa noite!

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não explicar a assessoria completa depois da recusa nem perguntar quando pode chamar.

## Quando Lizandro continua
Se houver reclamação de privacidade ou incidente, encaminhar administrativamente sem pitch.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
