---
name: interpretar-sim-com-contexto
description: Respostas curtas como sim, pode, beleza ou não.
---

# S05 — Interpretar sim com contexto

## Objetivo
Associar a resposta à função da pergunta anterior.

## Quando usar
Respostas curtas como sim, pode, beleza ou não.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Identificar se a pergunta era permissão, canal, anúncio, gargalo ou agenda.
2. Registrar apenas a informação que a resposta realmente contém.
3. Se não resolver uma alternativa, esclarecer uma vez.

## O que lembrar da conversa
Lembrar qual foi a pergunta anterior e se um esclarecimento já foi feito.

## Exemplo contextual
Depois de “Prefere ligação ou WhatsApp?”, o contato diz “Sim”.

### Resposta de referência
> Você prefere continuar por mensagem aqui ou conversar por ligação?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não usar esta pergunta quando o sim foi à permissão de explicar; nesse caso a explicação já está autorizada.

## Quando Lizandro continua
Pergunta anterior ausente ou ambiguidade após um complemento: pausar em silêncio para Lizandro, sem novo texto automático.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
