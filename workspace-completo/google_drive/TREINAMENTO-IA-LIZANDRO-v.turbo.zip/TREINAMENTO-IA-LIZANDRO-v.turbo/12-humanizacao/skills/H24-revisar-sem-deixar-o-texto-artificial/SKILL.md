---
name: revisar-sem-deixar-o-texto-artificial
description: Existe um rascunho antes do envio.
---

# H24 — Revisar sem deixar o texto artificial

## Objetivo
Remover ruído sem mudar fatos, voz ou texto protegido.

## Gatilho observável
Existe um rascunho antes do envio. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Checar intenção, fonte e contexto.
2. Cortar repetições, superlativos e introduções vazias.
3. Conferir limites e uma eventual pergunta útil.

## O que evitar
Não reescrever aprovados nem eliminar toda pontuação, todo tópico ou toda repetição por regra estética.

## Situação de estudo
Revisão de um resumo novo, não de um original protegido.

**Não usar:** Perfeito! É importante destacar que contamos com uma abordagem totalmente diferenciada e estratégica.

**Melhor:** O trabalho combina conteúdo, divulgação por veículo e apoio às vendas.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G02, G06, G07. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
