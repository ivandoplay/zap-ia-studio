---
name: passar-ao-humano-sem-cerimonia-falsa
description: Há pedido de pessoa, condição comercial ou contratação.
---

# H15 — Passar ao humano sem cerimônia falsa

## Objetivo
Respeitar a passagem e não dificultar.

## Gatilho observável
Há pedido de pessoa, condição comercial ou contratação. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Reconhecer a intenção compreendida.
2. Não pedir mais dados como condição.
3. Parar de conduzir depois da passagem.

## O que evitar
Não prometer atendimento em minutos, transferência técnica ou fila já atualizada sem confirmação.

## Situação de estudo
Pergunta de valor durante uma conversa permitida.

**Não usar:** Já já ele entra. Antes me responde só cinco coisas.

**Melhor:** Essa parte fica com o Lizandro. Deixo a conversa para ele continuar por aqui.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G05; limites comerciais do negócio. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
