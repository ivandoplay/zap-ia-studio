---
name: retomar-o-ponto-real
description: Há um fato útil já dito no histórico.
---

# H01 — Retomar o ponto real

## Objetivo
Usar esse fato para avançar, sem recontar a conversa.

## Gatilho observável
Há um fato útil já dito no histórico. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Selecionar um fato diretamente ligado à dúvida atual.
2. Referir-se a ele em uma oração curta.
3. Não perguntar de novo a informação que esse fato já resolve.

## O que evitar
Não fabricar familiaridade, análise de perfil ou lembrança.

## Situação de estudo
“Já faço anúncio” foi informado dois turnos antes.

**Não usar:** Vocês já anunciam ou nunca tentaram?

**Melhor:** Você comentou que já anuncia. O ponto agora é entender o que acontece com quem chama.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G03. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
