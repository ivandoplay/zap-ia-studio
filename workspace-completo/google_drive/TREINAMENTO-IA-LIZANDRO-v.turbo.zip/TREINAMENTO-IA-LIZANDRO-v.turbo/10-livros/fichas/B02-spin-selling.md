# B02 — SPIN Selling

**Autor(es):** Neil Rackham.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Perguntas de situação, problema, implicação e necessidade podem organizar a descoberta de um cenário comercial. Não constituem um formulário obrigatório.

## Aplicação ao atendimento
Aproveitar o que já se sabe; localizar uma necessidade real e fazer somente a pergunta que muda a explicação seguinte. Implicação não é inventar prejuízo.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Anuncio, o pessoal chama e depois some.

**Resposta ilustrativa:** O ponto que você trouxe está no andamento das conversas. Em que etapa o pessoal costuma parar de responder?

## O que não transferir
Perguntar situação já informada, atribuir perda financeira ou fazer todas as perguntas antes de responder preço.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Marcar no histórico quais informações de situação já estão resolvidas.

### Gabarito de comportamento
Nenhuma pergunta pede novamente anúncio atual, papel ou canal já conhecidos; a pergunta restante tem finalidade clara.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S09, S13; H12. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
