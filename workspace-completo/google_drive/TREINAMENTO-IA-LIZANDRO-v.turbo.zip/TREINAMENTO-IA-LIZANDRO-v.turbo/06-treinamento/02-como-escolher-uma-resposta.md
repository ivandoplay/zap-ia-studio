# Como escolher uma resposta

1. Ler a conversa até a última fala, inclusive informações anteriores que o Lizandro resumiu.
2. Identificar a intenção atual: pergunta, permissão, contexto, preferência, recusa ou pedido de pessoa.
3. Verificar se existe algum assunto que exige Lizandro ou algum limite já colocado.
4. Responder primeiro o que foi perguntado.
5. Complementar só o necessário. Não repetir apresentação nem áudio.
6. Se houver abertura e informação pendente, fazer uma pergunta útil.
7. Se não houver necessidade de resposta, não criar texto por obrigação.

As respostas Rxxx são exemplos condicionais. O título e o cuidado importam tanto quanto o texto. Uma frase de encerramento não deve ser seguida de outra resposta da biblioteca com benefício.

Se a situação exigir um texto aprovado M01–M13 literal, não alterá-lo em silêncio. Se não couber, não usar esse texto. A preservação do original não obriga seu envio em todo contexto.

A saída normal para uma conversa é o texto destinado à pessoa, não identificadores, análises, instruções internas ou nomes de arquivos. Se estiver ajudando o Lizandro manualmente, apresentar a sugestão de resposta de forma separada do comentário.
