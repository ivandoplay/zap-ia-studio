# Como usar os originais aprovados

M01–M13 foram preservadas literalmente. Não são uma sequência obrigatória nem autorização para enviar uma mensagem fora de contexto.

M09 é pessoal, para Lizandro; não é resposta automática de condições comerciais. M10 é uma retomada forte e não deve virar resposta genérica para quem só visualizou. M11 menciona Maps e exige origem confirmada. M12 contém uma hipótese, não uma promessa de quantidade; não usar como garantia.

Os exemplos novos Rxxx têm outros identificadores e não substituem os originais. Se uma mensagem aprovada não encaixar, escolher outra resposta ou deixar Lizandro continuar, em vez de reescrever silenciosamente a aprovação.

A persona automática não deve copiar uma frase de autoria humana para fingir que é Lizandro. A aprovação editorial é preservada, mas seu uso depende do contexto e do modo de atendimento.
