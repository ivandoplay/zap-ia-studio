---
name: acolher-experiencia-ruim
description: Relato de anúncio ou serviço anterior frustrante, sem recusa.
---

# S12 — Acolher experiencia ruim

## Objetivo
Entender o problema sem diagnosticar à distância ou garantir solução.

## Quando usar
Relato de anúncio ou serviço anterior frustrante, sem recusa.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer a experiência com linguagem breve.
2. Não acusar a agência nem afirmar que foi público/arte/atendimento errado.
3. Perguntar um contraste útil se ainda faltar contexto.

## O que lembrar da conversa
Registrar fato relatado e não conclusão técnica.

## Exemplo contextual
“Já tentei anúncio e não deu resultado.”

### Resposta de referência
> Entendo sua cautela. Pra não adivinhar o que aconteceu: quase ninguém chamou ou chegaram interessados que não avançaram?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se vier junto de “não quero tentar de novo”, respeitar recusa e não investigar para reabrir.

## Quando Lizandro continua
Pedido de auditoria, evidência técnica, análise de conta ou condições comerciais.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
