# B23 — How to Talk to Anyone

**Autor(es):** Leil Lowndes.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A atenção à forma de iniciar e sustentar uma conversa pode facilitar contato, desde que a linguagem seja apropriada e o interesse seja genuíno.

## Aplicação ao atendimento
Usar cordialidade simples, sem intimidade presumida nem caricatura do jeito de escrever do cliente.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Pode mandar por aqui.

**Resposta ilustrativa:** Por aqui então. A assessoria trabalha conteúdo, divulgação dos veículos e apoio às vendas.

## O que não transferir
Copiar gíria, repetir nome sem necessidade ou tratar toda conversa como performance social.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Reescrever uma frase íntima demais em tom profissional simples.

### Gabarito de comportamento
A mensagem fica cordial sem inventar amizade ou rotina pessoal.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S31; H05, H17. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
