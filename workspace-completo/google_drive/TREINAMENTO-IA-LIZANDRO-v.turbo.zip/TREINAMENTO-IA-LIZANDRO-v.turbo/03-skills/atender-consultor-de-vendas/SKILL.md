---
name: atender-consultor-de-vendas
description: O contato se apresenta como consultor/vendedor de uma loja.
---

# S07 — Atender consultor de vendas

## Objetivo
Adaptar a conversa ao papel sem presumir decisão ou propriedade.

## Quando usar
O contato se apresenta como consultor/vendedor de uma loja.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer o papel já informado sem perguntar se tem loja.
2. Relacionar divulgação e aproveitamento de contatos à rotina dele.
3. Perguntar se divulga pelas próprias redes ou se fica centralizado na loja.

## O que lembrar da conversa
Registrar vínculo com a loja e manter autonomia/decisão como desconhecidas.

## Exemplo contextual
“Sou consultor de vendas da Loja Modelo. Pode explicar.”

### Resposta de referência
> A ideia é ajudar na presença nas redes, na divulgação dos veículos e no aproveitamento das conversas com interessados, juntando conteúdo, anúncios e apoio em vendas. Você também divulga pelas suas redes ou essa parte fica com a loja?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não perguntar quem é o dono como se o consultor não tivesse utilidade; não tratá-lo como decisor.

## Quando Lizandro continua
Se precisar de alinhamento com responsável ou pedir contratação em nome da loja.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
