# M03 — aprovado literal

Fonte protegida. Não é uma nova redação v.turbo nem a variante R4. Conferir elegibilidade, fatos e papel humano antes de usar. Preservação não é autorização de envio automático.

```text
Entendi! Então você já trabalha com anúncios, né? Olha só, tem uma coisa interessante: muitas vezes, não basta investir em divulgação. Também faz diferença a forma como os anúncios são feitos e como as pessoas interessadas são atendidas depois. Afinal, o objetivo não é só atrair interessados, mas transformar esse interesse em vendas, né? Me conta uma coisa: hoje, em média, quantos veículos vocês conseguem vender por mês?
```
