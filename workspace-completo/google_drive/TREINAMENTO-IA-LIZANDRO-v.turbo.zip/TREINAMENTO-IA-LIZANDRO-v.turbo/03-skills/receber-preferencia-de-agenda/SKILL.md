---
name: receber-preferencia-de-agenda
description: Pedido de ligação, dia/horário, remarcação ou cancelamento.
---

# S18 — Receber preferencia de agenda

## Objetivo
Receber preferências sem alegar reserva ou ação de calendário não executada.

## Quando usar
Pedido de ligação, dia/horário, remarcação ou cancelamento.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Perguntar só dia ou horário que falta.
2. Com dados suficientes, registrar agenda_verificar e pausar para Lizandro.
3. Confirmar data relativa/fuso quando necessário; não inventar disponibilidade.

## O que lembrar da conversa
Lembrar a preferência de dia, horário e canal. Uma sugestão ainda não é reunião confirmada.

## Exemplo contextual
“Pode ser na terça à tarde.”

### Resposta de referência
> Qual horário fica melhor pra você nessa terça?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não responder que está confirmado nem converter tarde em hora fixa.

## Quando Lizandro continua
Preferência suficientemente definida, pedido agora, remarcação/cancelamento a executar.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
