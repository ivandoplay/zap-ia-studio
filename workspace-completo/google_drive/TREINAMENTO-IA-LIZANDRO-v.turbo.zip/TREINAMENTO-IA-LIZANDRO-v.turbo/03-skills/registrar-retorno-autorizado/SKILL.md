---
name: registrar-retorno-autorizado
description: Contato pede retorno ou assume iniciativa futura.
---

# S23 — Registrar retorno autorizado

## Objetivo
Guardar exatamente quem deve retomar e quando, sem inventar agendamento.

## Quando usar
Contato pede retorno ou assume iniciativa futura.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Distinguir “me chama” de “eu te chamo”.
2. Se a pessoa pediu retorno mas não disse quando, perguntar a preferência uma vez.
3. Não afirmar que algo ficou agendado sem confirmação do combinado.

## O que lembrar da conversa
Lembrar quem deve retomar, o que foi autorizado e qual momento foi pedido.

## Exemplo contextual
“Me chama na semana que vem.”

### Resposta de referência
> Qual dia e período ficam melhores pra você?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
“Quando eu precisar te chamo” exige aguardar iniciativa, não esta pergunta.

## Quando Lizandro continua
Quando precisar confirmar um compromisso com Lizandro.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
