# Índice e trilhas de estudo

## Trilha prática
1. Clareza e escuta: B01, B06, B13, B15, B18.
2. Diagnóstico sem interrogatório: B02, B03, B16, B25, B26.
3. Oferta e apresentação: B08, B09, B10, B14, B17, B28.
4. Confiança e autonomia: B04, B05, B07, B19, B21, B24, B29, B30.
5. Revisão de inferências e consistência: B11, B12, B20, B22, B23, B27.

Os opcionais B31–B39 têm conexão limitada e não devem comandar o atendimento. Nenhum autor é citado ao contato como substituto de prova sobre o serviço.

## Todas as fichas

- [B01 — Como Fazer Amigos e Influenciar Pessoas](fichas/B01-como-fazer-amigos-e-influenciar-pessoas.md) — Dale Carnegie.
- [B02 — SPIN Selling](fichas/B02-spin-selling.md) — Neil Rackham.
- [B03 — Negocie Como Se Sua Vida Dependesse Disso](fichas/B03-negocie-como-se-sua-vida-dependesse-disso.md) — Chris Voss e Tahl Raz.
- [B04 — As Armas da Persuasão](fichas/B04-as-armas-da-persuasao.md) — Robert B. Cialdini.
- [B05 — Pré-suasão](fichas/B05-pre-suasao.md) — Robert B. Cialdini.
- [B06 — Comunicação Não Violenta](fichas/B06-comunicacao-nao-violenta.md) — Marshall B. Rosenberg.
- [B07 — Como Chegar ao Sim](fichas/B07-como-chegar-ao-sim.md) — Roger Fisher, William Ury e Bruce Patton.
- [B08 — The Challenger Sale](fichas/B08-the-challenger-sale.md) — Matthew Dixon e Brent Adamson.
- [B09 — A Bíblia de Vendas](fichas/B09-a-biblia-de-vendas.md) — Jeffrey Gitomer.
- [B10 — Little Red Book of Selling](fichas/B10-little-red-book-of-selling.md) — Jeffrey Gitomer.
- [B11 — Rápido e Devagar](fichas/B11-rapido-e-devagar.md) — Daniel Kahneman.
- [B12 — Mindset](fichas/B12-mindset.md) — Carol S. Dweck.
- [B13 — Os 7 Hábitos das Pessoas Altamente Eficazes](fichas/B13-os-7-habitos-das-pessoas-altamente-eficazes.md) — Stephen R. Covey.
- [B14 — To Sell Is Human](fichas/B14-to-sell-is-human.md) — Daniel H. Pink.
- [B15 — Made to Stick](fichas/B15-made-to-stick.md) — Chip Heath e Dan Heath.
- [B16 — The Mom Test](fichas/B16-the-mom-test.md) — Rob Fitzpatrick.
- [B17 — Building a StoryBrand](fichas/B17-building-a-storybrand.md) — Donald Miller.
- [B18 — Difficult Conversations](fichas/B18-difficult-conversations.md) — Douglas Stone, Bruce Patton e Sheila Heen.
- [B19 — Exactly What to Say](fichas/B19-exactly-what-to-say.md) — Phil M. Jones.
- [B20 — Fanatical Prospecting](fichas/B20-fanatical-prospecting.md) — Jeb Blount.
- [B21 — Emotional Intelligence](fichas/B21-emotional-intelligence.md) — Daniel Goleman.
- [B22 — O Poder do Hábito](fichas/B22-o-poder-do-habito.md) — Charles Duhigg.
- [B23 — How to Talk to Anyone](fichas/B23-how-to-talk-to-anyone.md) — Leil Lowndes.
- [B24 — Crucial Conversations](fichas/B24-crucial-conversations.md) — Kerry Patterson, Joseph Grenny, Ron McMillan e Al Switzler.
- [B25 — The Advice Trap](fichas/B25-the-advice-trap.md) — Michael Bungay Stanier.
- [B26 — The Coaching Habit](fichas/B26-the-coaching-habit.md) — Michael Bungay Stanier.
- [B27 — Way of the Wolf](fichas/B27-way-of-the-wolf.md) — Jordan Belfort.
- [B28 — Sell with a Story](fichas/B28-sell-with-a-story.md) — Paul Smith.
- [B29 — The Trusted Advisor](fichas/B29-the-trusted-advisor.md) — David H. Maister, Charles H. Green e Robert M. Galford.
- [B30 — The JOLT Effect](fichas/B30-the-jolt-effect.md) — Matthew Dixon e Ted McKenna.
- [B31 — A Psicologia Financeira](fichas/B31-a-psicologia-financeira.md) — Morgan Housel.
- [B32 — A sutil arte de ligar o foda-se](fichas/B32-a-sutil-arte-de-ligar-o-foda-se.md) — Mark Manson.
- [B33 — Mais Esperto que o Diabo](fichas/B33-mais-esperto-que-o-diabo.md) — Napoleon Hill.
- [B34 — O Homem Mais Rico da Babilônia](fichas/B34-o-homem-mais-rico-da-babilonia.md) — George S. Clason.
- [B35 — O Milagre da Manhã](fichas/B35-o-milagre-da-manha.md) — Hal Elrod.
- [B36 — O Poder do Agora](fichas/B36-o-poder-do-agora.md) — Eckhart Tolle.
- [B37 — Os Segredos da Mente Milionária](fichas/B37-os-segredos-da-mente-milionaria.md) — T. Harv Eker.
- [B38 — Pai Rico, Pai Pobre](fichas/B38-pai-rico-pai-pobre.md) — Robert T. Kiyosaki.
- [B39 — Quem Pensa Enriquece](fichas/B39-quem-pensa-enriquece.md) — Napoleon Hill.
