---
name: encaminhar-questao-comercial
description: Preço, verba, mensalidade, condição, cobrança, pagamento, desconto ou gratuidade.
---

# S15 — Encaminhar questao comercial

## Objetivo
Passar ao humano sem quantia, cálculo, confirmação ou barreira de qualificação.

## Quando usar
Preço, verba, mensalidade, condição, cobrança, pagamento, desconto ou gratuidade.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer a pergunta sem oferecer quantia, estimativa ou condição.
2. Deixar a questão para Lizandro, sem exigir mais qualificação.
3. Não voltar ao discurso comercial enquanto o atendimento pessoal estiver pendente.

## O que lembrar da conversa
Lembrar a pergunta comercial exata e que a conversa foi passada para Lizandro.

## Exemplo contextual
“Quanto custa o serviço de vocês?”

### Resposta de referência
> Essa parte precisa ser alinhada com o Lizandro. Vou deixar sua pergunta organizada para ele continuar por aqui.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não usar “depende” para emendar média de vendas antes da passagem. Nem afirmar gratuidade.

## Quando Lizandro continua
Sempre. Se houver recusa junto, priorizar encerramento sem reabrir a venda.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
