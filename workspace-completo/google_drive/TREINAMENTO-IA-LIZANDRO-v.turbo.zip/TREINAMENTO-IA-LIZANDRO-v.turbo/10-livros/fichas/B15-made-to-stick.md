# B15 — Made to Stick

**Autor(es):** Chip Heath e Dan Heath.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Ideias claras, concretas e coerentes com a situação são mais fáceis de compreender que abstrações e slogans.

## Aplicação ao atendimento
Usar um exemplo simples de veículo, divulgação e conversa, sempre apresentado como ilustração.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não entendi como isso funciona.

**Resposta ilustrativa:** Por exemplo: um veículo é apresentado nas redes e na campanha, a pessoa chama a loja e o atendimento procura entender o que ela busca. O trabalho ajuda nessas frentes; isso não é um resultado prometido.

## O que não transferir
Inventar história de cliente, usar números para tornar a explicação memorável ou confundir exemplo com garantia.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Explicar a assessoria sem as palavras solução, potencializar e revolucionário.

### Gabarito de comportamento
A resposta nomeia ações concretas e mantém o limite entre processo e resultado.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S02, S16; H04, H18. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
