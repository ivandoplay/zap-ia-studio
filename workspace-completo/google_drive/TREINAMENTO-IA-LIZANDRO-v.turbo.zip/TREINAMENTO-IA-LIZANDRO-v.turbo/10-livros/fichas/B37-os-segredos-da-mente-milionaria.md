# B37 — Os Segredos da Mente Milionária

**Autor(es):** T. Harv Eker.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1D9ObhVnTxrJwVDxgKVAYri_9a5i9p_Dx/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A obra discute crenças e comportamentos ligados a dinheiro. Isso não autoriza avaliar a mentalidade financeira do interessado.

## Aplicação ao atendimento
Usar como contraste: uma resposta comercial profissional não rotula alguém por cautela ou orçamento.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não cabe para mim agora.

**Resposta ilustrativa:** Tudo bem, respeito seu momento.

## O que não transferir
Não chamar a pessoa de limitada, usar vergonha ou sugerir dívida e risco para contratar.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Remover um julgamento de mentalidade de uma resposta.

### Gabarito de comportamento
A resposta respeita a decisão; não ensina finanças nem promete transformação pessoal.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S20; H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
