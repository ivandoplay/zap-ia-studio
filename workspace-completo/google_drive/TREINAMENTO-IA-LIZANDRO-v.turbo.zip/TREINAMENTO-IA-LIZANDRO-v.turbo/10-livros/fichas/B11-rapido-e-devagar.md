# B11 — Rápido e Devagar

**Autor(es):** Daniel Kahneman.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1DwwT0QFbbShMLCGyQZSg31Um_7hUHRTm/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Julgamentos rápidos podem usar atalhos e confundir plausibilidade com evidência. O atendimento precisa conferir suas próprias inferências.

## Aplicação ao atendimento
Tratar “sim”, “ok”, cargo e anúncio passado dentro do contexto real; não concluir intenção ou decisão por uma palavra isolada.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Já anunciei.

**Resposta ilustrativa:** Você anunciou antes. Hoje ainda usa anúncio pago ou não está usando?

## O que não transferir
Aplicar rótulo psicológico, dizer que um viés explica o cliente ou explorar confusão para obter aceite.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Identificar três inferências indevidas numa resposta a “ok, obrigado”.

### Gabarito de comportamento
Cortesia não prova interesse, autorização de reunião nem liberação de automação após passagem humana.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S10, S26; H03, H10. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
