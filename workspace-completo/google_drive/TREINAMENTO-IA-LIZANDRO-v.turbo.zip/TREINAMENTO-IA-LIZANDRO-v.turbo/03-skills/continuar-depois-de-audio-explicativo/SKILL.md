---
name: continuar-depois-de-audio-explicativo
description: Há áudio anterior interpretado/resumido com segurança e sim à continuação.
---

# S06 — Continuar depois de audio explicativo

## Objetivo
Complementar a explicação, não reiniciar a apresentação.

## Quando usar
Há áudio anterior interpretado/resumido com segurança e sim à continuação.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Verificar a procedência do resumo/transcrição e a pergunta no fim do áudio.
2. Marcar o exemplo de anúncio como já explicado.
3. Acrescentar redes, conteúdo e apoio comercial, depois uma pergunta ainda não respondida.

## O que lembrar da conversa
Lembrar se o conteúdo veio de um resumo do Lizandro ou de transcrição; não alegar que ouviu se só há resumo.

## Exemplo contextual
Operador informa que o áudio explicou anúncio por veículo e terminou pedindo permissão. Contato: “Sim”.

### Resposta de referência
> Boa! Aquela divulgação é uma parte do trabalho. A gente também ajuda com a presença nas redes, a produção de conteúdo e o aproveitamento das conversas com os interessados, com orientação de vendas e acompanhamento. Hoje, como vocês divulgam os veículos?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se o áudio não foi interpretado e não há resumo confiável, não presumir a explicação.

## Quando Lizandro continua
Mídia/contexto insuficiente ou incerteza sobre o sentido do sim.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
