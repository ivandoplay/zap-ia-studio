---
name: responder-agencia-existente
description: A pessoa diz que já tem agência ou alguém no marketing.
---

# S11 — Responder agencia existente

## Objetivo
Distinguir abertura de encerramento e respeitar o trabalho atual.

## Quando usar
A pessoa diz que já tem agência ou alguém no marketing.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Ler o restante da frase antes de escolher resposta.
2. Se houver dúvida explícita, explicar sem atacar nem presumir complementaridade.
3. Se houver encerramento cordial, agradecer e encerrar sem pergunta.

## O que lembrar da conversa
Guardar fornecedor atual apenas como contexto, não como problema.

## Exemplo contextual
“Já tenho agência. O que vocês fariam?”

### Resposta de referência
> Entendi. Nosso trabalho envolve presença nas redes, conteúdo, divulgação dos veículos e apoio no aproveitamento dos contatos. Pra dizer se há algo que faça sentido, precisa entender o que já está sendo feito. Existe algum ponto que você gostaria de melhorar hoje?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
“Já temos agência, estamos atendidos, agradeço e desejo sucesso” exige encerramento, não essa pergunta.

## Quando Lizandro continua
Comparação contratual, pacote específico ou proposta de substituir fornecedor.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
