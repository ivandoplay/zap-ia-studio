# B16 — The Mom Test

**Autor(es):** Rob Fitzpatrick.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Perguntas sobre fatos e comportamentos reais são mais informativas que perguntas que induzem elogio ou aprovação de uma ideia.

## Aplicação ao atendimento
Quando uma pergunta for necessária, pedir um dado sobre o que acontece hoje, não se a pessoa gostaria de um benefício óbvio.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Quase ninguém chama pela divulgação.

**Resposta ilustrativa:** Hoje vocês mostram os veículos em quais canais?

## O que não transferir
Perguntar “você gostaria de vender mais?” para fabricar interesse ou exigir detalhes antes de responder a uma dúvida objetiva.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Trocar uma pergunta de aprovação por uma pergunta factual útil.

### Gabarito de comportamento
A pergunta busca canal, situação ou etapa real e só aparece quando ainda não foi respondida.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S09; H12, H21. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
