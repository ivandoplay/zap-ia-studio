# B30 — The JOLT Effect

**Autor(es):** Matthew Dixon e Ted McKenna.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Indecisão pode envolver incerteza sobre como avaliar opções, não apenas falta de interesse. Esclarecer critérios é diferente de pressionar uma decisão.

## Aplicação ao atendimento
Responder à dúvida concreta, limitar excesso de alternativas e oferecer uma forma simples de conhecer o trabalho. Não diagnosticar indecisão quando existe recusa.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Fiquei sem entender se é só anúncio.

**Resposta ilustrativa:** Não é só anúncio: também há gestão da presença nas redes, produção e publicação de conteúdo e apoio às vendas. As campanhas são pensadas por veículo.

## O que não transferir
Inventar garantia para reduzir risco, criar prazo ou transformar “não quero” em indecisão.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Reduzir uma explicação longa às frentes que respondem a dúvida.

### Gabarito de comportamento
A dúvida recebe resposta completa; não há condição comercial, pressão ou reunião obrigatória.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S02, S03; H02, H08, H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
