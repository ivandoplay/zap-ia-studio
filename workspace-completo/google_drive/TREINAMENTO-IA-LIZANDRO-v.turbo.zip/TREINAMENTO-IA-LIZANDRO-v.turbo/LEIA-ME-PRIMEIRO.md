# Treinamento IA Lizandro · v.turbo

Pacote completo de conhecimento, comportamento e linguagem para o atendimento de interessados na assessoria de Lizandro Celestino / Alavancagem de Vendas, no mercado de veículos. **Somente treinamento**: sem legislação, políticas/métodos de plataforma, conexão, integração, deploy, extensão ou novo backup importável.

## O que está aqui
- **224 arquivos**, sendo **203 documentos Markdown**, separados por assunto.
- **56 skills autorais:** 32 operacionais e 24 de humanização.
- **3 filtros de voz** e **12 perfis de interlocutor** com sinais, limites e exemplos.
- **39 fichas de livros:** 30 principais e 9 opcionais, todas com procedência e aplicação.
- **164 referências de resposta**, 45 situações/objeções e 105 fichas de encaixe do R4.
- **74 conversas didáticas**, **232 exercícios com gabarito** e **50 pares bom/ruim** em dois conjuntos.
- **7 arquivos de skills públicas consultados**, em 3 repositórios, com caminhos e commits fixados.
- **M01–M13 aprovadas preservadas literalmente**, em JSON original e Markdown individual.
- Fonte R4 textual recuperada, comparação de versões, auditoria e manifesto de integridade.

Os números descrevem itens de estudo, não habilidades instaladas, intenções totalmente distintas, percursos exaustivos ou testes já executados. Os JSON/JSONL são complementares; o conteúdo de estudo está em Markdown.

## Por onde começar
1. [Regras canônicas e precedência](00-REGRAS-CANONICAS-E-ORDEM-DE-LEITURA.md).
2. [Prompt principal](PROMPT-PRINCIPAL-DO-ATENDENTE.md).
3. [Playbook central novo](PLAYBOOK-CENTRAL-DO-ATENDIMENTO.md).
4. Negócio e comportamento nas pastas 01 e 02.
5. Personas, humanização e skills; depois respostas, fluxo, conversas e exercícios.
6. [Índice de todos os documentos](INDICE.md) ou [manual consolidado](MANUAL-CONSOLIDADO.md).
7. [Como entregar a outra IA](COMO-ENTREGAR-A-OUTRA-IA.md).

## Versão do fluxo
A referência mais recente entre as recuperadas é `FUNIL-ALAVANCAGEM-DE-VENDAS-V4 (1).lzb`, criado internamente em 23/10/2026 e disponibilizado no Drive em 25/10/2026. Os fluxos internos ainda estão em rascunho. A v.turbo aproveita o conhecimento e revisa o encaixe conversacional; não publica nem altera o backup.

## Livros e skills: distinção importante
O R4 cita `LIVROS-30-APLICADOS-FUNIL-R4.md`, mas esse catálogo original não foi recuperado. Os 15 arquivos de livros identificados no Drive não demonstram a seleção original de 30. As 39 fichas são sínteses autorais desta revisão, incluindo esses 15 títulos e 24 referências complementares. **Não são os 30 originais reconstruídos, leitura integral ou os PDFs completos.**

As antigas skills GitHub também não foram identificadas. Os sete arquivos públicos consultados são complementos novos, claramente documentados, não substituição silenciosa das fontes antigas.

## Regras mais importantes
Oferta ampla, com conteúdo e gestão além de anúncios; personalização por veículo; valores/condições com Lizandro; dúvida respondida antes de qualificação; sem repetição, promessa ou origem inventada; texto é caminho válido; recusa e parar respeitados; intenção não compreendida leva a **pausa silenciosa**; “ok” aguardando humano não reinicia.

## Limite honesto da entrega
É documentação pronta para estudo, consulta e avaliação. Não significa treinamento de pesos, execução em uma IA, atendimento real validado, homologação do aplicativo ou garantia de que alguém não reconhecerá automação. A revisão realizada e a integridade dos arquivos estão registradas na pasta 17.
