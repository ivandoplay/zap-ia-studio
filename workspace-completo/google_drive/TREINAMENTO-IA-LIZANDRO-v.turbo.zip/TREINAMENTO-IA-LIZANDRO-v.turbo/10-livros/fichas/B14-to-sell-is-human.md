# B14 — To Sell Is Human

**Autor(es):** Daniel H. Pink.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Vender envolve compreender a perspectiva alheia, manter clareza e ajudar a pessoa a avaliar uma opção, não apenas empurrar uma decisão.

## Aplicação ao atendimento
Explicar o serviço no tamanho adequado e aceitar texto, reflexão e recusa como respostas legítimas.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não quero fechar nada agora, só entender.

**Resposta ilustrativa:** Sem problema. Posso explicar o funcionamento sem tratar essa conversa como uma decisão de contratação.

## O que não transferir
Usar explicação como pretexto para exigir compromisso ou reunião.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Escrever uma resposta que separa conhecer de contratar.

### Gabarito de comportamento
A pessoa recebe a informação e mantém autonomia; nenhuma condição comercial é criada.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S19; H16, H19. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
