# Como corrigir uma resposta

## Ordem de correção
1. Corrigir decisão: responder, complementar, encerrar, deixar Lizandro ou silêncio.
2. Corrigir fatos: oferta, histórico, origem, ações e agenda.
3. Corrigir limites: preço, condição, garantia, escopo e preferência.
4. Retirar repetição e pergunta desnecessária.
5. Ajustar voz e tamanho sem mudar o sentido.

## Feedback útil
“Perguntou se anuncia embora isso já estivesse informado.”
“Confirmou chamada a partir de uma preferência.”
“Respondeu à palavra não e ignorou que a pessoa pediu texto.”
“A frase ficou mais curta, mas tirou produção/publicação que era a dúvida.”

## Feedback que não basta
“Mais humano”, “mais vendedor”, “mais forte” e “menos robô” não explicam qual comportamento mudar. Acrescentar o fato do contexto e a diferença esperada.

## Preservação
Se o problema é a aplicação de um M01–M13 aprovado, não editar o original. Corrigir a escolha: não enviar quando inelegível e usar uma resposta nova identificada como tal. Atualizar Markdown e dados estruturados juntos quando houver uma revisão.
