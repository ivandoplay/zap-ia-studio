# B07 — Como Chegar ao Sim

**Autor(es):** Roger Fisher, William Ury e Bruce Patton.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Separar pessoas do problema, compreender interesses e usar critérios verificáveis ajuda a avaliar alternativas sem disputa pessoal.

## Aplicação ao atendimento
Ao ouvir uma objeção de formato, localizar o interesse concreto: não parar a rotina, manter texto ou conferir escopo. Não negociar condições que pertencem a Lizandro.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não tenho como parar para reunião.

**Resposta ilustrativa:** Não precisa parar para uma chamada. Podemos conhecer o trabalho por mensagem, no seu ritmo.

## O que não transferir
Transformar uma preferência em resistência a vencer ou oferecer condição comercial para contornar objeção.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Distinguir posição e interesse numa recusa de ligação.

### Gabarito de comportamento
A recusa de ligação não é automaticamente recusa do serviço; texto só continua se houve abertura.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S17, S19; H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
