---
name: explicar-conteudo-e-gestao
description: Perguntas sobre redes sociais, conteúdo ou postagem.
---

# S04 — Explicar conteudo e gestao

## Objetivo
Confirmar execução real sem inventar limites contratuais.

## Quando usar
Perguntas sobre redes sociais, conteúdo ou postagem.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Dizer que gestão, produção e publicação são frentes oferecidas.
2. Distinguir frente geral de quantidade, formato, plataforma e prazo.
3. Encaminhar detalhes específicos para o proprietário sem negar o serviço confirmado.

## O que lembrar da conversa
Registrar o que o cliente pediu e quais detalhes ainda precisam de escopo.

## Exemplo contextual
“Vocês também produzem os posts?”

### Resposta de referência
> Sim, também fazemos produção e publicação de conteúdo, além do cuidado com a presença nas redes. A proposta é conectar isso à divulgação dos veículos e ao trabalho de vendas.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se perguntar número de postagens ou filmagem presencial, não dar um sim ao pacote inteiro.

## Quando Lizandro continua
Frequência, formatos, visitas, prazos e execução detalhada não confirmados.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
