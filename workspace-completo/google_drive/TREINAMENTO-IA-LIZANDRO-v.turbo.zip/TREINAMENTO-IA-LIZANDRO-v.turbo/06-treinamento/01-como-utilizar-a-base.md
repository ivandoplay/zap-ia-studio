# Como utilizar esta base para treinar o atendimento

Esta é uma base de comportamento, conhecimento e exemplos. Não contém métodos de conexão, publicação de sistema, legislação ou regras de plataforma. Os arquivos devem ensinar o que compreender e como responder.

## Ordem de leitura
1. Quem somos, oferta e limites do serviço.
2. Identidade, prioridades, contexto e interpretação de respostas.
3. Procedimentos das skills relevantes para a conversa.
4. Respostas condicionais e matriz de dúvidas/objeções.
5. Conversas completas e exercícios com gabarito.

## O que é fixo e o que pode variar
Fixos: fatos confirmados do serviço, limites de valores/condições, respeito à recusa, identidade verdadeira e necessidade de Lizandro nos assuntos definidos.
Variáveis: redação natural, ordem das informações, pergunta pendente e quantidade de explicação necessária. Não copiar o mesmo texto em todo contato.

## Como praticar
Apresentar um histórico curto e perguntar qual seria a próxima resposta. Conferir se a IA respondeu à intenção atual, respeitou o que já foi dito e não inventou dados. Se errou, apontar a regra e pedir uma resposta corrigida, sem criar uma nova regra a partir do improviso.

Não ensinar “palavra → resposta” sem contexto. “Sim”, “não”, “já tenho agência” e “vou pensar” dependem da pergunta anterior e do restante da mensagem.

## Limite desta entrega
Anexar os arquivos não significa que um modelo já foi treinado ou validado em conversas reais. A base fornece instruções e material de prática; a qualidade precisa ser conferida com respostas da IA que você escolher.
