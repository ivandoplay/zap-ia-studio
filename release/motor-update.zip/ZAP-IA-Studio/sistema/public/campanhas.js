// Interface experimental. Ela só cria rascunhos; início depende de confirmação explícita.
(() => {
'use strict';
const $=id=>document.getElementById(id), painel=$('tab-campanhas');if(!painel)return;
const ctx={campanhas:[],pastas:[],blocos:[],destinatarios:[],selecionada:null,editando:null,editStatus:null,carregando:false,listando:false,pagina:0,pastaPagina:0};
const tipos={rascunho:'Rascunho',ativa:'Em andamento',pausada:'Pausada',concluida:'Concluída'};
const criar=(tag,texto,classe)=>{const e=document.createElement(tag);if(texto!=null)e.textContent=texto;if(classe)e.className=classe;return e;};
const botao=(txt,fn,classe='btn btn-secondary btn-sm')=>{const b=criar('button',txt,classe);b.type='button';b.addEventListener('click',()=>Promise.resolve().then(fn).catch(erro));return b;};
const erro=e=>{showToast(e?.message||'Não foi possível concluir a operação.',true);};
const json=(url,method,body)=>api(url,{method,body:JSON.stringify(body)});
const limpar=e=>e.replaceChildren();
const input=(value,callback,opts={})=>{const e=document.createElement(opts.multiline?'textarea':'input');if(opts.multiline)e.rows=opts.rows||4;else e.type=opts.type||'text';e.value=value??'';if(opts.placeholder)e.placeholder=opts.placeholder;if(opts.maxLength)e.maxLength=opts.maxLength;if(opts.min!=null)e.min=opts.min;if(opts.max!=null)e.max=opts.max;e.addEventListener('input',()=>callback(e.value));return e;};
const selecao=(valor,opcoes,callback)=>{const e=criar('select');for(const [v,t] of opcoes){const o=criar('option',t);o.value=v;e.append(o);}e.value=valor;e.addEventListener('change',()=>callback(e.value));return e;};
const campo=(nome,elemento)=>{const l=criar('label',nome);l.append(elemento);return l;};
const id=()=>crypto.randomUUID();
function novoBloco(tipo){return tipo==='texto'?{id:id(),tipo,modo:'fixo',selecao:'sequencial',texto:'',original:'',prompt:'',quantidade:5,gerada:false,falhou:false}:{id:id(),tipo,pastaId:'',selecao:'sequencial',notaVoz:true};}
function blocosRender(){
 const container=$('campBlocos');limpar(container);
 ctx.blocos.forEach((b,i)=>{
  const card=criar('div',null,'camp-block'),head=criar('div',null,'camp-blockhead');head.append(criar('strong',`${i+1}. ${b.tipo==='texto'?'Texto':b.tipo==='imagem'?'Pasta de imagens':'Pasta de áudios'}`));
  const ops=criar('div',null,'camp-blockbuttons');const mover=delta=>{const j=i+delta;if(j<0||j>=ctx.blocos.length)return;[ctx.blocos[i],ctx.blocos[j]]=[ctx.blocos[j],ctx.blocos[i]];blocosRender();};
  const cima=botao('↑',()=>mover(-1)),baixo=botao('↓',()=>mover(1)),remover=botao('Excluir',()=>{ctx.blocos.splice(i,1);blocosRender();});cima.setAttribute('aria-label','Mover bloco para cima');baixo.setAttribute('aria-label','Mover bloco para baixo');cima.disabled=i===0;baixo.disabled=i===ctx.blocos.length-1;ops.append(cima,baixo,remover);head.append(ops);card.append(head);
  if(b.tipo==='texto'){
   const modo=selecao(b.modo,[['fixo','Texto fixo'],['spintax','Spintax {Olá|Oi}'],['rotacao','Rodízio de textos completos'],['ia','Variações com IA']],v=>{b.modo=v;blocosRender();});card.append(campo('Como variar o texto',modo));
   if(b.modo==='ia'){
    card.append(campo('Texto original',input(b.original,v=>{b.original=v;b.gerada=false;},{multiline:true,maxLength:5000})));
    const linha=criar('div',null,'camp-two');linha.append(campo('Quantidade de variações (1 a 20)',input(String(b.quantidade),v=>{b.quantidade=Number(v);b.gerada=false;},{type:'number',min:1,max:20})),campo('Instrução própria (opcional)',input(b.prompt,v=>{b.prompt=v;b.gerada=false;},{multiline:true,rows:2,maxLength:4000,placeholder:'Vazio usa apenas o prompt padrão do sistema.'})));card.append(linha);
    const gerar=botao('Gerar variações',async()=>{gerar.disabled=true;try{const r=await json('/api/campaigns/ai-variations','POST',{texto:b.original,quantidade:b.quantidade,prompt:b.prompt});if(!Array.isArray(r.variacoes))throw new Error('A IA não gerou variações válidas.');b.texto=r.variacoes.join('\n---\n');b.gerada=true;b.falhou=false;blocosRender();}catch(e){b.gerada=false;b.falhou=true;blocosRender();erro(e);}finally{gerar.disabled=false;}});card.append(gerar);
    if(b.falhou){const alerta=criar('p','Não foi possível gerar as variações. Tente novamente ou escolha usar o texto original.','camp-hint camp-error');card.append(alerta,botao('Usar texto original',()=>{b.modo='fixo';b.texto=b.original;b.falhou=false;blocosRender();}));}
    if(!b.gerada)card.append(criar('p','Gere as variações antes de salvar; você poderá revisá-las e editá-las.','camp-hint'));
   }
   const multiplos=b.modo==='rotacao'||b.modo==='ia';
   if(b.modo!=='ia'||b.gerada){card.append(campo(multiplos?'Textos completos (separe com uma linha contendo ---)':'Mensagem',input(b.texto,v=>{b.texto=v;},{multiline:true,rows:5,placeholder:b.modo==='spintax'?'{Olá|Oi}, {{nome}}!':'Escreva sua mensagem…'})));}
   if(multiplos)card.append(campo('Escolha dos textos',selecao(b.selecao,[['sequencial','Rodízio sequencial'],['aleatorio','Sorteio']],v=>{b.selecao=v;})));
  }else{
   const disponiveis=ctx.pastas.filter(p=>p.tipo===b.tipo).map(p=>[p.pasta_id,p.nome]);card.append(campo('Pasta',selecao(b.pastaId,[['','Selecione uma pasta'],...disponiveis],v=>{b.pastaId=v;})));
   const linha=criar('div',null,'camp-two');linha.append(campo('Escolha do arquivo',selecao(b.selecao,[['sequencial','Rodízio sequencial'],['aleatorio','Sorteio']],v=>{b.selecao=v;})));
   if(b.tipo==='audio')linha.append(campo('Formato de envio',selecao(b.notaVoz?'voz':'anexo',[['voz','Nota de voz'],['anexo','Arquivo anexo']],v=>{b.notaVoz=v==='voz';})));card.append(linha);
  }
  container.append(card);
 });
 if(!ctx.blocos.length)container.append(criar('p','Adicione ao menos um bloco.','camp-hint'));
}
function blocoParaPlano(b){if(b.tipo==='texto'){if(b.modo==='ia'&&!b.gerada)throw new Error('Gere ou use o texto original antes de salvar.');const textos=['rotacao','ia'].includes(b.modo)?b.texto.split(/\r?\n---\r?\n/).map(x=>x.trim()).filter(Boolean):[b.texto.trim()];if(!textos.length||textos.some(x=>!x)||textos.length>20)throw new Error('Confira os textos: use de 1 a 20 versões não vazias.');return {id:b.id,tipo:'texto',modo:b.modo,textos,...(['rotacao','ia'].includes(b.modo)?{selecao:b.selecao}:{})};}if(!b.pastaId)throw new Error('Selecione uma pasta para cada bloco de mídia.');return {id:b.id,tipo:b.tipo,pastaId:b.pastaId,selecao:b.selecao,...(b.tipo==='audio'?{notaVoz:b.notaVoz}:{})};}
// Pausar/retomar direto no card. Usa o MESMO endpoint do detalhe (/control),
// para não existir dois caminhos de controle com regras diferentes.
async function controleRapido(campanhaId,acao){
 const aviso=acao==='retomar'?'Retomar os próximos envios desta campanha?':'Pausar os envios desta campanha agora?';
 if(!confirm(aviso))return;
 await json(`/api/campaigns/${campanhaId}/control`,'POST',{acao});
 await atualizar();
 showToast(acao==='retomar'?'Campanha retomada.':'Campanha pausada.');
}
function listarRender(){const list=$('campLista');limpar(list);if(!ctx.campanhas.length){list.append(criar('div','Nenhuma campanha criada ainda.','camp-empty'));return;}
 for(const c of ctx.campanhas){
  // o card virou <div> com dois botões irmãos: um abre o detalhe, o outro controla
  const row=criar('div','','camp-card');
  row.setAttribute('aria-current',String(ctx.selecionada===c.campanha_id));
  row.dataset.status=c.status;
  const abrir=botao('',()=>detalhe(c.campanha_id),'camp-card-abrir');
  abrir.setAttribute('aria-label','Abrir detalhes de '+c.nome);
  const col=criar('span');
  col.append(criar('strong',c.nome),criar('small',c.status==='ativa'?'Próxima ação: '+new Date(c.proxima_acao_em).toLocaleString('pt-BR'):'Clique para ver detalhes'));
  abrir.append(col);
  row.append(abrir,criar('span',tipos[c.status]||c.status,'camp-badge'));
  if(c.status==='ativa'){const b=botao('Pausar',()=>controleRapido(c.campanha_id,'pausar'),'btn btn-secondary btn-sm camp-card-acao');b.setAttribute('aria-label','Pausar '+c.nome);row.append(b);}
  if(c.status==='pausada'){const b=botao('Retomar',()=>controleRapido(c.campanha_id,'retomar'),'btn btn-primary btn-sm camp-card-acao');b.setAttribute('aria-label','Retomar '+c.nome);row.append(b);}
  list.append(row);
 }}
async function atualizar(){
 if(ctx.carregando)return;
 ctx.carregando=true;
 try{
  const d=await api('/api/campaigns');
  ctx.campanhas=d.campanhas;
  listarRender();
  if(ctx.selecionada)await detalhe(ctx.selecionada);
 }catch(err){
  const list=$('campLista');
  if(list&&(!Array.isArray(ctx.campanhas)||!ctx.campanhas.length)){
   limpar(list);
   list.append(criar('div',err?.message||'Não foi possível carregar as campanhas agora.','camp-empty'));
  }
  throw err;
 }finally{
  ctx.carregando=false;
 }
}
function contador(){for(const x of painel.querySelectorAll('[data-camp-tempo]')){const seconds=Math.max(0,Math.ceil((Number(x.dataset.campTempo)-Date.now())/1000));const h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;x.textContent=seconds?`${h?`${h}h `:''}${m}min ${String(s).padStart(2,'0')}s`:'Pronta para a próxima ação';}}
async function detalhe(campanhaId){
 const d=await api(`/api/campaigns/${encodeURIComponent(campanhaId)}`);if(ctx.selecionada!==campanhaId){ctx.listando=false;ctx.pagina=0;}ctx.selecionada=campanhaId;listarRender();const area=$('campDetalhe');limpar(area);const c=d.campanha,r=d.resumo;
 const head=criar('div',null,'camp-heading'),titulo=criar('div');titulo.append(criar('h2',c.nome),criar('p',tipos[c.status]||c.status));head.append(titulo,criar('span',tipos[c.status]||c.status,'camp-badge'));area.append(head);
 const metrics=criar('div',null,'camp-metrics');for(const [valor,legenda] of [[r.total,'Pessoas'],[r.concluidos,'Sequências concluídas'],[r.incertos,'A conferir'],[r.excluidos,'Removidas']]){const m=criar('div',null,'camp-metric');m.append(criar('strong',String(valor??0)),criar('span',legenda));metrics.append(m);}area.append(metrics,criar('p','Conclusão indica aceite pelo motor, não garante entrega ou leitura.','camp-hint'));
 if(c.status==='ativa'&&d.proxima_acao_estimada_em){const p=criar('p','Próxima ação estimada em: ','camp-hint');const t=criar('strong');t.dataset.campTempo=String(Date.parse(d.proxima_acao_estimada_em));p.append(t);area.append(p,criar('p','Estimativa depende do chip conectado e da disponibilidade do motor.','camp-hint'));contador();}
 if(c.status==='pausada'&&c.falha_codigo){const mensagens={contato_restrito:'A próxima pessoa já está marcada como ignorada ou pertence aos seus próprios chips. Confira a lista e remova-a manualmente se necessário.',campos:'Falta uma coluna usada em um texto para a próxima pessoa. Corrija o texto ou a lista antes de retomar.',preparacao:'Não foi possível preparar a próxima etapa. Confira mídia, conexão e configuração antes de retomar.',chip_indisponivel:'O chip escolhido está desconectado. Conecte exatamente esse chip e retome a campanha; não houve troca automática para outro número.',chip_provedor_ambiguo:'O mesmo chip aparece conectado por Baileys e Evolution. Desconecte um dos provedores e retome após conferir o número.'};const aviso=criar('div',null,'camp-review');aviso.append(criar('strong','Campanha pausada para conferência'),criar('p',mensagens[c.falha_codigo]||mensagens.preparacao));if(d.pendente)aviso.append(criar('p',`Próxima pessoa: ${d.pendente.nome||'Sem nome'} · +${d.pendente.telefone} · bloco ${d.pendente.etapa+1}`));area.append(aviso);}
 const actions=criar('div',null,'camp-actions');
 const controlar=async(acao)=>{if(acao==='iniciar'&&!confirm('Iniciar esta campanha com os destinatários e blocos configurados?'))return;if(acao==='retomar'&&!confirm('Retomar os próximos envios desta campanha?'))return;await json(`/api/campaigns/${campanhaId}/control`,'POST',{acao});await atualizar();};
 if(c.status==='rascunho')actions.append(botao('Iniciar campanha',()=>controlar('iniciar'),'btn btn-primary btn-sm'));
 if(c.status==='ativa')actions.append(botao('Pausar',()=>controlar('pausar')));
 if(c.status==='pausada'&&!d.revisao)actions.append(botao('Retomar',()=>controlar('retomar'),'btn btn-primary btn-sm'));
 if(['ativa','pausada'].includes(c.status)&&['pessoa','lote'].includes(c.pausa_tipo)&&Date.parse(c.proxima_acao_em)>Date.now())actions.append(botao('Pular esta pausa',()=>controlar('pular')));
 if(c.status!=='concluida')actions.append(botao('Editar',()=>editar(c)));actions.append(botao(ctx.listando?'Ocultar destinatários':'Ver destinatários',async()=>{ctx.listando=!ctx.listando;ctx.pagina=0;await detalhe(campanhaId);}));area.append(actions);
 if(d.revisao){const x=d.revisao,box=criar('div',null,'camp-review');box.append(criar('strong',x.status==='incerta'?'Envio precisa de conferência':'Envio em andamento'));const pessoa=x.destinatario.nome?`${x.destinatario.nome} · +${x.destinatario.telefone}`:`+${x.destinatario.telefone}`;box.append(criar('p',`Pessoa: ${pessoa} · bloco ${x.etapa+1} · ${x.material?.slotId||''}`));
  if(x.material?.bloco?.tipo==='texto')box.append(criar('code',String(x.material.bloco.texto||'')));
  if(x.status==='incerta'){
   box.append(criar('p','A resposta do WhatsApp foi inconclusiva; o envio anterior pode até terminar depois desta mensagem. Confira a conversa no chip e aguarde antes de decidir. Marcar como não enviada pode causar duplicidade.'));
   const a=criar('div',null,'camp-actions');const resolver=async decisao=>{const aviso=decisao==='confirmada'?'Você conferiu a conversa e confirmou que esta etapa foi enviada?':'Você conferiu a conversa e tem certeza de que esta etapa não foi enviada? Após retomar, ela poderá ser enviada novamente.';if(!confirm(aviso))return;await json(`/api/campaigns/${campanhaId}/resolve`,'POST',{destinatarioId:x.destinatario_id,etapa:x.etapa,tentativaId:x.tentativa_id,decisao,conferi:true});await atualizar();};
   a.append(botao('Conferi: foi enviada',()=>resolver('confirmada')),botao('Conferi: não foi enviada',()=>resolver('nao_enviada')));box.append(a);
  }else box.append(criar('p','Aguarde o término. Uma operação ainda em andamento não deve ser reenviada.'));area.append(box);
 }
 if(ctx.listando)await destinatarios(campanhaId,area);
}
async function destinatarios(campanhaId,area){
 const inicio=ctx.pagina*50,r=await api(`/api/campaigns/${encodeURIComponent(campanhaId)}/recipients?inicio=${inicio}`);if(ctx.selecionada!==campanhaId||!area.isConnected)return;
 const box=criar('div',null,'camp-block');box.append(criar('strong','Destinatários'),criar('p','Remova manualmente as próximas etapas de uma pessoa. Envios já iniciados ou confirmados não são desfeitos.','camp-hint'));
 for(const pessoa of r.destinatarios){const row=criar('div',null,'camp-recipient');const label=criar('span',`${pessoa.nome||'Sem nome'} · +${pessoa.telefone}`);row.append(label);
  if(pessoa.pode_excluir)row.append(botao('Remover',async()=>{if(!confirm(`Remover ${pessoa.nome||'esta pessoa'} desta campanha? Ela não receberá as etapas ainda não iniciadas.`))return;await json(`/api/campaigns/${campanhaId}/recipients/${pessoa.destinatario_id}/remove`,'POST',{confirmo:true});await atualizar();}));else row.append(criar('small',pessoa.excluido?'Removida':'Em envio ou concluída'));box.append(row);}
 if(!r.destinatarios.length)box.append(criar('p','Nenhuma pessoa nesta página.','camp-hint'));
 const nav=criar('div',null,'camp-actions');if(ctx.pagina>0)nav.append(botao('Anterior',async()=>{ctx.pagina--;await detalhe(campanhaId);}));if(r.destinatarios.length===50&&inicio<9950)nav.append(botao('Próxima página',async()=>{ctx.pagina++;await detalhe(campanhaId);}));box.append(nav);area.append(box);
}
async function pastas(){const r=await api('/api/campaigns/folders');ctx.pastas=r.pastas;const sel=$('campPastaSelecionada'),anterior=sel.value;limpar(sel);sel.append(new Option('Selecione uma pasta',''));for(const p of ctx.pastas)sel.append(new Option(`${p.nome} · ${p.tipo==='imagem'?'imagens':'áudios'}`,p.pasta_id));sel.value=anterior;blocosRender();}
async function arquivosDaPasta(){const pasta=$('campPastaSelecionada').value,area=$('campPastaConteudo');limpar(area);if(!pasta)return;const inicio=ctx.pastaPagina*100,r=await api(`/api/campaigns/folders/${pasta}/files?inicio=${inicio}`);area.append(criar('p',`${r.arquivos.length} arquivo(s) nesta página.`));if(r.arquivos.length){const ul=criar('ul');for(const f of r.arquivos){const li=criar('li');li.append(criar('span',`${f.nome_original||'Arquivo'} · ${f.mime||'mídia'} · ${Math.ceil((f.tamanho||0)/1024)} KB${f.excluindo?' · exclusão pendente':''}`));li.append(botao(f.excluindo?'Concluir exclusão':'Excluir arquivo',async()=>{if(!confirm('Excluir este arquivo? Campanhas que usam a pasta podem parar se ela ficar sem arquivos.'))return;await json(`/api/campaigns/files/${f.arquivo_id}/delete`,'POST',{confirmo:true});await arquivosDaPasta();showToast('Arquivo excluído.');}));ul.append(li);}area.append(ul);}const nav=criar('div',null,'camp-actions');if(ctx.pastaPagina>0)nav.append(botao('Arquivos anteriores',async()=>{ctx.pastaPagina--;await arquivosDaPasta();}));if(r.arquivos.length===100&&inicio<9900)nav.append(botao('Próximos arquivos',async()=>{ctx.pastaPagina++;await arquivosDaPasta();}));area.append(nav);}
function resetEditor(){ctx.editando=null;ctx.editStatus=null;ctx.destinatarios=[];ctx.blocos=[novoBloco('texto')];$('campFormulario').reset();$('campInicioEm').disabled=false;$('campImportacao').hidden=false;$('campEdicaoAviso').hidden=true;$('campEditorTitulo').textContent='Nova campanha';$('campSalvar').textContent='Salvar rascunho';$('campImportarStatus').textContent='Nenhuma lista conferida.';limpar($('campAmostra'));$('campEditorStatus').textContent='';blocosRender();}
function abrir(){resetEditor();$('campEditor').hidden=false;$('campEditor').scrollIntoView({behavior:'smooth',block:'start'});$('campNome').focus();}
function editar(c){resetEditor();ctx.editando=c.campanha_id;ctx.editStatus=c.status;$('campInicioEm').disabled=c.status!=='rascunho';if(c.status==='rascunho'&&Date.parse(c.proxima_acao_em)>Date.now()){const d=new Date(c.proxima_acao_em);$('campInicioEm').value=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);}$('campImportacao').hidden=true;$('campEdicaoAviso').hidden=false;$('campEditorTitulo').textContent='Editar campanha';$('campSalvar').textContent='Salvar alterações';$('campNome').value=c.plano.nome;$('campModoChips').value=c.plano.modoChips;$('campRetomada').value=c.plano.retomada;for(const e of $('campChips').querySelectorAll('input'))e.checked=c.plano.chips.includes(e.value);
 ctx.blocos=c.plano.blocos.map(b=>b.tipo==='texto'?{...b,texto:b.textos.join('\n---\n'),original:b.textos[0],prompt:'',quantidade:b.textos.length,gerada:b.modo==='ia',falhou:false}:{...b});
 for(const [id,key,div] of [['campPessoaMin','intervalo_min_ms',1000],['campPessoaMax','intervalo_max_ms',1000],['campLoteMin','lote_min',1],['campLoteMax','lote_max',1],['campPausaMin','pausa_lote_min_ms',1000],['campPausaMax','pausa_lote_max_ms',1000],['campEtapa','intervalo_etapas_ms',1000]])$(id).value=Number(c[key])/div;
 $('campRestrito').checked=c.restricao_horaria;$('campFuso').value=c.fuso;$('campInicio').value=String(c.inicio).slice(0,5);$('campFim').value=String(c.fim).slice(0,5);for(const e of $('campDias').querySelectorAll('input'))e.checked=c.dias.includes(Number(e.value));blocosRender();$('campEditor').hidden=false;$('campEditor').scrollIntoView({behavior:'smooth',block:'start'});$('campNome').focus();}
$('campNova').addEventListener('click',abrir);$('campFechar').addEventListener('click',()=>$('campEditor').hidden=true);$('campCancelar').addEventListener('click',()=>$('campEditor').hidden=true);$('campAtualizar').addEventListener('click',()=>atualizar().catch(erro));
for(const tipo of ['Texto','Imagem','Audio'])$('campAdicionar'+tipo).addEventListener('click',()=>{ctx.blocos.push(novoBloco(tipo.toLowerCase()));blocosRender();});
$('campImportar').addEventListener('click',async()=>{try{const file=$('campArquivo').files[0],texto=$('campNumeros').value.trim();if(file&&texto)throw new Error('Use o arquivo ou a lista colada, não os dois ao mesmo tempo.');let r;if(file){if(file.size>4*1024*1024)throw new Error('O arquivo de lista pode ter no máximo 4 MB.');const form=new FormData();form.append('file',file);form.append('separador',$('campSeparador').value);r=await api('/api/campaigns/import-preview',{method:'POST',body:form});}else{if(!texto)throw new Error('Cole números ou escolha um arquivo.');r=await json('/api/campaigns/import-preview','POST',{texto,formato:'txt'});}ctx.destinatarios=r.destinatarios;const amostra=$('campAmostra');limpar(amostra);if(ctx.destinatarios.length){amostra.append(criar('strong','Amostra dos destinatários importados'));const ul=criar('ul');for(const d of ctx.destinatarios.slice(0,5)){const extra=Object.entries(d.campos||{}).map(([k,v])=>`${k}: ${v}`).join(' · ');ul.append(criar('li',`${d.nome||'Sem nome'} · +${d.telefone}${extra?' · '+extra:''}`));}amostra.append(ul);}const problemas=r.problemas||[];$('campImportarStatus').textContent=`${ctx.destinatarios.length} número(s) válido(s); ${problemas.length} linha(s) inválida(s) ou duplicada(s) foram ignoradas.${problemas.length?' Linhas: '+problemas.slice(0,20).map(p=>p.linha).join(', '):''}`;}catch(e){ctx.destinatarios=[];limpar($('campAmostra'));$('campImportarStatus').textContent='Nenhuma lista válida conferida.';erro(e);}});
$('campNumeros').addEventListener('input',()=>{ctx.destinatarios=[];limpar($('campAmostra'));$('campImportarStatus').textContent='A lista mudou. Confira os destinatários novamente.';});$('campArquivo').addEventListener('change',()=>{ctx.destinatarios=[];limpar($('campAmostra'));$('campImportarStatus').textContent='O arquivo mudou. Confira os destinatários novamente.';});$('campSeparador').addEventListener('change',()=>{ctx.destinatarios=[];limpar($('campAmostra'));$('campImportarStatus').textContent='O separador mudou. Confira os destinatários novamente.';});
$('campFormulario').addEventListener('submit',async e=>{e.preventDefault();const btn=$('campSalvar');btn.disabled=true;try{const chips=[...$('campChips').querySelectorAll('input:checked')].map(x=>x.value),modoChips=$('campModoChips').value;if(!chips.length||(modoChips==='fixo'&&chips.length!==1))throw new Error('Para chip fixo, escolha exatamente um chip. Para rodízio, escolha ao menos um.');if(!ctx.blocos.length)throw new Error('Adicione ao menos um bloco.');if(!ctx.editando&&!ctx.destinatarios.length)throw new Error('Confira uma lista com pelo menos um destinatário.');
 const plano={nome:$('campNome').value.trim(),chips,modoChips,retomada:$('campRetomada').value,blocos:ctx.blocos.map(blocoParaPlano)};
 const n=id=>Number($(id).value),dias=[...$('campDias').querySelectorAll('input:checked')].map(x=>Number(x.value));const opcoes={intervalo_min_ms:n('campPessoaMin')*1000,intervalo_max_ms:n('campPessoaMax')*1000,lote_min:n('campLoteMin'),lote_max:n('campLoteMax'),pausa_lote_min_ms:n('campPausaMin')*1000,pausa_lote_max_ms:n('campPausaMax')*1000,intervalo_etapas_ms:n('campEtapa')*1000,restricao_horaria:$('campRestrito').checked,fuso:$('campFuso').value.trim(),dias,inicio:$('campInicio').value,fim:$('campFim').value};if($('campInicioEm').value&&!$('campInicioEm').disabled)opcoes.inicio_em=new Date($('campInicioEm').value).toISOString();else if(ctx.editando&&ctx.editStatus==='rascunho')opcoes.inicio_em=new Date().toISOString();
 const edicao=ctx.editando;const r=await json(edicao?`/api/campaigns/${edicao}`:'/api/campaigns',edicao?'PUT':'POST',{plano,opcoes,...(!edicao?{destinatarios:ctx.destinatarios}:{})});$('campEditor').hidden=true;ctx.selecionada=r.campanha.campanha_id;showToast(edicao?'Alterações salvas para etapas ainda não iniciadas.':'Rascunho salvo. Revise antes de iniciar.');await atualizar();}catch(err){$('campEditorStatus').textContent=err.message;erro(err);}finally{btn.disabled=false;}});
$('campPastaCriar').addEventListener('click',async()=>{try{const nome=$('campPastaNome').value.trim(),tipo=$('campPastaTipo').value;if(!nome)throw new Error('Informe o nome da pasta.');const r=await json('/api/campaigns/folders','POST',{nome,tipo});$('campPastaNome').value='';await pastas();$('campPastaSelecionada').value=r.pasta.pasta_id;ctx.pastaPagina=0;await arquivosDaPasta();showToast('Pasta criada.');}catch(e){erro(e);}});
$('campPastaSelecionada').addEventListener('change',()=>{ctx.pastaPagina=0;arquivosDaPasta().catch(erro);});
$('campPastaEnviar').addEventListener('click',async()=>{const btn=$('campPastaEnviar');btn.disabled=true;try{const pasta=$('campPastaSelecionada').value,files=[...$('campPastaArquivos').files];if(!pasta||!files.length)throw new Error('Escolha uma pasta e ao menos um arquivo.');for(let i=0;i<files.length;i++){const f=files[i];$('campPastaStatus').textContent=`Enviando arquivo ${i+1} de ${files.length}…`;const r=await json(`/api/campaigns/folders/${pasta}/upload-init`,'POST',{tamanho:f.size});const up=await fetch(r.upload.signedUrl,{method:'PUT',headers:{'Content-Type':f.type||'application/octet-stream','x-upsert':'false'},body:f,redirect:'error'});if(!up.ok)throw new Error('Não foi possível enviar o arquivo para o armazenamento.');await json(`/api/campaigns/folders/${pasta}/upload-finalize`,'POST',{arquivoId:r.upload.arquivoId,nome:f.name});}$('campPastaArquivos').value='';$('campPastaStatus').textContent='Arquivos adicionados com sucesso.';await arquivosDaPasta();}catch(e){$('campPastaStatus').textContent='Envio interrompido. Os arquivos anteriores já concluídos foram preservados.';erro(e);}finally{btn.disabled=false;}});
let ultima=0;window.carregarCampanhas=async()=>{if(Date.now()-ultima<3000)return;ultima=Date.now();try{await Promise.all([atualizar(),pastas()]);}catch(e){erro(e);}};
setInterval(()=>{if(painel.classList.contains('active')){contador();if(document.visibilityState==='visible'&&Date.now()-ultima>15000){ultima=Date.now();atualizar().catch(()=>{});}}},1000);
})();
