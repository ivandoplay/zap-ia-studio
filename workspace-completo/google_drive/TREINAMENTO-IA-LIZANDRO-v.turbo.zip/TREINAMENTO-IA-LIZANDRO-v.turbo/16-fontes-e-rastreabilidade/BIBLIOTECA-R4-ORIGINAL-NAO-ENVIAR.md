# Biblioteca textual R4 recuperada — somente referência histórica

**NÃO USAR ESTE ARQUIVO COMO PROMPT OU SEQUÊNCIA AUTOMÁTICA.** São as variantes do backup mais recente recuperado, preservadas para rastreabilidade. Não são os M01–M13 aprovados do usuário. Algumas falas dependem de origem, ação, disponibilidade ou escopo que não estão confirmados; consultar a auditoria e as regras atuais. Os rascunhos de autoria anterior não ganham aprovação por estarem aqui.

## R4.M01 | Apresentação + permissão (otimizada)

Identificador na fonte: `msg-M01`. Papel neste pacote: histórico, não instrução.

```text
Opa, tudo bem meu amigo? Aqui é da Alavancagem de Vendas, peguei seu contato no Google Maps.
```

## R4.M01b | Apresentação + permissão (otimizada) (bolha 2 de 2)

Identificador na fonte: `msg-M01b`. Papel neste pacote: histórico, não instrução.

```text
tô com uma estratégia aqui que é a cara de loja de veículo. Dei uma olhada no seu perfil e dá pra aumentar bem suas vendas sem depender só de indicação. Posso te falar mais sobre?
```

## R4.M02 | Apresentação + pergunta de cenário (otimizada)

Identificador na fonte: `msg-M02`. Papel neste pacote: histórico, não instrução.

```text
Então, a gente não é agência não. Trabalhamos só com loja de veículo, tá bom? Seu carro na frente de quem já quer comprar, e quando a pessoa chama no zap, a conversa não esfria.
```

## R4.M02b | Apresentação + pergunta de cenário (otimizada) (bolha 2 de 2)

Identificador na fonte: `msg-M02b`. Papel neste pacote: histórico, não instrução.

```text
Como eu sempre digo, é ofertar o produto certo pra pessoa certa. Me diz uma coisa, porque isso aqui decide o caminho. Hoje aperta mais chegar cliente na loja, ou fechar com quem já te chama?
```

## R4.M03 | Já investe em anúncios → volume (otimizada)

Identificador na fonte: `msg-M03`. Papel neste pacote: histórico, não instrução.

```text
Anúncio rodando já é meio caminho andado, tá bom. A diferença mora no depois, como o anúncio é feito e o que acontece quando a pessoa chama. Trazer gente é metade, fechar é a outra.
Me diz uma coisa pra eu entender teu momento sem tomar teu tempo. Hoje, em média, quantos carros vocês vendem por mês?
```

## R4.M04 | Nunca investiu / depende de indicação (otimizada)

Identificador na fonte: `msg-M04`. Papel neste pacote: histórico, não instrução.

```text
Depender só de indicação e do movimento da rua deixa a venda na mão da sorte, tá bom. Não que indicação seja ruim, é ótima, só que ela não depende de você. Com divulgação direcionada dá pra colocar seus carros na frente de quem tá procurando, todo dia.
Deixa eu te explicar rapidinho como funciona. Se você achar que não é pra tua loja, me dispensa.
```

## R4.M05 | Tipo de negócio (mantida)

Identificador na fonte: `msg-M05`. Papel neste pacote: histórico, não instrução.

```text
Certo. E me diz uma coisa, você toca uma loja de veículos ou vende por conta própria, tipo autônomo?
```

## R4.M06 | Convite 15 minutos — confiança de processo (otimizada)

Identificador na fonte: `msg-M06`. Papel neste pacote: histórico, não instrução.

```text
Olha, com o que você me contou já dá pra ter uma boa ideia do que fazer no seu caso. Me dá 15 minutinhos pra eu te mostrar direitinho?
```

## R4.M06b | Convite 15 minutos — confiança de processo (otimizada) (bolha 2 de 2)

Identificador na fonte: `msg-M06b`. Papel neste pacote: histórico, não instrução.

```text
Pode ser uma chamada rápida ou a gente segue por aqui no zap, como ficar melhor pra você. Você sai sabendo o que vale a pena fazer, fechando ou não com a gente.
```

## R4.M07 | Escolheu ligação — pedir dia/horário (mantida)

Identificador na fonte: `msg-M07`. Papel neste pacote: histórico, não instrução.

```text
Combinado então, chamada é rapidinho mesmo 📞 Que dia e horário fica melhor pra você? Se facilitar, responde só tipo amanhã às 15h ou sexta-feira, do jeito que ficar mais fácil.
```

## R4.M08 | Escolheu WhatsApp — aceitação do canal (mantida, leve ajuste)

Identificador na fonte: `msg-M08`. Papel neste pacote: histórico, não instrução.

```text
Fechado, por aqui então. Você responde no seu tempo, sem precisar parar o que tá fazendo. Na sequência eu já te mostro como funciona pro seu caso, direto ao ponto.
```

## R4.M09 | Investimento — resposta pessoal (manual, otimizada) [MANUAL]

Identificador na fonte: `msg-M09`. Papel neste pacote: histórico, não instrução.

```text
O investimento depende do cenário de cada negócio, volume, o que você já faz de divulgação, onde quer chegar. Por isso eu prefiro te responder com número certo a chutar um valor por mensagem, tá bom.
Me conta uma coisa pra eu chegar nesse cenário. Hoje, do jeito que você vende, quantos carros saem por mês em média?
```

## R4.M10 | Retomada de conversa por silêncio (manual, otimizada) [MANUAL]

Identificador na fonte: `msg-M10`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Sei que o dia de quem vende carro é corrido, mensagem fica pra depois mesmo, sem problema. Reli aqui o que a gente conversou e dá pra alavancar isso aí, essa eu assino embaixo.
Bora retomar de onde a gente parou, ou prefere que eu deixe quieto por enquanto?
```

## R4.M11 | Quem é você — com origem Google Maps comprovada (mantida)

Identificador na fonte: `msg-M11`. Papel neste pacote: histórico, não instrução.

```text
Aqui é da Alavancagem de Vendas, tá bom. A gente trabalha com estratégia de marketing e vendas pro mercado de veículos, ajudando lojista e vendedor a chegar mais cliente e vender mais. Achei o contato da sua empresa no Google Maps e te chamei porque vi que tem tudo a ver com o que a gente faz, e porque acredito que pode te ajudar a vender mais.
```

## R4.M12 | Gancho de curiosidade — future pacing (reposicionada para o caminho PRINCIPAL)

Identificador na fonte: `msg-M12`. Papel neste pacote: histórico, não instrução.

```text
Já que a gente tá conversando aqui, pensa comigo numa hipótese, só pra medir o tamanho da coisa. Se todo dia chegassem de duas a cinco pessoas querendo os carros que você tem no estoque, o que isso mudaria no seu fim de mês?
É hipótese pra pensar junto, não é promessa. Mas é exatamente esse tipo de conta que a gente olha primeiro.
```

## R4.M13 | Explicação da estratégia + convite (otimizada com double bind)

Identificador na fonte: `msg-M13`. Papel neste pacote: histórico, não instrução.

```text
É exatamente aí que a gente entra, tá bom. Divulgação certa e atendimento que não deixa o lead esfriar, pra atrair gente querendo o que já tem no estoque, sem depender da sorte.
Se quiser, a gente conversa uns 15 minutinhos pra eu entender teu negócio e te mostrar como aplicar. Você já sai sabendo se vale a pena, mesmo que não feche nada. Fica melhor uma ligação ou continuamos por aqui?
```

## R4.M14 | Estratégia em 3 frentes — formatada para WhatsApp

Identificador na fonte: `msg-M14`. Papel neste pacote: histórico, não instrução.

```text
São três frentes juntas, porque anúncio sozinho não fecha venda.
1. Anúncio direcionado, seu carro na frente de quem tá procurando de verdade.
2. Conversa de venda no zap, pra cliente não esfriar no meio do papo.
3. Acompanhamento de quem ainda não decidiu, porque muita gente compra depois, mas só de quem não sumiu.
Sem prometer que todo mundo que chama vai comprar, mas sem deixar oportunidade sem toque.
```

## R4.M15 | Diagnóstico — localizar o gargalo (mantida)

Identificador na fonte: `msg-M15`. Papel neste pacote: histórico, não instrução.

```text
Pra eu ligar isso ao que você realmente precisa, e não te empurrar o que não resolve, me diz uma coisa, hoje pesa mais chegar cliente novo, ou transformar em comprador quem já te chama?
```

## R4.M16 | Gargalo captação — espelhamento + pergunta de canais

Identificador na fonte: `msg-M16`. Papel neste pacote: histórico, não instrução.

```text
Então, seu jogo é fazer chegar mais cliente na loja, né? Isso tem jeito. Me diz uma coisa, hoje seus clientes chegam mais por onde, Instagram, indicação, ou o povo que passa na frente?
```

## R4.M17 | Gargalo fechamento — perda real sem acusar

Identificador na fonte: `msg-M17`. Papel neste pacote: histórico, não instrução.

```text
Entendi. E olha, é aí que mais loja perde venda, o povo chama, a conversa esfria e o cliente acaba comprando em outro lugar. Me diz uma coisa, quem atende hoje quando alguém chama, você mesmo ou alguém da equipe?
```

## R4.M18 | Qualificação — anúncios atuais (assistida) [ASSISTIDA]

Identificador na fonte: `msg-M18`. Papel neste pacote: histórico, não instrução.

```text
Me conta uma coisa pra eu não te tratar como todo mundo, hoje vocês já usam anúncio pago pra divulgar os carros, ou trabalham mais com outras formas de divulgação?
```

## R4.M19 | Vou pensar — descobrir a dúvida + saída M91

Identificador na fonte: `msg-M19`. Papel neste pacote: histórico, não instrução.

```text
Decisão boa é decisão sem pressa, fica à vontade pra avaliar. Parece que ainda tem algum ponto em aberto aí do seu lado. Quero te ajudar com o que importa de verdade, não te encher de informação genérica. O que ficou de dúvida ou o que você quer entender melhor?
```

## R4.M20 | Utilidade do diagnóstico — risk reversal

Identificador na fonte: `msg-M20`. Papel neste pacote: histórico, não instrução.

```text
Essa conversa de 15 minutos é um diagnóstico, não é apresentação de venda, tá bom. A gente olha como você atrai cliente hoje, onde as conversas tão escapando e se tem espaço real pra melhorar. E te digo mais, se eu perceber que não é pro seu negócio, eu sou o primeiro a te falar. Prefiro perder uma venda a te empurrar o que não serve.
Faz sentido a gente olhar isso junto?
```

## R4.M21 | Investimento — handoff humano sem fourth wall

Identificador na fonte: `msg-M21`. Papel neste pacote: histórico, não instrução.

```text
Olha, valor eu não te passo por aqui não, porque cada caso é um caso e chute por mensagem não vale nada. Já te coloco com o responsável daqui e ele te chama nessa mesma conversa, tá bom?
```

## R4.M21b | Investimento — handoff humano sem fourth wall (bolha 2 de 2)

Identificador na fonte: `msg-M21b`. Papel neste pacote: histórico, não instrução.

```text
Se quiser adiantar, me diz uma coisa, quantos carros você vende por mês, mais ou menos?
```

## R4.M22 | Desinteresse — encerrar sem insistir (mantida)

Identificador na fonte: `msg-M22`. Papel neste pacote: histórico, não instrução.

```text
Tranquilo, meu amigo. Valeu por responder e pela sinceridade, isso é raro. Não te incomodo mais com isso, pode deixar. Se um dia quiser conversar sobre vender mais, a porta tá aberta. Um abraço e boas vendas aí.
```

## R4.M23 | Follow-up — retomada específica do ponto onde parou (manual) [MANUAL]

Identificador na fonte: `msg-M23`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Não queria deixar nossa conversa no ar. Reli aqui o que você me falou e aquilo ficou martelando, porque dá pra alavancar exatamente aquele ponto.
Quer continuar de onde a gente parou? Se não for a hora, é só dizer que eu deixo quieto.
```

## R4.M24 | Exemplo didático do processo (otimizada)

Identificador na fonte: `msg-M24`. Papel neste pacote: histórico, não instrução.

```text
Um exemplo de como funciona. A pessoa vê o carro, chama no zap, recebe um atendimento que entende o que ela procura. E se ainda não decidir, a conversa é acompanhada no momento certo, sem sumir.
O foco é não depender só do anúncio e não deixar a oportunidade morrer no meio do papo. É exemplo do processo, não é resultado prometido, resultado a gente constrói junto.
```

## R4.M25 | Reativação — checar se ainda faz sentido (manual) [MANUAL]

Identificador na fonte: `msg-M25`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? A gente conversou sobre estratégia pra chegar mais cliente e fechar mais na venda de veículos, e você topou que eu voltasse hoje. Isso ainda faz sentido pra você neste momento, ou prefere deixar o assunto encerrado? Qualquer resposta tá ótima, se for encerrar, eu encerro de verdade.
```

## R4.M26 | Lead quente WhatsApp — tratamento VIP

Identificador na fonte: `msg-M26`. Papel neste pacote: histórico, não instrução.

```text
Beleza, já anotei tudo que a gente conversou aqui, tá bom? Vou te passar direto pra quem cuida disso com a gente. Ele já vem te atender sabendo do seu caso, você não precisa repetir nada. Me dá um instantinho.
```

## R4.M27 | Já tem agência — curiosidade sem ameaça

Identificador na fonte: `msg-M27`. Papel neste pacote: histórico, não instrução.

```text
Ter essa parte acompanhada já é um passo à frente, e não vim pedir pra você trocar nada sem conhecer o que funciona pra vocês. Me conta com sinceridade, porque é isso que decide se eu tenho algo a somar. Os resultados tão te deixando satisfeito, ou tem algum ponto que te incomoda?
```

## R4.M28 | Já anuncia + média conhecida — gargalo (mantida, leve ajuste)

Identificador na fonte: `msg-M28`. Papel neste pacote: histórico, não instrução.

```text
O ponto não é começar a anunciar, você já faz isso. O ponto é o que acontece depois do clique, fazer quem chega avançar do jeito que você espera. Hoje pesa mais a quantidade de gente que chama, ou o aproveitamento das conversas que já chegam?
```

## R4.M29 | Anúncio não funcionou — empatia + investigação binária

Identificador na fonte: `msg-M29`. Papel neste pacote: histórico, não instrução.

```text
Entendo a frustração, tá bom. Gastar com anúncio e não ver retorno irrita mesmo, e a causa quase nunca é anúncio não funciona, é algum ponto específico do processo. Te falo com sinceridade, sem olhar o que foi feito, quem aponta a causa na hora tá só chutando.
Me conta o que aconteceu no seu caso. Quase ninguém chamou, ou chegou gente que não avançou?
```

## R4.M30 | Muitos curiosos — validar a dor + duas frentes honestas

Identificador na fonte: `msg-M30`. Papel neste pacote: histórico, não instrução.

```text
Isso desgasta mesmo. Responder vinte pessoas pra fechar com uma desanima qualquer um. Ninguém garante que só comprador vai chegar, mas dá pra melhorar nas duas pontas. Divulgação direcionada, pra atrair gente com intenção real, e filtragem na conversa, pra gastar tempo com quem tá levando a sério. Teu tempo é o recurso mais caro da loja, né.
Hoje vocês entendem o que a pessoa procura antes da negociação?
```

## R4.M31 | Sem tempo — empatia + double bind honroso + saída M91

Identificador na fonte: `msg-M31`. Papel neste pacote: histórico, não instrução.

```text
Olha, quem vende veículo não tem hora livre sobrando não, eu sei como é. Não quero ser mais um te tomando tempo, tá bom?
```

## R4.M31b | Sem tempo — empatia + double bind honroso + saída M91 (bolha 2 de 2)

Identificador na fonte: `msg-M31b`. Papel neste pacote: histórico, não instrução.

```text
Então é o seguinte, prefere marcar um momento melhor pra gente se falar, ou deixar isso pra lá por enquanto? Qualquer uma das duas serve, e se for não, sem problema também.
```

## R4.M32 | Sem orçamento — conhecer sem compromisso

Identificador na fonte: `msg-M32`. Papel neste pacote: histórico, não instrução.

```text
Momento é momento, não adianta empurrar nada que não cabe agora, e conhecer não te compromete com nada. Você prefere ver a ideia por aqui, no seu tempo, ou deixar essa conversa pra outra hora?
```

## R4.M33 | Vendas vão bem — elogio + pergunta de ambição

Identificador na fonte: `msg-M33`. Papel neste pacote: histórico, não instrução.

```text
Loja vendendo bem é justamente o melhor cenário pra crescer mais. Quem já vende bem não depende, escolhe. Te pergunto direto, porque a resposta muda o que eu te mostraria. Tem algum ponto que você ainda queria melhorar, tipo alcançar outro público, vender mais rápido ou aproveitar melhor os contatos? Ou o cenário atual já tá te atendendo?
```

## R4.M34 | Manda informações — resumo em bullets

Identificador na fonte: `msg-M34`. Papel neste pacote: histórico, não instrução.

```text
Deixa eu resumir sem enrolação. Seu carro na frente da pessoa certa na rede social, e quando ela chama no zap o atendimento segura, porque muita venda morre no vácuo. Vai ajustando pelo que dá resultado.
```

## R4.M34b | Manda informações — resumo em bullets (bolha 2 de 2)

Identificador na fonte: `msg-M34b`. Papel neste pacote: histórico, não instrução.

```text
Vou te falar a real, não é promessa de milagre não, é trabalho bem feito. Se o caso não tiver potencial, você ouve isso da gente primeiro. Me diz uma coisa, hoje aperta mais chegar cliente ou fechar com quem já te chama?
```

## R4.M35 | Desconfiança — validação + controle na mão dele

Identificador na fonte: `msg-M35`. Papel neste pacote: histórico, não instrução.

```text
Você tá certíssimo em conferir, eu também desconfiaria de mensagem de desconhecido. Vou te dar o que conferir em vez de pedir confiança. Aqui é da Alavancagem de Vendas, a gente trabalha com divulgação e vendas pra quem vende veículo, e este contato é uma proposta comercial, nada além disso. Você não precisa mandar dado nenhum nem decidir nada agora.
Me diz o que quer confirmar primeiro, que eu te passo certinho.
```

## R4.M36 | Origem desconhecida — honestidade sem jargão

Identificador na fonte: `msg-M36`. Papel neste pacote: histórico, não instrução.

```text
Justo perguntar. Seu contato é público, tá no perfil da loja no Google Maps, foi de lá que eu peguei. Não tem lista comprada nem nada disso. Se quiser que eu não te chame mais, é só falar que eu tiro seu número na hora.
```

## R4.M37 | Identidade — calor + porta de saída

Identificador na fonte: `msg-M37`. Papel neste pacote: histórico, não instrução.

```text
Então, sou da Alavancagem de Vendas. A gente trabalha só com loja e vendedor de veículo, pra ajudar a vender mais sem depender só de indicação.
```

## R4.M37b | Identidade — calor + porta de saída (bolha 2 de 2)

Identificador na fonte: `msg-M37b`. Papel neste pacote: histórico, não instrução.

```text
Te chamei por um motivo, vi sua loja e sei que dá pra girar mais esse estoque, tá bom? Se não quiser seguir com a conversa, eu sigo reto, sem insistência nenhuma.
```

## R4.M38 | Sócio ou gerente — decisão conjunta (mantida)

Identificador na fonte: `msg-M38`. Papel neste pacote: histórico, não instrução.

```text
Faz todo sentido envolver quem decide isso junto com você, decisão dividida dura mais. Fica melhor um resumo pra você encaminhar, ou uma conversa em que vocês possam participar juntos?
```

## R4.M39 | Não decide — sem pressionar o intermediário (mantida)

Identificador na fonte: `msg-M39`. Papel neste pacote: histórico, não instrução.

```text
Sem problema, e obrigado pela honestidade de dizer isso logo. Posso te passar um resumo curto pra você encaminhar a quem avalia essa parte, e a gente só continua se a pessoa tiver interesse, zero pressão do seu lado. Facilitaria por aí?
```

## R4.M40 | Indicação — preservar o canal que funciona (mantida)

Identificador na fonte: `msg-M40`. Papel neste pacote: histórico, não instrução.

```text
Indicação é ouro, e não precisa deixar de existir, tá bom. O anúncio entra pra alcançar quem ainda não te conhece, não pra substituir o que já funciona. Me diz uma coisa, hoje vocês usam anúncio pago como complemento, ou trabalham só com indicação mesmo?
```

## R4.M41 | Pouco movimento de rua — alcance online (mantida, leve ajuste)

Identificador na fonte: `msg-M41`. Papel neste pacote: histórico, não instrução.

```text
Aí a divulgação online faz exatamente o que a localização não faz, coloca seus carros na frente de quem nunca vai passar na frente da loja. O alcance deixa de depender do endereço. Hoje vocês mostram o estoque em quais canais?
```

## R4.M42 | Vendedor independente — entender o modelo (mantida)

Identificador na fonte: `msg-M42`. Papel neste pacote: histórico, não instrução.

```text
Tranquilo, também dá pra avaliar o cenário de quem vende de forma independente. O que muda é o jeito de montar, não é o princípio. Você trabalha com carro próprio, consignado, ou intermediando a venda pra outras pessoas?
```

## R4.M43 | Sem estoque fixo — não anunciar indisponíveis (mantida)

Identificador na fonte: `msg-M43`. Papel neste pacote: histórico, não instrução.

```text
Certo, então a divulgação tem que acompanhar os carros que você realmente tem disponíveis, sem tratar tua operação como estoque fixo. Como você costuma achar comprador quando aparece uma oportunidade de venda?
```

## R4.M44 | Não quer reunião — aceitar o canal de texto (otimizada)

Identificador na fonte: `msg-M44`. Papel neste pacote: histórico, não instrução.

```text
Tranquilo, não precisa de ligação nenhuma pra conhecer o serviço. A gente segue por mensagem aqui no seu ritmo, sem horário marcado. Só me diz uma coisa, aperta mais chegar cliente na loja ou fechar com quem já te chama?
```

## R4.M45 | Retorno em outro momento — pedir preferência (mantida)

Identificador na fonte: `msg-M45`. Papel neste pacote: histórico, não instrução.

```text
Certo, cada coisa no seu tempo. Que dia e período fica bom pra eu retomar com você? Te confirmo em seguida, pode deixar que não te pego numa hora ruim.
```

## R4.M46 | Não é prioridade — respeitar sem argumentar (mantida)

Identificador na fonte: `msg-M46`. Papel neste pacote: histórico, não instrução.

```text
Combinado, vamos respeitar o momento do seu negócio, porque insistir onde não é prioridade só atrapalha os dois lados. Vou deixar o assunto por aqui. Se virar prioridade e você quiser retomar, é só me chamar que a gente continua de onde parou.
```

## R4.M47 | Como atrair clientes — explicar + canais (otimizada)

Identificador na fonte: `msg-M47`. Papel neste pacote: histórico, não instrução.

```text
A gente combina duas coisas, tá bom. Anúncio direcionado, que coloca seus carros na frente de quem tá procurando de verdade, não é alcance aleatório. E atendimento que não deixa quem chega escapar, porque atrair sem segurar é enxugar gelo.
Pra eu direcionar isso à tua realidade. Você já divulga os carros em quais canais?
```

## R4.M48 | Garantia de vendas — honestidade que vira autoridade

Identificador na fonte: `msg-M48`. Papel neste pacote: histórico, não instrução.

```text
Olha, vou ser direto, quem promete número garantido de venda nesse mercado não tá falando a verdade. Resultado depende do estoque, da região, do preço dos carros e da execução, dos dois lados.
O que eu garanto é o processo. Divulgação com critério, conversa acompanhada e ajuste com base em número. Essa conversa serve pra avaliar o potencial real no seu cenário, e se não tiver potencial você ouve isso de mim primeiro.
```

## R4.M49 | É grátis? — ponte humana sem confirmar condição

Identificador na fonte: `msg-M49`. Papel neste pacote: histórico, não instrução.

```text
Olha, se eu te responder isso de cabeça aqui, seria te desrespeitar. Essa pergunta merece resposta certa. Já te coloco com quem responde isso por mim e ele te retorna nessa mesma conversa, pode deixar.
```

## R4.M50 | Eu te chamo — iniciativa com ele, porta destrancada

Identificador na fonte: `msg-M50`. Papel neste pacote: histórico, não instrução.

```text
Combinado, a iniciativa fica com você, e eu não vou ficar te cutucando, porque prometer isso e não cumprir vale menos que nada. Quando der vontade de retomar, é só mandar uma mensagem aqui que a gente continua de onde parou.
```

## R4.M51 | Experiência ruim anterior — ouvir antes de oferecer (otimizada)

Identificador na fonte: `msg-M51`. Papel neste pacote: histórico, não instrução.

```text
Sua cautela é justa. Antes de sugerir qualquer coisa, eu quero entender o que deu errado aí, até pra não repetir o mesmo erro com você. O que mais te decepcionou, a quantidade de gente que chegou, o atendimento que você recebeu, ou o resultado das conversas?
```

## R4.M52 | Privacidade — não exigir dados sensíveis (mantida)

Identificador na fonte: `msg-M52`. Papel neste pacote: histórico, não instrução.

```text
Tranquilo, você não precisa passar documento, senha nem dado sensível pra conhecer a proposta, e eu nunca vou te pedir nada disso. Dá pra conversar só sobre o funcionamento geral das vendas. Se preferir não compartilhar nem isso, a gente respeita, a conversa é sua.
```

## R4.M53 | Equipe ou funcionário — encaminhar sem presumir (mantida)

Identificador na fonte: `msg-M53`. Papel neste pacote: histórico, não instrução.

```text
Sem problema, posso deixar um resumo pra pessoa que acompanha a divulgação ou o atendimento no dia a dia, e a gente continua só se ela quiser, sem te transformar em cobrador de resposta. Você prefere encaminhar por aí?
```

## R4.M54 | Resposta vaga à pergunta de gargalo (mantida)

Identificador na fonte: `msg-M54`. Papel neste pacote: histórico, não instrução.

```text
Deixa eu confirmar uma coisa pra não te empurrar o que não serve, tá bom? Hoje você quer mais cliente chamando pelos carros, ou fechar melhor com quem já te procura?
```

## R4.M55 | Pedido para parar — fim imediato (mantida)

Identificador na fonte: `msg-M55`. Papel neste pacote: histórico, não instrução.

```text
Entendido, meu amigo. Seu número sai agora da nossa lista e ninguém mais te chama por aqui, pode contar com isso. Foi um prazer falar com você. Um abraço.
```

## R4.M56 | Número errado ou fora do público (mantida)

Identificador na fonte: `msg-M56`. Papel neste pacote: histórico, não instrução.

```text
Obrigado por avisar, e desculpa pelo contato indevido. Vou encerrar por aqui e não te mando mais nada. Boas vendas pra você.
```

## R4.M57 | Não entendeu — explicação vívida e simples

Identificador na fonte: `msg-M57`. Papel neste pacote: histórico, não instrução.

```text
Do jeito mais simples possível, tá bom. Sabe quando o cliente chama e a conversa não vai pra frente? A gente resolve isso, e ainda faz chegar mais gente. São três coisas, anúncio pra quem procura carro, conversa melhor no zap e acompanhamento de quem sumiu.
Primeiro eu entendo como você vende hoje, depois mostro o que serve pro seu caso. Nessa ordem, porque sem entender o hoje qualquer proposta é chute.
```

## R4.M58 | Capacidade de atendimento — parceiro de planejamento

Identificador na fonte: `msg-M58`. Papel neste pacote: histórico, não instrução.

```text
Então, esse ponto é importante e é bom você levantar. Trazer mais conversa do que dá pra atender piora as coisas, não melhora. Por isso a ordem certa é organizar e dar velocidade ao atendimento primeiro, e só depois pensar em atrair mais gente. Quem vende bem começa pelo gargalo, não pelo topo.
Nessa parte de responder o cliente, o que mais consome teu tempo hoje?
```

## R4.M59 | Resultados e referências — promessa cumprível

Identificador na fonte: `msg-M59`. Papel neste pacote: histórico, não instrução.

```text
Justo, eu também pediria no seu lugar. Tenho material de trabalho pra te mostrar, mas prefiro te enviar pessoalmente, com o contexto de cada caso, em vez de jogar print solto aqui, porque número sem contexto promete mais do que entrega. Já anotei teu pedido e te mando nessa conversa.
```

## R4.M60 | Encerramento cordial — sem nova tentativa (mantida)

Identificador na fonte: `msg-M60`. Papel neste pacote: histórico, não instrução.

```text
Sem problema nenhum, meu amigo. Obrigado pelo retorno e pela educação, isso faz diferença. Não te incomodo mais com isso. Se um dia o momento melhorar, a gente tá por aqui. Um abraço e boas vendas.
```

## R4.M61 | Não isolado — esclarecer sem excluir (generalizada: gargalo E canal)

Identificador na fonte: `msg-M61`. Papel neste pacote: histórico, não instrução.

```text
Tranquilo, e valeu por falar direto, tá bom? Me diz uma coisa pra eu não errar de novo. É falta de tempo agora, é o formato, tipo ligação ou mensagem, ou você não quer continuar mesmo? Qualquer resposta serve, eu ajusto aqui.
```

## R4.M62 | Os dois gargalos — priorizar uma vez (mantida)

Identificador na fonte: `msg-M62`. Papel neste pacote: histórico, não instrução.

```text
Entendi, e faz sentido sim. Dá pra trabalhar os dois lados, fazer chegar mais cliente e fechar mais com quem te chama. Só me diz uma coisa, qual dos dois pesa mais pra você hoje?
```

## R4.M63 | Não sabe a média — seguir sem bloquear (mantida, leve ajuste)

Identificador na fonte: `msg-M63`. Papel neste pacote: histórico, não instrução.

```text
Então, não precisa ter esse número na mão pra conversar, vamos pelo cenário geral. O que você sente que mais atrapalha as vendas hoje?
```

## R4.M64 | Média recebida — reconhecer e avançar (mantida)

Identificador na fonte: `msg-M64`. Papel neste pacote: histórico, não instrução.

```text
Certo, anotado. Essa referência ajuda a entender o momento da operação. Não precisa detalhar tudo agora, o importante é o que você quer melhorar a partir desse cenário.
```

## R4.M65 | Objetivo diferente — ouvir sem encaixar à força (mantida)

Identificador na fonte: `msg-M65`. Papel neste pacote: histórico, não instrução.

```text
Beleza, então me conta do teu jeito. Qual resultado ou melhoria você tá buscando hoje na venda dos carros?
```

## R4.M66 | Dúvida esclarecida — pedir permissão curta (mantida, leve ajuste)

Identificador na fonte: `msg-M66`. Papel neste pacote: histórico, não instrução.

```text
Rapidinho só, posso continuar te contando?
```

## R4.M67 | Sim ao convite — falta escolher o canal (mantida, leve ajuste)

Identificador na fonte: `msg-M67`. Papel neste pacote: histórico, não instrução.

```text
Beleza, só falta escolher o canal então. Uma chamada rapidinha, ou prefere seguir por mensagem aqui no zap?
```

## R4.M68 | Preferência de horário recebida — inclusive 'qualquer horário'

Identificador na fonte: `msg-M68`. Papel neste pacote: histórico, não instrução.

```text
Anotado aqui, tá bom? Só preciso confirmar com a agenda do pessoal e já te retorno com a confirmação certinha. Qualquer mudança eu te aviso antes, não te deixo no vácuo.
```

## R4.M69 | Só o horário — falta o dia (mantida)

Identificador na fonte: `msg-M69`. Papel neste pacote: histórico, não instrução.

```text
Certo, e pra qual dia você tá pensando nesse horário? Se ficar mais fácil, responde só com algo tipo quinta ou amanhã.
```

## R4.M70 | Só o dia — falta o horário (mantida)

Identificador na fonte: `msg-M70`. Papel neste pacote: histórico, não instrução.

```text
Fechado. E qual horário fica melhor pra você nesse dia?
```

## R4.M71 | Fuso — reconhece a pergunta antes de pedir a cidade

Identificador na fonte: `msg-M71`. Papel neste pacote: histórico, não instrução.

```text
Quero confirmar a referência de horário certinha contigo, pra não dar nenhum desencontro, porque ninguém merece entrar em conversa na hora errada. Me diz só em qual cidade você vai estar no dia, que eu já te retorno com tudo confirmado.
```

## R4.M72 | Quer falar agora — conferir atendimento (mantida, leve ajuste)

Identificador na fonte: `msg-M72`. Papel neste pacote: histórico, não instrução.

```text
Opa, pra agora eu não te deixo no vácuo não. Me espera um minutinho aqui que já te atendo. Se precisar sair, me avisa que a gente remarca sem problema.
```

## R4.M73 | Remarcação — nova preferência (mantida, leve ajuste)

Identificador na fonte: `msg-M73`. Papel neste pacote: histórico, não instrução.

```text
Sem problema nenhum ajustar, agenda boa é a que cabe na sua semana, não a que trava. Qual novo dia e horário funcionam melhor pra você?
```

## R4.M74 | Cancelar reunião — humano, sem 'sinalizar'

Identificador na fonte: `msg-M74`. Papel neste pacote: histórico, não instrução.

```text
Certo, pode deixar. Essa conversa tá cancelada e eu não marco outro horário sem combinar com você antes. Se mais pra frente quiser remarcar, é só chamar aqui, a porta fica aberta, sem cobrança.
```

## R4.M75 | Áudio recebido — interesse genuíno

Identificador na fonte: `msg-M75`. Papel neste pacote: histórico, não instrução.

```text
Recebi teu áudio. Vou ouvir com calma e te responder aqui pessoalmente, porque você merece resposta de quem ouviu inteiro, não de quem escutou pela metade.
```

## R4.M76 | Arquivo ou imagem — conferir antes de responder

Identificador na fonte: `msg-M76`. Papel neste pacote: histórico, não instrução.

```text
Recebi o material. Vou olhar com calma e já te retorno aqui, porque prefiro conferir direitinho a responder qualquer coisa no impulso. Resposta afobada só gera retrabalho.
```

## R4.M77 | Retomada da fila silenciosa, resposta fora do esperado [MANUAL]

Identificador na fonte: `msg-M77`. Papel neste pacote: histórico, não instrução.

```text
Prefiro perguntar do que sair falando coisa que não te serve. Me diz numa frase só, o que você quer saber ou resolver agora?
```

## R4.M78 | Operação fora do escopo — avaliar pessoalmente (otimizada)

Identificador na fonte: `msg-M78`. Papel neste pacote: histórico, não instrução.

```text
Esse tipo de operação eu preciso avaliar pessoalmente. Não quero te prometer algo fora do que a gente realmente atende, porque promessa torta cobra juros depois. Deixa eu conferir e já te dou uma resposta honesta aqui.
```

## R4.M79 | Pessoa quer comprar um carro — esclarecer (mantida, leve ajuste)

Identificador na fonte: `msg-M79`. Papel neste pacote: histórico, não instrução.

```text
Só pra esclarecer, porque a confusão é justa. Aqui é da Alavancagem de Vendas, não é de uma loja anunciando carro. Esse contato é sobre estratégia pra quem TRABALHA com venda de veículos. Desculpa o mal-entendido, e obrigado por responder.
```

## R4.M80 | É robô? — transparência com simpatia

Identificador na fonte: `msg-M80`. Papel neste pacote: histórico, não instrução.

```text
Vou ser sincero contigo, sou um assistente automático daqui, tá bom? Faço bem o básico, e quem resolve de verdade é gente.
```

## R4.M80b | É robô? — transparência com simpatia (bolha 2 de 2)

Identificador na fonte: `msg-M80b`. Papel neste pacote: histórico, não instrução.

```text
Se quiser, te passo agora pra uma pessoa do time. Ou, se preferir, eu continuo e te mostro rapidinho o que a gente faz. O que fica melhor pra você?
```

## R4.M81 | Handoff pessoal — upgrade, não erro do sistema

Identificador na fonte: `msg-M81`. Papel neste pacote: histórico, não instrução.

```text
Claro, meu amigo. Seu caso merece atenção de gente, não de robô. Vou te passar direto pra alguém do time e já vem te atender, em instantes. Não precisa repetir nada do que a gente conversou, tá tudo anotado.
```

## R4.M82 | Identidade + investimento na mesma mensagem

Identificador na fonte: `msg-M82`. Papel neste pacote: histórico, não instrução.

```text
Então, sobre o investimento eu prefiro te responder pessoalmente, porque número solto por mensagem nunca reflete teu cenário, e eu não vou te passar chute. Já anotei tua pergunta e te retorno aqui nessa conversa.
```

## R4.M83 | Dados oficiais — proatividade na verificação

Identificador na fonte: `msg-M83`. Papel neste pacote: histórico, não instrução.

```text
Justo, quem é sério tem que poder ser conferido mesmo, e você não deveria confiar em mim só pela minha palavra. Vou separar as informações e os materiais certos pra você verificar tudo por conta própria, sem resposta vaga. Já te envio aqui nessa conversa.
```

## R4.M84 | Quer contratar — tapete vermelho

Identificador na fonte: `msg-M84`. Papel neste pacote: histórico, não instrução.

```text
Aí sim! Então vamos fazer isso direito. A partir daqui quem assume a conversa é o responsável do time, sem pacote pronto empurrado goela abaixo. Ele te chama já já nessa mesma conversa e vocês alinham tudo.
```

## R4.M85 | Resumo para sócio/equipe — formatado para encaminhar

Identificador na fonte: `msg-M85`. Papel neste pacote: histórico, não instrução.

```text
Resumo pra você encaminhar, pode copiar e colar.
A Alavancagem de Vendas trabalha com três frentes pra quem vende veículo. Divulgação direcionada nas redes, técnica de venda no zap e acompanhamento de quem chamou e não fechou.

Sem promessa de resultado fixo, a proposta é entender o cenário e aproveitar melhor as oportunidades. Dá pra conhecer por mensagem ou numa conversa de 15 minutos.

Obrigado por envolver quem decide junto, decisão dividida dura mais.
```

## R4.M86 | Escopo técnico/integração — sem vender fumaça

Identificador na fonte: `msg-M86`. Papel neste pacote: histórico, não instrução.

```text
Esse detalhe eu só te prometo depois de conferir o que tá incluso de verdade. Não quero te vender fumaça, porque fumaça some na primeira subida. Vou verificar e te respondo certinho aqui nessa conversa.
```

## R4.M87 | Prazo de resultado — honestidade com espinha

Identificador na fonte: `msg-M87`. Papel neste pacote: histórico, não instrução.

```text
Te respondo com sinceridade, quem promete vendas em 15 dias tá te vendendo ilusão. O que existe é trabalho bem executado. Planejar, anunciar, acompanhar as conversas e ajustar pelo que os números mostram. O resultado vai construindo, e quem fala diferente promete o que não controla.
Essa conversa inicial serve pra ver o que dá pra esperar no teu cenário, sem ilusão e sem pessimismo de fachada.
```

## R4.M88 | Duração da conversa — time framing (mantida, leve ajuste)

Identificador na fonte: `msg-M88`. Papel neste pacote: histórico, não instrução.

```text
A conversa inicial dura uns 15 minutos, curta e direta ao ponto, porque respeito ao teu tempo é o mínimo. Se preferir, também dá pra conhecer a proposta por mensagem aqui no zap.
```

## R4.M89 | Confirmação de agenda COM detalhes reais [MANUAL]

Identificador na fonte: `msg-M89`. Papel neste pacote: histórico, não instrução.

```text
Tudo confirmado! 📞 Nossa conversa tá de pé no dia e no horário que a gente combinou, e te chamo pelo zap mesmo. Se precisar mudar qualquer coisa, me avisa por aqui que a gente ajusta sem cerimônia. Até lá, e valeu por reservar esse tempo!
```

## R4.M90 | Quem executa a venda — delimitar a proposta (mantida)

Identificador na fonte: `msg-M90`. Papel neste pacote: histórico, não instrução.

```text
Cada lado tem um papel aqui. A proposta é ajudar na divulgação, nas técnicas de atendimento e no acompanhamento de quem chama, sem assumir a negociação nem vender os carros no lugar de vocês, porque o teu papel ninguém faz melhor que você. O que cada lado executa a gente alinha pessoalmente antes de qualquer contratação.
```

## R4.M91 | Permissão para o próximo toque — gera a autorização que a M25 exige

Identificador na fonte: `msg-M91`. Papel neste pacote: histórico, não instrução.

```text
Valeu por falar aberto comigo, isso é raro, tá bom? Só mais uma coisa, posso te mandar amanhã uma ideia rápida do que daria pra fazer aí na loja? Se não quiser, é só ignorar que eu não te incomodo mais.
```

## R4.M92 | Toque de valor — cumpre o combinado na M91 [MANUAL]

Identificador na fonte: `msg-M92`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Como combinado, te trouxe aquele exemplo que falei. Lembrei do que você me contou e é exatamente essa parte que isso ataca, porque pensei nesse material ouvindo você.
Dá uma olhada com calma e, se fizer sentido, me diz o que achou. Se não fizer, sem problema nenhum também.
```

## R4.M93 | Breakup — encerrar como prometido, porta aberta [MANUAL]

Identificador na fonte: `msg-M93`. Papel neste pacote: histórico, não instrução.

```text
Oi! Como te falei, vou encerrar por aqui pra não ficar insistindo, porque promessa é promessa 🙂. Se vender mais carro virar prioridade aí, me chama a qualquer momento, a gente retoma exatamente de onde parou, sem precisar me explicar nada de novo. Boas vendas pra você!
```

## R4.M94 | Reabertura — o lead voltou por conta própria

Identificador na fonte: `msg-M94`. Papel neste pacote: histórico, não instrução.

```text
Que bom te ver por aqui de novo, e desta vez foi você quem chamou, o que vale mais. Dá pra retomar sim, a gente continua exatamente de onde parou. Me conta, o que você quer saber?
```

## R4.M95 | Lembrete de véspera — salva a call antes do dia [MANUAL]

Identificador na fonte: `msg-M95`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Passando só pra confirmar nossa conversa de amanhã no horário que a gente combinou, continua bom pra você? Se apertar alguma coisa, me avisa por aqui que a gente remarca sem problema nenhum, melhor remarcar do que faltar.
```

## R4.M96 | Lembrete do dia — 1 a 2 horas antes [MANUAL]

Identificador na fonte: `msg-M96`. Papel neste pacote: histórico, não instrução.

```text
Logo mais a gente se fala, no horário combinado! Te chamo por aqui. Vai ser rápido e direto, como te prometi. Se mudar algo, me avisa.
```

## R4.M97 | Recuperação de no-show — sem culpa, remarcação fácil [MANUAL]

Identificador na fonte: `msg-M97`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Acho que o dia apertou por aí, totalmente normal, acontece com todo mundo que vende. Quer remarcar nossa conversa? Me diz um dia e horário que fique melhor que eu me ajusto aqui, sem culpa e sem burocracia.
```

## R4.M98 | Pergunta socrática — estoque parado (dor verbalizada pelo lead)

Identificador na fonte: `msg-M98`. Papel neste pacote: histórico, não instrução.

```text
Só por curiosidade, pra entender tua operação de verdade. Em média, quanto tempo um carro fica parado no pátio até vender? Pergunto porque é esse número que costuma mostrar onde a estratégia faz diferença.
```

## R4.M99 | Pós-call — resumo e próximo passo em até 24h [MANUAL]

Identificador na fonte: `msg-M99`. Papel neste pacote: histórico, não instrução.

```text
Obrigado pelo papo hoje, de verdade! Antes de eu te mandar o resumo escrito, me diz você, do que a gente viu, qual ponto ficou mais claro como próximo passo? Quero fechar isso do seu jeito, porque resumo que a gente constrói junto não fica no ar. Na sequência te mando tudo certinho por aqui, com a sugestão do próximo passo, e se ficou algum ponto de fora, me fala direto.
```

## R4.M100 | Follow-up de proposta — 48h, direto e leve [MANUAL]

Identificador na fonte: `msg-M100`. Papel neste pacote: histórico, não instrução.

```text
Oi, tudo bem? Conseguiu dar uma olhada no que te mandei? Se tiver qualquer dúvida, valor, escopo, prazo, me pergunta direto aqui. Prefiro responder tudo a deixar coisa no ar, porque dúvida sem resposta vira um não silencioso.
```

## R4.M101 | Assunção do lead quente — sua primeira mensagem humana (áudio) [MANUAL]

Identificador na fonte: `msg-M101`. Papel neste pacote: histórico, não instrução.

```text
ROTEIRO DO ÁUDIO. Falar natural, não ler. Grave num lugar silencioso e sorria enquanto fala, a voz carrega o sorriso.
1. Nome + gente. Cumprimente o lead pelo nome e se apresente pelo seu nome, da Alavancagem de Vendas.
2. Prova de contexto. Leia o histórico ANTES, cite a dor que ele contou ao robô com as palavras dele e nomeie o que parece pesar, no estilo parece que...
3. Ponte. Isso é exatamente o que a gente resolve, e pro caso dele você já tem uma ideia do que fazer.
4. CTA único. Ofereça os 2 minutos de explicação e pergunte se ele prefere um áudio por aqui ou 15 minutinhos de ligação.
Depois de falar, espere. Se ele desabafar, repita as últimas palavras dele antes de responder, e procure o isso mesmo antes de propor qualquer coisa.
Frame antes de gravar, filtro Harvey. Você não pede favor, você oferece algo que resolve e também avalia se o caso tem a ver com o que a gente faz. Quem precisa menos conduz.
Convicção, filtro Belfort versão honesta. Certeza na voz só sobre o que é VERDADE, nunca sobre o que não pode garantir.
Leitura, filtro Jane. Repare no que ele NÃO disse no histórico e nomeie com leveza, no parece que...
```

## R4.M102 | Abertura de campanha personalizada — braço B do teste A/B [ASSISTIDA]

Identificador na fonte: `msg-M102`. Papel neste pacote: histórico, não instrução.

```text
Bom dia! Falo com o responsável pelas vendas da loja? Aqui é da Alavancagem de Vendas, trabalho com divulgação pra lojas de veículos aqui da região. Dei uma olhada no perfil de vocês e vi uma coisa que me deu uma ideia específica pra aí, específica mesmo, não é mensagem em massa. Posso te mostrar rapidinho?
```

## R4.M103 | Origem conhecida (não-Maps) — resposta verdadeira [ASSISTIDA]

Identificador na fonte: `msg-M103`. Papel neste pacote: histórico, não instrução.

```text
Consegui seu contato por dados públicos da sua empresa, do mesmo jeito que o cliente te acha quando procura carro na internet. Te chamei porque a gente trabalha com lojas de veículos aqui da região, não é sorteio de lista. Se preferir não receber esse tipo de contato, me avisa que eu tiro seu número na hora, sem problema e sem pergunta extra.
```

## R4.M104 | Confusão de nicho — financiamento, consórcio ou compra

Identificador na fonte: `msg-M104`. Papel neste pacote: histórico, não instrução.

```text
Sua confusão é justa, tá bom. A gente não trabalha com financiamento, consórcio nem venda de carro. Nosso trabalho é com estratégia pra QUEM VENDE veículo, divulgação pra chegar mais cliente e atendimento pra fechar melhor. Isso tem a ver com o seu caso, ou você tava procurando outra coisa? Se era outra coisa, me diz que eu te oriento pra onde ir.
```

## R4.M105 | Pedido de outro canal — e-mail, Instagram, telefone [ASSISTIDA]

Identificador na fonte: `msg-M105`. Papel neste pacote: histórico, não instrução.

```text
Combinado, te mando por lá sim, porque o canal é seu e quem escolhe é você. Só te aviso que por aqui no zap eu consigo te responder mais rápido. Prefere continuar por lá ou por aqui mesmo?
```
