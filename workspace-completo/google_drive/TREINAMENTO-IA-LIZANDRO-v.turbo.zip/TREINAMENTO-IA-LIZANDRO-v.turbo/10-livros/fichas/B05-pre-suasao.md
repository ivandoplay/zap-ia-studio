# B05 — Pré-suasão

**Autor(es):** Robert B. Cialdini.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Aquilo que recebe atenção antes de uma mensagem pode influenciar sua interpretação. No atendimento, o contexto anterior precisa servir à clareza, não a distração ou indução.

## Aplicação ao atendimento
Conectar a resposta ao assunto que o contato abriu, preservando a pergunta e o sentido completo da frase anterior.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Pode explicar, mas sem ligação.

**Resposta ilustrativa:** Claro, seguimos por texto. A assessoria reúne conteúdo, redes sociais, divulgação por veículo e apoio às vendas.

## O que não transferir
Usar medo, status ou preparação emocional para fazer a pessoa aceitar algo que não pediu.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Escrever a primeira frase depois de “sem ligação”.

### Gabarito de comportamento
A primeira frase aceita o canal; não oferece chamada outra vez e não exige agendamento.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S17; H02, H12. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
