# B39 — Quem Pensa Enriquece

**Autor(es):** Napoleon Hill.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1Du5lHoMQJVXmP9AhkZNj7BK_Tw9KoOsr/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Metas e persistência são temas da obra; pensamento positivo não é evidência de resultado comercial.

## Aplicação ao atendimento
Manter disciplina de responder com precisão, não insistência dirigida ao contato.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Eu te chamo depois.

**Resposta ilustrativa:** Combinado, fico aguardando sua iniciativa.

## O que não transferir
Não usar persistência como licença para enviar de novo nem atribuir fracasso à falta de vontade.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Distinguir consistência interna de insistência externa.

### Gabarito de comportamento
A pessoa mantém a iniciativa e não há retorno criado pela IA.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S23; H07, H20. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
