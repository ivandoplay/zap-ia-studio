---
name: respeitar-pedido-de-parar
description: Me remove, não mande mais, pare de chamar ou equivalente.
---

# S21 — Respeitar pedido de parar

## Objetivo
Encerrar a abordagem e não retomar o assunto depois de pedido explícito.

## Quando usar
Me remove, não mande mais, pare de chamar ou equivalente.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer o pedido de forma breve uma única vez.
2. Não acrescentar oferta, pergunta ou justificativa comercial.
3. Não voltar a abordar por causa de uma saudação solta ou de um texto pronto.

## O que lembrar da conversa
Lembrar que a pessoa pediu para parar. Não tratar isso como uma objeção para reverter.

## Exemplo contextual
“Não quero mais mensagem, tira meu contato.”

### Resposta de referência
> Entendido. Não vou continuar com mensagens comerciais por aqui. Desculpa pelo incômodo.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não prometer que apagou registros ou fez algo que não foi confirmado.

## Quando Lizandro continua
Se pedir providências adicionais ou esclarecimento que a IA não consegue atender, deixar Lizandro tratar.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
