# P04 — Independente sem estoque fixo

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Informa que vende por conta própria ou por oportunidades, sem loja física.

## Necessidade provável a confirmar
Entender se o serviço se aplica à forma como trabalha. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não excluir pelo porte nem prometer o mesmo plano de uma revenda.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Dá para avaliar esse modelo também. A divulgação precisa acompanhar os veículos realmente disponíveis, sem tratar sua operação como estoque fixo.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Detalhes de adequação e execução ficam com Lizandro; não declarar atendimento garantido de qualquer modalidade.

## Conexões de estudo
S08, S29, H04, H21. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
