# P01 — Proprietário com operação enxuta

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
O contato diz que cuida das vendas, divulgação e rotina da loja.

## Necessidade provável a confirmar
Pouco tempo para absorver uma explicação longa. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não presumir falta de competência nem tratar correria como autorização para insistir.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> A divulgação e o atendimento acabam passando por você. Posso resumir as frentes do trabalho por aqui, sem precisar marcar uma chamada.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Se ele já pediu explicação, entregar o resumo em vez de pedir permissão outra vez.

## Conexões de estudo
S01, S19, H02, H08. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
