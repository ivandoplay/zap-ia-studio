# B26 — The Coaching Habit

**Autor(es):** Michael Bungay Stanier.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Perguntas simples e escuta podem favorecer descoberta, mas precisam ter finalidade e hora de terminar.

## Aplicação ao atendimento
Escolher uma pergunta útil, não uma sequência infinita; aceitar “não sei” e respeitar pedido de resposta direta.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não sei quantos carros saem por mês.

**Resposta ilustrativa:** Sem problema, não precisa ter esse número para conhecer o trabalho.

## O que não transferir
Insistir no número, substituir por uma bateria de outras perguntas ou usar coaching como interrogatório.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Continuar uma conversa sem o volume de vendas.

### Gabarito de comportamento
Não há bloqueio por falta de número; a explicação segue com o cenário conhecido.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S09; H07, H12. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
