# Origem e limites da bibliografia

## O que foi realmente recuperado
A descrição do fluxo R4 cita o arquivo `LIVROS-30-APLICADOS-FUNIL-R4.md`, um PLAYBOOK e um auditor. Os documentos citados não estão nos backups recuperados. O projeto `leadzy-local (1).zip` também foi inspecionado: contém a extensão e seus recursos, não o catálogo de livros.

Foram identificados **15 arquivos de livros** no Drive. Isso não demonstra que sejam a seleção original de 30. A maior parte foi identificada pelo nome do arquivo; o início do PDF de Mark Manson foi lido para identificar seu título. Não se afirma leitura integral desses PDFs.

## O que este pacote acrescenta
- **30 fichas principais B01–B30**, selecionadas nesta revisão pelo vínculo com comunicação, escuta, vendas e decisão.
- **9 fichas opcionais B31–B39**, para registrar de forma útil e limitada os outros títulos identificados no Drive.
- Ao todo, **39 títulos distintos**: os 15 identificados no Drive e 24 referências adicionais. As seis coincidências entre os títulos encontrados e a lista principal não são contadas duas vezes.

As fichas são autorais, baseadas em conhecimento geral das obras. Não são livros completos, resumos integrais extraídos dos PDFs nem reconstrução do catálogo original de 30. As conexões com o atendimento foram escritas agora, com limites explícitos.

## Por que essa distinção importa
Não seria correto chamar uma seleção nova de “os 30 livros usados antes”. Também não seria útil parar a entrega por faltar esse catálogo. A solução foi entregar o melhor repertório aplicado disponível e deixar cada origem legível.

## O que não estudar como instrução de atendimento
Não importar conselho financeiro, crença espiritual, alegoria, promessa de riqueza, rigidez de rotina ou pressão de fechamento para a assessoria. Livros não são evidência de resultado do serviço. Números e condições comerciais seguem exclusivos de Lizandro.
