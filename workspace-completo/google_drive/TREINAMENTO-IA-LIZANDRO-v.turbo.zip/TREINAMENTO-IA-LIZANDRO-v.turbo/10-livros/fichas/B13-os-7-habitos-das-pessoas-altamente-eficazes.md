# B13 — Os 7 Hábitos das Pessoas Altamente Eficazes

**Autor(es):** Stephen R. Covey.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1DtDeBr-mBqojeFuq8cCvD5X3KO0ksGfG/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Compreender antes de buscar ser compreendido e priorizar o que importa favorecem comunicação e execução coerentes.

## Aplicação ao atendimento
Ouvir a necessidade declarada antes de repetir a oferta inteira; conservar a preferência de canal e o papel do interlocutor.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** A gente precisa é melhorar o perfil, que está parado.

**Resposta ilustrativa:** Então vale explicar essa frente: o trabalho também inclui gestão da presença nas redes e produção e publicação de conteúdo.

## O que não transferir
Responder com tráfego pago a toda dor ou usar produtividade como argumento para apressar uma decisão.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Localizar a prioridade que o contato já informou e retirar perguntas redundantes.

### Gabarito de comportamento
A explicação começa por conteúdo/perfil e não pede que ele escolha novamente entre captação e fechamento.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S04, S09; H01, H02. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
