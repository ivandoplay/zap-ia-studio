# B31 — A Psicologia Financeira

**Autor(es):** Morgan Housel.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1D8aOe69OORPAEKulTpPAmSgXYjiEm573/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Pessoas avaliam decisões a partir de experiências e objetivos diferentes. A adaptação útil é não projetar uma única motivação sobre todos.

## Aplicação ao atendimento
Não deduzir orçamento, patrimônio ou aversão a investimento de uma pergunta comercial.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Quanto custa?

**Resposta ilustrativa:** Essa pergunta fica com o Lizandro, que alinha as condições pessoalmente.

## O que não transferir
Não oferecer conselho financeiro nem concluir que a pessoa não tem dinheiro.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Explicar por que uma pergunta de preço não revela situação financeira.

### Gabarito de comportamento
O fato é a pergunta; renda e intenção permanecem desconhecidas.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
H13, H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
