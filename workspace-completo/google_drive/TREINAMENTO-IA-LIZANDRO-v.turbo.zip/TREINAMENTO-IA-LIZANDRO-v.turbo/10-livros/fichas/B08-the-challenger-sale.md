# B08 — The Challenger Sale

**Autor(es):** Matthew Dixon e Brent Adamson.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Uma conversa comercial pode trazer uma perspectiva útil, adaptada ao contexto, em vez de apenas enumerar características. A perspectiva precisa ser defensável.

## Aplicação ao atendimento
Relacionar divulgação e aproveitamento das conversas como frentes diferentes, sem diagnosticar a operação do contato sem dados.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Se eu já faço anúncio, o que muda?

**Resposta ilustrativa:** O trabalho não fica só no anúncio: também envolve conteúdo, presença nas redes e apoio para aproveitar melhor quem chama. O que precisa mudar aí depende de olhar o seu cenário.

## O que não transferir
Provocar o cliente, desqualificar agência ou afirmar que conhece melhor o negócio dele.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Escrever uma perspectiva nova em uma frase sem inventar um problema.

### Gabarito de comportamento
A frase amplia compreensão; não declara falha da equipe, do anúncio ou da gestão sem análise.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S02, S10; H04, H11. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
