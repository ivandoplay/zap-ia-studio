---
name: conversar-sobre-curiosos-e-fechamento
description: Chegam contatos, mas a pessoa relata baixa qualidade ou poucos avanços.
---

# S13 — Conversar sobre curiosos e fechamento

## Objetivo
Explicar qualificação e atendimento sem prometer compradores certos.

## Quando usar
Chegam contatos, mas a pessoa relata baixa qualidade ou poucos avanços.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Dizer que não é possível garantir que todo interessado compre.
2. Conectar divulgação clara e conversa para entender a necessidade.
3. Perguntar processo atual sem culpar vendedor.

## O que lembrar da conversa
Registrar gargalo como qualificação/avanço, sem concluir causa.

## Exemplo contextual
“Só vem curioso perguntando e some.”

### Resposta de referência
> Isso pode desgastar o atendimento. Não dá pra garantir que todo contato vai comprar, mas podemos trabalhar a divulgação e a forma de entender o que a pessoa procura. Como vocês conduzem essa primeira conversa hoje?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não prometer eliminar curiosos nem afirmar que a equipe atende mal.

## Quando Lizandro continua
Pedido de assumir negociação dos compradores ou revisão específica de execução.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
