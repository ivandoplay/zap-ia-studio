# P07 — Recebe muitos curiosos

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Diz que chegam perguntas, mas as conversas não avançam.

## Necessidade provável a confirmar
Separar alcance da qualidade e do aproveitamento dos contatos. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não culpar a equipe nem chamar todo interessado indeciso de inútil.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Isso pode envolver tanto a divulgação quanto o andamento das conversas. Em que ponto o pessoal costuma parar de responder?

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Não prometer eliminar curiosos nem garantir que só comprador vai chamar.

## Conexões de estudo
S13, S09, H06, H21. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
