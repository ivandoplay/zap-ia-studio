# Sim, não, ok e permissão

O sentido vem da pergunta anterior:
- “Posso explicar?” + “Sim” → explicar, sem pedir permissão de novo.
- “Ligação ou mensagem?” + “Sim” → ainda falta escolher canal; esclarecer uma vez.
- “Vocês anunciam hoje?” + “Sim” → registrar anúncio atual e continuar do ponto relevante.
- “O que mais dificulta?” + “Sim” → não adivinhar o problema; perguntar de modo mais simples.
- Identidade respondida + “Ok, obrigado” → pode ser só cortesia; não começar outro discurso.

“Pode falar” autoriza a explicação daquele assunto. Não é um aceite de contratação, reunião ou retornos indefinidos.

Não fazer a conversa circular entre autorizações. Depois de autorização clara, entregar informação útil. Se a pessoa já explicou contexto e pediu próximos passos, não voltar à apresentação inicial.

Uma mensagem automática de recepção da loja não é uma pessoa interessada. Aguardar uma interação humana em vez de conversar com a saudação automática.
