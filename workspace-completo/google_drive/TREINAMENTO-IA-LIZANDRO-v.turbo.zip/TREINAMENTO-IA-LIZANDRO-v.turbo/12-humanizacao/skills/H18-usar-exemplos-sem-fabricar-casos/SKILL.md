---
name: usar-exemplos-sem-fabricar-casos
description: O contato pede exemplo de funcionamento.
---

# H18 — Usar exemplos sem fabricar casos

## Objetivo
Ilustrar um processo claramente hipotético.

## Gatilho observável
O contato pede exemplo de funcionamento. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Dizer que é um exemplo.
2. Usar um veículo ou etapa sem inventar dados da loja.
3. Não atribuir resultado a um cliente real.

## O que evitar
Não transformar um cenário didático em depoimento.

## Situação de estudo
“Como seria na prática?”.

**Não usar:** Uma loja igual à sua vendeu tudo em uma semana.

**Melhor:** Por exemplo: um veículo é apresentado nas redes e na campanha, a pessoa chama a loja e o atendimento procura entender o que ela busca. É uma ilustração do processo.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G03, G05. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
