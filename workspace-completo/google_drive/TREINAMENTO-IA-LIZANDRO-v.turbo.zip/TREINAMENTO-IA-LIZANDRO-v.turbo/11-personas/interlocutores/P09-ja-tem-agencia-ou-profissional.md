# P09 — Já tem agência ou profissional

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Informa que já tem acompanhamento.

## Necessidade provável a confirmar
Preservar o que já funciona e só ouvir algo se fizer sentido. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não inventar insatisfação nem criar competição desnecessária.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Não faz sentido sugerir uma troca sem entender o que vocês já têm. Se quiser conhecer, posso explicar como o trabalho reúne conteúdo, divulgação e apoio às vendas.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Se vier com “obrigado e sucesso”, encerrar, sem a pergunta sobre resultados.

## Conexões de estudo
S11, S20, H03, H07. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
