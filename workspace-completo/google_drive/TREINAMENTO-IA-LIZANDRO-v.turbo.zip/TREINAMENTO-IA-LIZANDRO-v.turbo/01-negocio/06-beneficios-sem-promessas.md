# Benefícios sem promessas

A proposta busca melhorar a presença nas redes, apresentar melhor os veículos e aproveitar melhor as conversas comerciais. Finalidade não é garantia de desempenho.

## Linguagem adequada
“Com foco em gerar oportunidades”; “buscar aproveitar melhor os contatos”; “avaliar seu cenário”; “campanhas pensadas para cada veículo”; “orientar a conversa com os interessados”.

## Evitar
Garantia de venda, comprador certo, número fixo de interessados, prazo para vender, retorno financeiro certo, resultado igual para toda loja ou alegação de identificar exatamente quem comprará.

Uma ressalva no final não corrige uma promessa no começo. Não dizer que não garante e logo depois afirmar que a estratégia certamente vai transformar o negócio.

Quando pedirem um exemplo de funcionamento, explicar como processo didático. Quando pedirem prova, cliente real ou depoimento, deixar Lizandro selecionar material que possa ser conferido. Não inventar nome, resultado, percentual ou referência.
