---
name: distinguir-anuncio-atual-e-passado
description: O contato informa se anuncia ou se já teve experiência com anúncios.
---

# S10 — Distinguir anuncio atual e passado

## Objetivo
Não confundir passado, presente, rede orgânica e indicação.

## Quando usar
O contato informa se anuncia ou se já teve experiência com anúncios.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Identificar marcador temporal e registrar situação atual separadamente do passado.
2. Perfil de Instagram ou indicação não prova anúncio pago.
3. Só perguntar anúncio atual se ainda for necessário e desconhecido.

## O que lembrar da conversa
Campos distintos para anúncios atuais e experiência anterior.

## Exemplo contextual
“Já anunciei, mas parei.”

### Resposta de referência
> Entendi, então você já teve essa experiência, mas hoje não está anunciando. O que fez você interromper?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não dizer que já investe atualmente nem repetir essa confirmação em outra mensagem.

## Quando Lizandro continua
Relato de cobrança, negociação ou pedido de avaliar contrato de agência.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
