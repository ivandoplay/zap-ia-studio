# M05 — aprovado literal

Fonte protegida. Não é uma nova redação v.turbo nem a variante R4. Conferir elegibilidade, fatos e papel humano antes de usar. Preservação não é autorização de envio automático.

```text
Entendi! E me conta uma coisa: hoje você trabalha com uma loja de veículos ou vende de forma independente?
```
