# Arquivos de livros identificados no Drive

Identificação documental, não prova de leitura integral nem da seleção original de 30. O arquivo de Mark Manson chamava-se `ARQUIVO_PAGINA.pdf`; o início do documento permitiu identificar a obra. Os demais títulos foram identificados a partir dos nomes disponíveis.

| Título identificável | Autor | Arquivo no Drive | Ficha desta revisão |
|---|---|---|---|
| A Psicologia Financeira | Morgan Housel | [abrir](https://drive.google.com/file/d/1D8aOe69OORPAEKulTpPAmSgXYjiEm573/view) | B31 |
| A sutil arte de ligar o foda-se | Mark Manson | [abrir](https://drive.google.com/file/d/1E2wCkz-1dxRAYjhDlmQPqst7q-4AWmft/view) | B32 |
| Como Fazer Amigos e Influenciar Pessoas | Dale Carnegie | [abrir](https://drive.google.com/file/d/1DquVUNRC6U4KIML2m-_zVhBb_t8JTRyt/view) | B01 |
| Rápido e Devagar | Daniel Kahneman | [abrir](https://drive.google.com/file/d/1DwwT0QFbbShMLCGyQZSg31Um_7hUHRTm/view) | B11 |
| Mindset | Carol S. Dweck | [abrir](https://drive.google.com/file/d/1EODRxFBA970ck-mseLQhwtFdlNCc0NDU/view) | B12 |
| Mais Esperto que o Diabo | Napoleon Hill | [abrir](https://drive.google.com/file/d/1DB3x67ZH5OzpZY_H9HY-j4Rx4e-Pnoqm/view) | B33 |
| O Homem Mais Rico da Babilônia | George S. Clason | [abrir](https://drive.google.com/file/d/1EPx1sz7g_wn0RnHd8aNfO17TLxa1IDhw/view) | B34 |
| O Milagre da Manhã | Hal Elrod | [abrir](https://drive.google.com/file/d/1EJ9l5gL8qCtnMkr_L_ZkKdoYWj3Ai-Wo/view) | B35 |
| O Poder do Agora | Eckhart Tolle | [abrir](https://drive.google.com/file/d/1EavA7sj1aOhQZd6b05ZBZqekxsfPIBpY/view) | B36 |
| O Poder do Hábito | Charles Duhigg | [abrir](https://drive.google.com/file/d/1Dx8Oz4y_ZdFpj5dfiq-I1Hs_97OdiB04/view) | B22 |
| Os 7 Hábitos das Pessoas Altamente Eficazes | Stephen R. Covey | [abrir](https://drive.google.com/file/d/1DtDeBr-mBqojeFuq8cCvD5X3KO0ksGfG/view) | B13 |
| Os Segredos da Mente Milionária | T. Harv Eker | [abrir](https://drive.google.com/file/d/1D9ObhVnTxrJwVDxgKVAYri_9a5i9p_Dx/view) | B37 |
| Pai Rico, Pai Pobre | Robert T. Kiyosaki | [abrir](https://drive.google.com/file/d/1DpSGmQ8ClH1HsV9McBqIv0TeT-Bu3rYE/view) | B38 |
| Quem Pensa Enriquece | Napoleon Hill | [abrir](https://drive.google.com/file/d/1Du5lHoMQJVXmP9AhkZNj7BK_Tw9KoOsr/view) | B39 |
| A Bíblia de Vendas | Jeffrey Gitomer | [abrir](https://drive.google.com/file/d/1EUlvGJNsOA4GPAX-cUyLCKOHcY_d4TpB/view) | B09 |

Os PDFs não foram republicados no ZIP. As fichas incluem somente sínteses autorais e aplicações ao atendimento, sem converter os temas pessoais/financeiros em escopo da assessoria.
