# Respostas curtas, negações e prioridades

## Respostas dependentes de antecedente
| Entrada | Antecedente real | Leitura |
|---|---|---|
| Sim | Permissão para explicar | Explicar |
| Sim | “Anuncia hoje?” | Anúncio atual confirmado |
| Sim | “Ligação ou mensagem?” | Interesse local, canal não escolhido; um complemento |
| Sim | Pergunta anterior indisponível | Não inferir; pausa silenciosa |
| Não | “Você já anuncia?” | Não anuncia; não é recusa do serviço |
| Não | “Quer conhecer a proposta?” | Recusa da proposta; encerrar |
| Os dois | Captação ou fechamento | Considerar os dois; não exigir prioridade repetidamente |
| Ok | Aguardando Lizandro | Sem novo texto automático |
| Ok, obrigado | Identidade/explicação concluída | Cortesia; não presumir interesse |

## Negação com escopo
- “Não liga, mas pode explicar aqui.” → texto permitido.
- “Não quero reunião nem explicação.” → recusa da oferta, não apenas da chamada.
- “Não anuncia agora; já anunciou antes.” → dado sobre tempo, não contradição.
- “Não tenho loja, vendo por conta própria.” → independente; não excluir por falta de ponto físico.
- “Não sou eu que decido, manda o resumo.” → resumo, sem exigir o dono.
- “Não me chama mais, nem por ligação.” → parar, não escolher texto.
- “Quanto custa? Se for caro, não quero.” → condições com Lizandro, sem estimativa nem condição aceita pela IA.

## Mensagens compostas
O pedido de parar prevalece sobre um pedido promocional na mesma mensagem. A recusa total prevalece sobre uma preferência de canal. Perguntas comerciais não podem ser contornadas com qualificação. Se um assunto factual simples e preço vierem juntos, responder o factual disponível e deixar o comercial com Lizandro, sem pitch adicional.

A prioridade é semântica. A ordem histórica de regras por palavra no grafo não prova que uma frase composta será entendida em execução. Este treinamento usa o sentido completo e registra a necessidade de revisão humana quando não houver compreensão segura.
