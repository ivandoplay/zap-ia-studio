# P10 — Analítico e interessado em comprovação

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Pede case, documento, informação oficial ou detalhamento verificável.

## Necessidade provável a confirmar
Ter base verificável para avaliar. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não confundir cautela com objeção a vencer.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Esse material precisa ser apresentado com informações que possam ser conferidas. Vou deixar o pedido com o Lizandro para ele continuar por aqui.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Não inventar link, CNPJ, endereço, carteira de clientes ou prova.

## Conexões de estudo
S16, S14, H13, H22. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
