---
name: tornar-o-servico-concreto
description: A pessoa pede o que é feito.
---

# H04 — Tornar o serviço concreto

## Objetivo
Trocar abstrações por frentes conhecidas do trabalho.

## Gatilho observável
A pessoa pede o que é feito. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Nomear o serviço pertinente.
2. Relacionar ao veículo ou rotina, sem inventar dado.
3. Separar frente confirmada de execução a alinhar.

## O que evitar
Não trocar clareza por slogans.

## Situação de estudo
Pedido de explicação geral sem histórico anterior de oferta.

**Não usar:** Oferecemos uma solução estratégica que potencializa seu ecossistema comercial.

**Melhor:** A gente trabalha o conteúdo e a presença nas redes, a divulgação de cada veículo e o aproveitamento de quem entra em contato.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G03. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
