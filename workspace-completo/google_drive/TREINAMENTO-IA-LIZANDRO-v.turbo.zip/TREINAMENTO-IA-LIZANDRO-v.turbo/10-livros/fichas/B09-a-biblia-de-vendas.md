# B09 — A Bíblia de Vendas

**Autor(es):** Jeffrey Gitomer.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1EUlvGJNsOA4GPAX-cUyLCKOHcY_d4TpB/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Credibilidade e utilidade precisam aparecer na conversa, não apenas na insistência em fechar.

## Aplicação ao atendimento
Entregar explicação concreta e respeitar o tempo do contato. A confiança é construída pela consistência entre o que se fala e o que se pode cumprir.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Manda as informações.

**Resposta ilustrativa:** A assessoria trabalha conteúdo e redes sociais, divulgação pensada por veículo e técnicas de vendas com acompanhamento. Dá para conhecer por aqui, sem precisar marcar chamada.

## O que não transferir
Trocar a informação pedida por qualificação ou uma sequência de convites.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Responder a “manda as informações” antes de pedir qualquer dado novo.

### Gabarito de comportamento
A resposta contém a oferta ampla e não depende de um formulário para começar.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S01, S02; H02, H04. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
