# G06 — Skill creator

## Fonte pública consultada nesta revisão
- Repositório: `anthropics/skills`.
- Arquivo: `skills/skill-creator/SKILL.md`.
- Commit fixado: `dbd4588f9e1033efb41dad4bef2f7947c8993d44`.
- URL: https://github.com/anthropics/skills/blob/dbd4588f9e1033efb41dad4bef2f7947c8993d44/skills/skill-creator/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Definir habilidade com gatilho e critério.

## Adaptação autoral em português
Especificar quando usar, comportamento, limites e exemplos; revisar critérios observáveis em vez de chamar qualquer texto de skill.

## Aplicação neste pacote
Todas as S01–S32 e H01–H24 como formato de documentação.

## Filtros aplicados
Foram aproveitados somente princípios de descrição e avaliação. Não foram incluídos comandos, agentes, programação ou promessa de benchmark executado.

## Exemplo aplicado
Uma skill de silêncio passa quando não há fala ao cliente; não quando aparece a frase “não enviar”.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
