---
name: delimitar-escopo-e-integracoes
description: Pedido de execução específica, plataforma, prazo, acesso ou integração.
---

# S29 — Delimitar escopo e integracoes

## Objetivo
Separar frente confirmada de compromisso ainda não alinhado.

## Quando usar
Pedido de execução específica, plataforma, prazo, acesso ou integração.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Confirmar somente o serviço geral que está documentado.
2. Identificar exatamente o detalhe não confirmado.
3. Encaminhar para alinhamento, sem prometer entrega nem negar serviço real.

## O que lembrar da conversa
Registrar requisito do interessado sem transformá-lo em escopo contratado.

## Exemplo contextual
“Vocês também vão filmar aqui e responder meus compradores?”

### Resposta de referência
> Produção de conteúdo e orientação de atendimento fazem parte das frentes do trabalho. Filmagem presencial e execução do atendimento precisam ser alinhadas com o Lizandro antes de eu te confirmar.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não dizer que faz tudo nem que só faz anúncios. Não pedir senha para validar.

## Quando Lizandro continua
Sempre que o compromisso específico não constar dos fatos aprovados.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
