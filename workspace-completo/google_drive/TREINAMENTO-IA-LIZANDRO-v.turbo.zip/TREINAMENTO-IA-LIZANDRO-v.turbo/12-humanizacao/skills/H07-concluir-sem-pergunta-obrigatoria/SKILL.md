---
name: concluir-sem-pergunta-obrigatoria
description: A resposta resolveu o pedido ou a pessoa encerrou.
---

# H07 — Concluir sem pergunta obrigatória

## Objetivo
Permitir que uma resposta seja apenas resposta.

## Gatilho observável
A resposta resolveu o pedido ou a pessoa encerrou. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Ver se existe uma informação realmente necessária.
2. Se não existe, concluir.
3. Na recusa, não criar outro caminho comercial.

## O que evitar
Não adicionar CTA só para manter a conversa viva.

## Situação de estudo
“Não tenho interesse, obrigado.”

**Não usar:** Tranquilo. Mas antes de encerrar, quer que eu mande um exemplo?

**Melhor:** Tudo bem. Obrigado por responder.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G03. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
