# M12 — aprovado literal

Fonte protegida. Não é uma nova redação v.turbo nem a variante R4. Conferir elegibilidade, fatos e papel humano antes de usar. Preservação não é autorização de envio automático.

```text
Já que a gente tá conversando aqui, deixa eu te perguntar rapidinho: pensa comigo, se todo dia chegassem de duas a cinco pessoas interessadas em comprar os veículos que você tem hoje no estoque, como isso poderia impactar suas vendas no fim do mês?
```
