# Consolidação da V1 e V2

A V1 e a V2 originais foram preservadas no workspace. A v.turbo não foi construída por importação de scripts que regravassem as entregas anteriores.

## Conteúdo útil mantido
- Conhecimento da assessoria e limites de execução.
- 32 skills autorais de atendimento.
- 116 respostas de referência e 45 situações/objeções.
- 24 conversas didáticas.
- 112 exercícios da versão somente treinamento.
- 26 comparações bom/ruim.
- Fonte M01–M13 protegida e literal.

A V1 tinha a mesma quantidade de respostas/situações/conversas, mas também materiais de implementação e aceitação técnica. Esses extras não foram migrados. Não se multiplicou conteúdo igual entre as versões para inflar o pacote.

## Revisado na v.turbo
A pausa silenciosa diante de intenção não compreendida prevalece sobre a antiga recuperação genérica por pergunta. Exemplos de mídia não interpretada e de ambiguidade persistente foram ajustados. Contexto parcial conhecido ainda permite um único complemento específico. As novas seções ampliam voz, personas, humanização, livros, fontes e prática.

## Fora desta entrega
Legislação, políticas/métodos de plataforma, conexão, integração, arquitetura, programação, deploy, extensão e novo backup importável. Os arquivos estruturados presentes são dados de treinamento e evidência documental, não código de um aplicativo.
