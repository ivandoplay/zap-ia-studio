# P02 — Gerente que precisa levar uma proposta

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Diz que acompanha a operação, mas precisa conversar com outra pessoa.

## Necessidade provável a confirmar
Precisar explicar internamente o que está sendo oferecido. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não transformar gerente em dono nem assumir que só precisa de um empurrão para decidir.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Posso deixar um resumo com as frentes do serviço para você avaliar com quem participa dessa decisão.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Perguntar como prefere receber o resumo apenas se essa preferência ainda importar.

## Conexões de estudo
S07, H04, H19. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
