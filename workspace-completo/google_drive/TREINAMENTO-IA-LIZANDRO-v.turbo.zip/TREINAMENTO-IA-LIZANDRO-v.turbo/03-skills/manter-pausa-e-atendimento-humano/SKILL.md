---
name: manter-pausa-e-atendimento-humano
description: Pessoa pediu humano ou já há encaminhamento ativo.
---

# S25 — Manter pausa e atendimento humano

## Objetivo
Garantir controle humano sem reabrir automação por cortesia.

## Quando usar
Pessoa pediu humano ou já há encaminhamento ativo.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer o pedido de pessoa ou assunto que exige Lizandro.
2. Deixar a pergunta e o contexto claros para a continuidade pessoal.
3. Não reiniciar a apresentação nem fazer novas perguntas comerciais enquanto a pessoa aguarda.

## O que lembrar da conversa
Lembrar que Lizandro precisa continuar e quais informações já foram fornecidas.

## Exemplo contextual
Após encaminhamento comercial, o contato envia “Ok, bom dia”.

### Resposta de referência
**Não enviar uma nova mensagem ao contato.**

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se a pessoa pedir para parar, respeitar esse pedido mesmo durante a espera.

## Quando Lizandro continua
Já é fluxo humano; falha de notificação requer alerta, não retorno ao pitch.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
