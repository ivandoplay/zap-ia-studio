---
name: explicar-oferta-completa
description: A pessoa aceitou ouvir ou pediu explicação geral.
---

# S02 — Explicar oferta completa

## Objetivo
Apresentar a assessoria sem reduzi-la a anúncio e sem recitar pacote não confirmado.

## Quando usar
A pessoa aceitou ouvir ou pediu explicação geral.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Considerar o que já foi explicado e selecionar a parte que falta.
2. Ligar presença nas redes, conteúdo, divulgação por veículo e aproveitamento das conversas.
3. Fazer uma pergunta leve sobre a operação, se ainda faltar contexto.

## O que lembrar da conversa
Lembrar que a explicação geral já foi dada e registrar informações espontâneas sobre divulgação.

## Exemplo contextual
Após “Posso explicar?”, o contato responde “Pode sim”. Ainda não houve explicação.

### Resposta de referência
> Boa! A gente ajuda a cuidar da presença nas redes sociais, produz e publica conteúdo e pensa a divulgação de cada veículo, junto com estratégias de atendimento e acompanhamento. O tráfego pago entra nesse conjunto. Hoje, como vocês divulgam os veículos?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se já conhece a proposta e perguntou um detalhe, responder o detalhe em vez de reapresentar tudo.

## Quando Lizandro continua
Pedido de pacote, frequência, prazo específico ou contratação.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
