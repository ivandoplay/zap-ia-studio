---
name: qualificar-sem-repetir
description: Há interesse e falta algum dado relevante do cenário.
---

# S09 — Qualificar sem repetir

## Objetivo
Conseguir contexto suficiente com uma pergunta por vez e sem barreiras.

## Quando usar
Há interesse e falta algum dado relevante do cenário.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Aproveitar fatos já fornecidos, inclusive espontaneamente.
2. Escolher entre canal, anúncio atual, objetivo, atendimento ou papel, conforme utilidade.
3. Se já houver contexto suficiente e pedido de próximo passo, avançar sem exigir formulário.

## O que lembrar da conversa
Guardar dados com mensagem de origem; “não sei” e “prefiro não dizer” são respostas válidas.

## Exemplo contextual
“Tenho revenda, anuncio, mas o pessoal chama e não continua.”

### Resposta de referência
> Entendi. Então o ponto parece estar mais no avanço das conversas. Hoje, quem faz esse atendimento por aí?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não perguntar de novo se tem loja, se anuncia e média mensal na mesma rodada.

## Quando Lizandro continua
Interesse em contratar, pergunta comercial ou conflito persistente de contexto.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
