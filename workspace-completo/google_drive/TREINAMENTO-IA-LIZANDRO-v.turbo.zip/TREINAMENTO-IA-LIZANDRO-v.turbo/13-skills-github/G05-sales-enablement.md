# G05 — Sales enablement

## Fonte pública consultada nesta revisão
- Repositório: `coreyhaines31/marketingskills`.
- Arquivo: `skills/sales-enablement/SKILL.md`.
- Commit fixado: `e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b`.
- URL: https://github.com/coreyhaines31/marketingskills/blob/e85f3cbc2e4a79bf33b2a12e9bdd9087d414735b/skills/sales-enablement/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Organizar material conforme a situação.

## Adaptação autoral em português
Documentar objeção, contexto, resposta e evidência; preparar resumos por papel e momento de decisão.

## Aplicação neste pacote
H06, H09, H13, H15, H16, H18, H19.

## Filtros aplicados
Não incluir calculadora financeira, previsão de retorno ou condição comercial. Material de apoio não autoriza inventar prova.

## Exemplo aplicado
Uma ficha para consultor facilita encaminhamento sem presumir que ele decide pelo dono.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
