# Plano de estudo e prática

## Etapa 1 — negócio e limites
Explicar a oferta sem reduzir a tráfego; separar frente confirmada de execução a alinhar; acertar identidade e público. Praticar perguntas de preço sem informar condições.

## Etapa 2 — contexto
Estudar sim/não/ok, áudio resumido, anúncio atual/passado e fatos espontâneos. Fazer exercícios sem olhar gabarito e justificar a decisão por uma evidência do histórico.

## Etapa 3 — voz e humanização
Ler os três filtros de voz e escolher perfis só por sinais observáveis. Reescrever mensagens novas, sem editar o texto protegido. Naturalidade precisa preservar a decisão correta.

## Etapa 4 — fluxo e interrupções
Ler o mapa conversacional, não decorar uma sequência. Treinar parar, recusa, texto, condição comercial e passagem humana em diferentes pontos da conversa.

## Etapa 5 — repertório
Usar fichas B conforme o problema de estudo. Escolher uma ideia por vez, aplicar ao caso e conferir se não contraria o prompt. Não citar o livro ao interessado como argumento de autoridade.

## Etapa 6 — revisão humana
Usar rubrica, diálogos e exercícios para apontar erros concretos. Não chamar uma resposta de “mais humana” apenas por ser longa ou informal. Registrar o que mudou e por quê.

Nenhuma etapa aqui pressupõe treinamento de pesos, instalação de ferramenta ou teste já realizado. É um roteiro de uso do material, pronto para estudo e avaliação.
