# P08 — Quer organizar conteúdo e perfil

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Pergunta por posts, perfil, publicação ou presença nas redes.

## Necessidade provável a confirmar
Entender o que existe além de tráfego. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não responder só sobre anúncios pagos.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Sim, também trabalhamos produção e publicação de conteúdo e gestão da presença nas redes. A organização precisa acompanhar a realidade dos veículos e da operação.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Frequência, formato, gravação e visita não estão confirmados.

## Conexões de estudo
S04, S02, H04, H11. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
