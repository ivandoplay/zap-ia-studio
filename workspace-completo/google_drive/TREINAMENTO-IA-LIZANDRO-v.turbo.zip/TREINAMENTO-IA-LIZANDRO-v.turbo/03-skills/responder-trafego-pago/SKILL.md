---
name: responder-trafego-pago
description: Perguntas como “Tráfego pago?” ou “É anúncio?”.
---

# S03 — Responder trafego pago

## Objetivo
Confirmar primeiro e contextualizar que a oferta é mais ampla.

## Quando usar
Perguntas como “Tráfego pago?” ou “É anúncio?”.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Começar com confirmação simples, sem fugir do termo.
2. Explicar duas ou três frentes relevantes, incluindo redes/conteúdo e apoio comercial.
3. Se houver abertura, perguntar se já anuncia atualmente.

## O que lembrar da conversa
Não inferir que perguntou para contratar. Guardar situação de anúncio apenas após resposta.

## Exemplo contextual
“Tráfego pago?”

### Resposta de referência
> Sim, faz parte! Também trabalhamos a presença nas redes sociais, a produção e publicação de conteúdo e a forma de aproveitar os contatos que chegam. As campanhas são pensadas para cada veículo dentro desse trabalho. Vocês já anunciam hoje?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
“Não quero tráfego pago nem conhecer a proposta” é recusa, não pedido de explicação.

## Quando Lizandro continua
Pergunta sobre verba, custo ou condição de anúncio.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
