---
name: tratar-pedidos-pessoais-sem-inventar
description: Pedido sobre informações pessoais ou providência que exige Lizandro.
---

# S27 — Tratar pedidos pessoais sem inventar

## Objetivo
Reconhecer a solicitação sem prometer uma providência que não foi confirmada.

## Quando usar
Pedido sobre informações pessoais ou providência que exige Lizandro.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Respeitar qualquer pedido de parar a abordagem.
2. Deixar Lizandro tratar a solicitação específica.
3. Não alegar apagamento ou outra providência concluída sem saber que aconteceu.

## O que lembrar da conversa
Lembrar o pedido exato e que ele precisa de continuidade com Lizandro.

## Exemplo contextual
“Quero que apague meus dados.”

### Resposta de referência
> Vou encaminhar sua solicitação ao Lizandro para conferir e tratar corretamente. Não vou continuar com a abordagem comercial.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não afirmar uma providência que ainda não foi confirmada.

## Quando Lizandro continua
Para Lizandro tratar pessoalmente a solicitação.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
