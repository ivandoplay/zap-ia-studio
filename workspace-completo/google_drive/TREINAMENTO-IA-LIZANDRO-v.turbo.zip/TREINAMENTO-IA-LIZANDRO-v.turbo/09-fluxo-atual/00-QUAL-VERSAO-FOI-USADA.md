# Qual versão foi usada

## Fonte principal recuperada
**FUNIL-ALAVANCAGEM-DE-VENDAS-V4 (1).lzb**, arquivo disponível no Drive, com criação interna em **2026-10-23T09:15:57.401Z** e modificação no Drive em **25/10/2026**.

Fonte: https://drive.google.com/file/d/1qq73ROI0ZbQbGF6wNHHsSkTVPEZmycVQ/view

SHA-256 do original: `0d049b12ebe7aea5fe89552e73389d8c7a7c59add8d3b308e042596405e50771`.

## Comparação com a outra recuperação
O `fluxo.zip` contém `FUNIL-LEADZY-REVISAO4 (3).lzb`, com criação interna em **2026-10-22T23:07:06.451Z**. A criação interna do arquivo direto é posterior, além da data posterior no Drive. Por isso ele foi selecionado como a referência mais nova **entre os arquivos recuperados**, sem presumir que seja a versão mais recente de toda a conta ou de materiais não disponíveis.

Ambos se chamam Revisão 4 nos fluxos internos e estão em rascunho. O arquivo selecionado não é chamado de “publicado” ou “homologado”. O pacote traduz conhecimento e comportamento; não produz novo backup importável nem altera o original.

## Contagem independente da fonte selecionada
- 105 códigos lógicos de mensagem, de M01 a M105.
- 113 itens/bolhas na biblioteca, contando os desdobramentos com sufixo.
- Dois fluxos, ambos `draft`.
- 114 nós e 480 arestas ao somar os dois fluxos.
- 52 nós de envio de texto.
- 39 identificadores de bolhas referenciados por esses envios, correspondentes a 31 códigos lógicos M.

A descrição ainda declara 32 textos enviados pelo grafo. A contagem do arquivo selecionado, separando bolhas de códigos lógicos, resultou nos números acima; a declaração não foi repetida como verificação independente. Nós de envio, mensagens únicas e possíveis envios reais não são a mesma medida.

## Coerência com o pedido atual
As confirmações do usuário sobre gestão, produção/publicação e personalização por veículo prevalecem sobre uma formulação legada que pareça apenas anúncios ou exclua independentes. M01–M13 aprovadas continuam em fonte própria, sem substituição pelas variantes R4.
