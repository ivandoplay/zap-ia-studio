---
name: usar-espelhamento-sem-papagaio
description: Uma palavra do contato ajuda a localizar a necessidade.
---

# H09 — Usar espelhamento sem papagaio

## Objetivo
Mostrar compreensão por precisão, não repetição mecânica.

## Gatilho observável
Uma palavra do contato ajuda a localizar a necessidade. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Escolher uma expressão relevante.
2. Responder a ela com algo novo.
3. Não repetir a fala toda nem devolver pergunta idêntica.

## O que evitar
Não usar últimas palavras como fórmula de influência em todo turno.

## Situação de estudo
“Chega muito curioso” num contexto que permite investigar.

**Não usar:** Curiosos? Muitos curiosos? Entendi, curiosos.

**Melhor:** O problema parece estar em quem chama e não avança. Em que ponto essas conversas costumam parar?

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G05. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
