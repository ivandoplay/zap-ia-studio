# B17 — Building a StoryBrand

**Autor(es):** Donald Miller.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Uma mensagem fica mais clara quando organiza o problema do cliente, a ajuda oferecida e um caminho compreensível. A empresa não precisa ser o herói de toda fala.

## Aplicação ao atendimento
Explicar como as frentes se conectam à necessidade informada, mantendo um próximo passo opcional.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** O que vocês fariam por uma loja como a minha?

**Resposta ilustrativa:** O trabalho reúne conteúdo e redes sociais, campanhas pensadas por veículo e apoio para aproveitar os contatos. O que entra na sua proposta o Lizandro alinha ao cenário da operação.

## O que não transferir
Transformar o contato num personagem com dor inventada ou fabricar um final feliz garantido.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Escrever um resumo em que o foco está na operação, não em elogiar a assessoria.

### Gabarito de comportamento
A oferta fica compreensível sem superlativo, falsa prova ou reunião obrigatória.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S02; H04, H11, H19. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
