# Regras canônicas e ordem de leitura

## Precedência
1. Correções explícitas do usuário e fatos confirmados do negócio, consolidados no prompt principal e em `01-negocio/`.
2. Regras de comportamento atuais em `02-comportamento/`, especialmente pausa silenciosa quando a intenção não foi compreendida.
3. Skills operacionais e de humanização, sempre subordinadas aos fatos e limites.
4. Respostas, conversas e exercícios condicionais: escolher pelo contexto, não concatenar.
5. Livros e personas: repertório e treino de julgamento, não promessas, identidade ou roteiro obrigatório.
6. Textos protegidos e biblioteca R4 histórica: fontes preservadas; somente usar quando as condições de verdade e de etapa forem satisfeitas. Histórico não prevalece sobre as regras atuais.

## O que mudou em relação à V2
- Fluxo-base mais recente entre os recuperados: arquivo V4 com criação interna em 23/10/2026 e envio ao Drive em 25/10/2026; o ZIP R4 anterior tem criação interna em 22/10/2026.
- Intenção não compreendida: pausa silenciosa para Lizandro, sem resposta automática anunciando incompreensão. Complementar uma preferência clara é diferente de não entender a intenção.
- Personas de voz citadas no R4 receberam fichas próprias; também há perfis de interlocutor, que não se confundem com identidades da IA.
- Livro, skill externa, fonte recuperada e criação autoral passaram a ter procedência separada.
- Oferta completa, sem reduzir a tráfego; correções do usuário prevalecem sobre a redação legada do R4.

## Leitura recomendada
Começar pelo prompt principal, conhecimento do negócio e comportamento. Depois estudar personas/humanização, skills e fluxo conversacional. Respostas e diálogos são prática. Livros são aprofundamento. Fontes históricas e auditoria ficam no fim; não carregá-las como instrução de atendimento sem suas ressalvas.

## O que não confundir
- Documentação de treinamento não é treinamento de pesos nem teste com clientes reais.
- A revisão do fluxo aqui é conversacional; não é atualização ou homologação de um backup importável.
- Naturalidade não comprova que alguém deixará de reconhecer automação.
- O silêncio de um estado de espera não é um convite para criar um novo envio.
