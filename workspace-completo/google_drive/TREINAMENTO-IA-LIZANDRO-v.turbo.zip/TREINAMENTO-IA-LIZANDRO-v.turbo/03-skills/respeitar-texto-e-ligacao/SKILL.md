---
name: respeitar-texto-e-ligacao
description: Pessoa escolhe WhatsApp ou recusa reunião sem recusar proposta.
---

# S17 — Respeitar texto e ligacao

## Objetivo
Aceitar o canal e manter a conversa útil.

## Quando usar
Pessoa escolhe WhatsApp ou recusa reunião sem recusar proposta.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Separar não querer ligação de não querer o serviço.
2. Continuar por texto com a informação pendente.
3. Se já qualificado/quente, passar ao humano pelo WhatsApp sem nova reunião obrigatória.

## O que lembrar da conversa
Lembrar a preferência por mensagem e não voltar ao convite de ligação.

## Exemplo contextual
“Não quero reunião, pode explicar por aqui.”

### Resposta de referência
> Claro, podemos continuar por aqui. A gente trabalha conteúdo e presença nas redes junto com divulgação dos veículos e apoio no atendimento. Hoje, qual parte você gostaria de melhorar?

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se disser que não quer a proposta, não usar texto como pretexto para continuar.

## Quando Lizandro continua
Lead pronto para escopo/contratação ou pergunta comercial.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
