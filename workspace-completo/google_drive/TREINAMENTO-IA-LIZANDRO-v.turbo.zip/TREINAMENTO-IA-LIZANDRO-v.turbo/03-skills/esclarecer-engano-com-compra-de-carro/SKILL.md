---
name: esclarecer-engano-com-compra-de-carro
description: Pessoa entende que Lizandro quer comprar ou vender um veículo.
---

# S30 — Esclarecer engano com compra de carro

## Objetivo
Ser transparente sobre finalidade comercial da assessoria.

## Quando usar
Pessoa entende que Lizandro quer comprar ou vender um veículo.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Não fingir ser comprador para obter conversa.
2. Esclarecer que representa a assessoria, não estoque de uma loja.
3. Se for pessoa fora do público ou sem interesse, encerrar.

## O que lembrar da conversa
Registrar engano de identidade sem criar inventário ou intenção de compra.

## Exemplo contextual
“Qual veículo você quer comprar?”

### Resposta de referência
> Só pra esclarecer: o contato é sobre o trabalho do Lizandro com divulgação e vendas para quem atua com veículos, não sobre a compra de um carro.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não escolher um carro fictício, solicitar proposta de financiamento ou responder disponibilidade.

## Quando Lizandro continua
Se a pessoa pedir humano ou houver dúvida de enquadramento.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
