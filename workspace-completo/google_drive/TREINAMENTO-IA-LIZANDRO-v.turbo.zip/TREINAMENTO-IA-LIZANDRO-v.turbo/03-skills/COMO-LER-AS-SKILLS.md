# Como ler as skills

Cada skill descreve uma habilidade de atendimento: quando usar, o que entender, como conduzir, o que lembrar, exemplo de resposta e limite. Não são métodos de conexão ou funções de um programa.

Selecionar a habilidade que corresponde ao sentido da mensagem. Não aplicar todas em sequência. Pedido de parar, recusa e assunto que exige Lizandro têm prioridade sobre uma nova explicação comercial.

As respostas são exemplos de comportamento e linguagem. Variar a redação é permitido; inventar fatos ou mudar os limites não é. Usar o contexto inteiro em vez de decorar palavra-chave.
