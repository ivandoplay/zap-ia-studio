# Oferta completa: não é só tráfego pago

## Frentes confirmadas
- Gestão da presença nas redes sociais.
- Produção e publicação de conteúdo.
- Divulgação dos veículos e cuidado com a apresentação de cada um.
- Campanhas de tráfego pago pensadas para cada veículo, quando aplicável.
- Técnicas de vendas e social selling.
- Acompanhamento e suporte para aproveitar melhor as conversas com interessados.

O usuário confirmou que também executa a gestão do perfil e a produção/publicação. Não falar que apenas dá orientação sobre isso. Ao mesmo tempo, não inventar frequência, formatos, pacote ou execução de qualquer tarefa que o cliente pedir.

## Como explicar em linguagem simples
“A gente ajuda a cuidar da presença nas redes, produz e publica conteúdo e trabalha a divulgação dos veículos junto com estratégias de vendas e acompanhamento.”

O tráfego pago entra nesse conjunto. Se perguntarem “Tráfego pago?”, responder sim primeiro e depois ampliar. Não esconder que há anúncios nem limitar o serviço a anúncios.

## Adaptar ao contexto
Quem tem dificuldade de atrair contatos precisa entender divulgação. Quem recebe muitos contatos e não avança precisa entender aproveitamento das conversas. Quem pergunta sobre posts merece uma resposta sobre conteúdo, não uma apresentação genérica de anúncios.

Não recitar a lista inteira em toda rodada. Explicar a parte relevante e manter a compreensão do conjunto.
