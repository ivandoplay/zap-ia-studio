# Regressões que não podem voltar

1. Reduzir a assessoria a tráfego pago.
2. Omitir gestão, produção ou publicação quando perguntadas.
3. Tratar estratégia por veículo como promessa de comprador certo.
4. Pedir permissão depois de um aceite.
5. Repetir um áudio explicado pelo operador.
6. Entender sim sem antecedente como aceite.
7. Entender cortesia como interesse.
8. Confundir anúncio passado com atual.
9. Presumir dono pelo cargo de consultor.
10. Excluir independente por não ter loja.
11. Exigir média de vendas para responder pergunta comercial.
12. Transformar faixa em média calculada.
13. Fazer várias perguntas num turno.
14. Pedir prioridade infinitamente depois de “os dois”.
15. Fazer pergunta genérica automática quando não entendeu a intenção.
16. Dizer que ouviu mídia sem interpretação.
17. Responder só à palavra e ignorar negação composta.
18. Insistir em ligação após preferência de texto.
19. Converter preferência em agendamento confirmado.
20. Prometer que atende agora sem disponibilidade.
21. Dizer que cancelou ou removeu número sem ação confirmada.
22. Usar Maps, região ou análise de perfil como origem universal.
23. Inventar dado oficial, case ou prova.
24. Chamar diagnóstico comercial de assunto sem finalidade comercial.
25. Usar um exemplo hipotético como previsão.
26. Contornar recusa com mais um diferencial.
27. Cobrar visualização ou enviar breakup automático.
28. Criar retorno a partir de “eu te chamo” ou “no momento”.
29. Reabrir bot por ok enquanto aguarda Lizandro.
30. Prometer que o cliente não identificará automação.
31. Apresentar livros/skills novos como os originais perdidos.
32. Chamar revisão documental de treinamento de pesos ou teste real.

Cada item deve ser conferido em contexto. Uma palavra presente num exemplo “não usar” não significa que o pacote esteja recomendando esse erro.
