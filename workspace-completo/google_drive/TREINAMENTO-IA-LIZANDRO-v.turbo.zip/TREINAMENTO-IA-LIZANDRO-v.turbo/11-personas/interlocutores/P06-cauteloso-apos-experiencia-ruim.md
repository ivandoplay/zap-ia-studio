# P06 — Cauteloso após experiência ruim

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Conta que um serviço anterior não trouxe o que esperava.

## Necessidade provável a confirmar
Evitar repetir uma experiência decepcionante. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não atacar outro profissional nem concluir qual foi a falha.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Faz sentido querer entender melhor antes de avaliar outro trabalho. O que mais te incomodou naquela experiência?

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Só investigar se houver abertura; “já tentei, não quero mais” é recusa.

## Conexões de estudo
S12, S16, H06, H16. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
