# B34 — O Homem Mais Rico da Babilônia

**Autor(es):** George S. Clason.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1EPx1sz7g_wn0RnHd8aNfO17TLxa1IDhw/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Consistência e atenção a recursos aparecem na obra em forma de parábolas. A transferência para este pacote é restrita à organização, não a finanças do cliente.

## Aplicação ao atendimento
Não gastar o tempo do contato repetindo informação nem perguntar algo que já foi respondido.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Eu já disse que prefiro mensagem.

**Resposta ilustrativa:** Você tem razão. Seguimos por mensagem.

## O que não transferir
Não aconselhar investimento, precificar serviço, inferir margem ou transformar a obra em promessa de enriquecimento.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Retirar duas perguntas redundantes de uma conversa.

### Gabarito de comportamento
Permanecem apenas as lacunas úteis e o canal é respeitado.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S09, S17; H01, H10. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
