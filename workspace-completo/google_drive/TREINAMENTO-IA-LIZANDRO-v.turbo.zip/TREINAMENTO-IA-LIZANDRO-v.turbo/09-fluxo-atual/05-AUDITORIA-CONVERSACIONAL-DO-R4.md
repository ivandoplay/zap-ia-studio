# Auditoria conversacional da fonte R4 selecionada

## O que foi verificado
Leitura da biblioteca, metadados e referências estruturais: 105 códigos, 113 bolhas, dois fluxos. Os nós têm identificadores únicos dentro de cada fluxo; não há aresta com origem/destino ausente nem referência de envio para mensagem inexistente. Isso não valida execução, interpretação de linguagem, estado do aplicativo ou atendimento real.

## Contagem da seleção
- R4 — Atendimento Principal (início manual): 110 nós, 477 arestas, 51 nós de envio; status draft.
- R4 — Saída Global (opt-out) — PUBLICAR SÓ APÓS HOMOLOGAÇÃO: 4 nós, 3 arestas, 1 nós de envio; status draft.

## Pontos que exigiram filtro no treinamento
1. **Origem e perfil:** M01, M01b, M36, M37b, M102 e M103 contêm alegações de origem, análise de perfil ou dado público. Não usar sem prova do caso real.
2. **Oferta reduzida:** diversas falas enfatizam anúncio e conversa. A regra atual inclui gestão, produção/publicação e campanhas por veículo.
3. **Preço com pergunta extra:** M21b e a formulação manual M09 pedem volume. O atendimento atual não condiciona resposta comercial a nova qualificação; Lizandro continua.
4. **Promessa de disponibilidade:** M26, M72, M81 e M84 sugerem atendimento em instantes. Não prometer sem confirmação.
5. **Ações não verificadas:** M55 afirma retirada de lista e ausência de contato por toda a equipe; M74 afirma cancelamento; M83 promete material já separado. O assistente não afirma ação só por ser desejável.
6. **Mídia:** M75 e M76 são declarações de escuta/análise futura. Quando o conteúdo não foi compreendido, a regra atual é pausa silenciosa; um resumo real do operador muda o caso.
7. **Qualificação repetida:** M44 pode refazer uma pergunta já respondida; M62 pode exigir prioridade mesmo depois de “os dois”. A base atual usa os fatos e aceita as duas necessidades.
8. **Permissão repetida:** M66 só cabe se realmente falta abertura. Não reaplicar depois de aceite ou de áudio explicativo já contextualizado.
9. **Prova/garantia de processo:** M48 afirma “o que eu garanto é o processo”. Não ampliar isso para uma garantia contratual ou desempenho; explicar a oferta confirmada e os limites.
10. **Hipóteses numéricas:** a M12 não vira previsão. A fonte aprovada é preservada; não usar número hipotético como meta ou promessa.
11. **Pós-conversa e retornos:** M91–M100 não formam cadência automática. Dependem de autorização, ação humana e fatos reais.
12. **Prioridade por palavras:** preferências de canal, recusa e parar podem coexistir numa frase. Há risco de leitura inadequada se só palavras e ordem forem usadas. Isso é um risco documental, não um defeito de execução demonstrado.

## Divergência de contagem
A descrição declara 32 textos do grafo. No arquivo selecionado existem 52 nós de envio, 39 bolhas referenciadas e 31 códigos M referenciados. Essas unidades foram explicitadas em vez de repetir a declaração como contagem própria.

## O que não foi executado
Não houve importação, publicação, teste autenticado da extensão, chamada a clientes, treinamento de pesos, medição de conversão ou verificação de filas e agenda. Nenhuma ausência de travas ou perfeição do atendimento é prometida.
