# Atalho por assunto

Consultar a condição, não só a frase. Os códigos levam às seções do catálogo de respostas; não são enviados à pessoa.

| Assunto | Referências úteis |
|---|---|
| O que faz / oferta completa | R001, R002, R034, R117, R118, R143, R163 |
| Tráfego pago e personalização por veículo | R003, R042, R126, R127 |
| Gestão, conteúdo e publicação | R004, R035, R119 |
| Frequência, formato, filmagem e fotos | R036–R039, R122–R124, R139, R158, R159 |
| Sim, permissão e canal | R005, R026, R066, R067, R162 |
| Áudio já resumido pelo operador | R006 |
| Consultor, equipe ou sócio | R007, R053–R055 e perfis P02/P03 |
| Independente e estoque variável | R008, R044, R128 |
| Anúncio atual e passado | R010, R045–R048 |
| Agência e experiência anterior | R011, R012 e conversas D005/D006 |
| Curiosos e avanço de conversa | R009, R013, R064 |
| Preço, condição, proposta e contratação | R015, R069–R073, R107, R135, R136, R138, R141, R144, R149 |
| Garantia, prazo e prova | R016, R074–R076, R145 |
| Canal e agenda | R017, R018, R077–R084, R148, R150 |
| Recusa, parar e iniciativa | R019–R023, R085–R092, R106, R108 |
| Mídia não interpretada | R024, R102 — pausa silenciosa |
| Aguardando Lizandro | R025, R104 — sem novo texto automático |
| Intenção não compreendida | R116 — pausa silenciosa |
| Identidade e origem | R014, R095–R101, R146, R147, R152 |
| Não é venda de carro / financiamento | R030, R093, R094, R129, R131 |
| Pedido de pessoa | R096, R153 |
| Material e dado verificável | R075, R100, R154 |
| Correção e histórico repetido | R032, R111, R112, R151 |
| Escopo e acessos | R029, R040, R041, R114, R120, R133, R140, R157 |

Os exemplos Rxxx não substituem os M01–M13 protegidos. “Sem texto” significa não enviar, não explicar o nome da ação ao contato.
