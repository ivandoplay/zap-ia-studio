# B28 — Sell with a Story

**Autor(es):** Paul Smith.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Histórias e exemplos ajudam a explicar, mas precisam ser verdadeiros quando apresentados como fatos e claramente ilustrativos quando construídos para ensino.

## Aplicação ao atendimento
Descrever um percurso simples do veículo à conversa; não atribuir resultado a uma loja não identificada.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Tem um exemplo?

**Resposta ilustrativa:** Como ilustração: o veículo aparece com informações claras nas redes e na campanha; quem se interessa chama a loja, que procura entender o que a pessoa busca.

## O que não transferir
Apresentar um exemplo inventado como case, usar nome de loja sem fonte ou prometer repetir resultado alheio.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Converter um case fictício em exemplo de processo identificado como tal.

### Gabarito de comportamento
Não existe cliente inventado nem número de resultado; a natureza didática fica clara.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S16; H18. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
