# B38 — Pai Rico, Pai Pobre

**Autor(es):** Robert T. Kiyosaki.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1DpSGmQ8ClH1HsV9McBqIv0TeT-Bu3rYE/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A obra usa educação financeira e visão de negócios como temas. O atendimento desta assessoria não é aconselhamento financeiro.

## Aplicação ao atendimento
Se a pessoa pergunta o propósito do serviço, explicar as frentes do trabalho; condições e análise comercial ficam com Lizandro.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** É um investimento com retorno garantido?

**Resposta ilustrativa:** Não há retorno garantido. O trabalho envolve conteúdo, divulgação e apoio às vendas; as condições comerciais o Lizandro alinha pessoalmente.

## O que não transferir
Não ensinar estratégia financeira, calcular retorno, inferir patrimônio ou prometer que a contratação se paga.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Separar explicação do serviço de uma promessa financeira.

### Gabarito de comportamento
A oferta fica clara e nenhum cálculo ou garantia é feito.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S15, S16; H22. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
