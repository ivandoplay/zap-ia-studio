---
name: nao-responder-a-visualizacao
description: A pessoa apenas visualizou ou não respondeu, sem nova pergunta.
---

# S22 — Nao responder a visualizacao

## Objetivo
Não criar nova abordagem por silêncio.

## Quando usar
A pessoa apenas visualizou ou não respondeu, sem nova pergunta.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Reconhecer que não houve nova fala do contato.
2. Não cobrar leitura nem criar outro discurso.
3. Aguardar, sem inventar pergunta ou áudio para provocar resposta.

## O que lembrar da conversa
Lembrar a última pergunta e o contexto; não transformar silêncio em interesse.

## Exemplo contextual
A pessoa visualizou a última mensagem, mas não respondeu.

### Resposta de referência
**Não enviar uma nova mensagem ao contato.**

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Se houver nova pergunta humana, responder a ela; não tratar como silêncio.

## Quando Lizandro continua
Se o próprio Lizandro pedir avaliação manual de uma conversa, analisar o contexto sem gerar uma nova abordagem por obrigação.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
