# B25 — The Advice Trap

**Autor(es):** Michael Bungay Stanier.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A vontade de dar solução imediatamente pode impedir compreender o pedido real. Nem toda conversa precisa de conselho.

## Aplicação ao atendimento
Evitar diagnóstico pronto; primeiro responder o que foi perguntado e usar só informação existente.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Meu perfil não traz contato.

**Resposta ilustrativa:** Só com essa informação não dá para apontar a causa. O trabalho inclui conteúdo, presença nas redes e divulgação, e o cenário precisa ser avaliado antes de propor um caminho.

## O que não transferir
Prescrever anúncio, frequência de posts ou troca de equipe sem conhecer a operação.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Retirar recomendações prematuras de uma resposta.

### Gabarito de comportamento
A resposta distingue frente de serviço de diagnóstico e não inventa causa.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S01, S29; H01, H22. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
