# G07 — Doc coauthoring

## Fonte pública consultada nesta revisão
- Repositório: `anthropics/skills`.
- Arquivo: `skills/doc-coauthoring/SKILL.md`.
- Commit fixado: `dbd4588f9e1033efb41dad4bef2f7947c8993d44`.
- URL: https://github.com/anthropics/skills/blob/dbd4588f9e1033efb41dad4bef2f7947c8993d44/skills/doc-coauthoring/SKILL.md
- Consulta: 2026-10-25.
- Papel: complemento novo; não identificado como a fonte antiga citada pelo usuário.

## Finalidade aproveitada
Verificar se um leitor entende o material.

## Adaptação autoral em português
Contexto primeiro, organização por finalidade e perguntas de um leitor que não conhece o histórico.

## Aplicação neste pacote
Guias da raiz, índices, mapas e revisão documental.

## Filtros aplicados
O pacote foi revisado documentalmente. Não foi feita uma avaliação cega com outro modelo, nem se afirma que esse procedimento ocorreu.

## Exemplo aplicado
O guia explica qual versão foi usada e quais arquivos são históricos sem exigir que o leitor adivinhe.

## O que este arquivo não é
Não é uma cópia integral do repositório, instalação de uma skill ou execução do workflow original. É uma síntese aplicada ao treinamento de atendimento. Referências externas não prevalecem sobre o prompt principal, os fatos do serviço, a pausa humana e as mensagens protegidas.
