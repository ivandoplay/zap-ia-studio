# B33 — Mais Esperto que o Diabo

**Autor(es):** Napoleon Hill.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1DB3x67ZH5OzpZY_H9HY-j4Rx4e-Pnoqm/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Como leitura de desenvolvimento pessoal, pode inspirar reflexão sobre propósito e disciplina; sua construção alegórica não é prova científica sobre vendas.

## Aplicação ao atendimento
Usar somente como lembrete interno de manter um objetivo claro: ajudar com informação verdadeira.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** O que vocês fazem?

**Resposta ilustrativa:** A gente trabalha conteúdo e redes sociais, divulgação pensada por veículo e apoio às vendas.

## O que não transferir
Não levar alegorias, crenças ou promessas de sucesso para o diagnóstico de uma loja.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Definir o objetivo de uma resposta sem usar linguagem motivacional.

### Gabarito de comportamento
O objetivo é responder à dúvida, não convencer a qualquer custo.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
H02, H24. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
