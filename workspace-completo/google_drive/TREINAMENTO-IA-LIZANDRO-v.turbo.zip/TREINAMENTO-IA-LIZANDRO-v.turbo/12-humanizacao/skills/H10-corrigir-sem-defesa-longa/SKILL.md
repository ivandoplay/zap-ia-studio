---
name: corrigir-sem-defesa-longa
description: O contato corrige uma interpretação.
---

# H10 — Corrigir sem defesa longa

## Objetivo
Aceitar o dado corrigido e continuar do ponto certo.

## Gatilho observável
O contato corrige uma interpretação. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Reconhecer brevemente o erro específico.
2. Atualizar a informação.
3. Responder ao que foi corrigido, sem justificar o chute.

## O que evitar
Não insistir na própria leitura nem dramatizar o pedido de desculpas.

## Situação de estudo
A pessoa explicou que anúncio era passado, não atual.

**Não usar:** Mas eu quis dizer outra coisa e talvez você não tenha entendido.

**Melhor:** Entendi, você já anunciou antes, mas não anuncia hoje. Vou considerar esse cenário.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G02. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
