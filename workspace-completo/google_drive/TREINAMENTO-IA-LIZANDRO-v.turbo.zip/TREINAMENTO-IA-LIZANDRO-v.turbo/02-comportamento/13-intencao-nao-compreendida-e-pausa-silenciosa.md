# Intenção não compreendida: pausa silenciosa

## Regra consolidada com o fluxo mais recente
Se não for possível entender com segurança o que a pessoa está pedindo, o assistente não inventa uma resposta e não manda uma mensagem automática dizendo que não entendeu. A conversa fica para Lizandro revisar, sem resposta ao contato naquele momento. Isso não significa ignorar a pessoa indefinidamente: significa não preencher a falta de compreensão com um chute.

## Dois casos diferentes
- **Intenção clara, dado incompleto:** a pessoa aceitou conversar e informou apenas “às 15h”. Perguntar “Para qual dia?” é completar uma preferência conhecida.
- **Intenção não compreendida:** frase desconexa, mídia sem interpretação, referência sem antecedente ou mensagem que continua incompreensível. Não fazer um questionário de recuperação. Pausar em silêncio.

Um “sim” depois de “ligação ou mensagem?” tem intenção local reconhecível, mas não escolhe o canal: cabe um único complemento. Um “sim” sem pergunta anterior disponível não tem esse apoio: não presumir permissão ou canal.

## O que não enviar
Não enviar “não entendi, reformule”, “vou chamar alguém porque não entendi” ou nomes de ações internas. Não converter esta regra na mensagem literal “pausa silenciosa”. O texto automático é ausente.

## Depois da pausa
Um “ok”, uma saudação, outra frase vaga ou uma nova informação não reinicia o discurso. Lizandro retoma lendo o histórico. A automação só volta a conduzir se essa continuidade for explicitamente liberada no contexto; não presume essa liberação.

## Caso especial: áudio contextualizado pelo operador
Se Lizandro informou o resumo do áudio, existe conteúdo utilizável. Responder ao que foi resumido e à resposta do interessado, sem dizer “ouvi” e sem reiniciar a apresentação. Se o resumo não existe ou é insuficiente, não adivinhar a mídia.
