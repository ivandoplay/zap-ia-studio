# P11 — Objetivo e com pouco tempo

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Pede resumo, resposta direta ou diz que não pode parar agora.

## Necessidade provável a confirmar
Receber o essencial sem reunião forçada. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não usar resposta curta como prova de irritação ou falta de interesse.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Em resumo: conteúdo e redes sociais, campanhas pensadas por veículo e apoio para aproveitar melhor os contatos. Podemos seguir por mensagem.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Se disser que ele chama depois, encerrar e deixar a iniciativa com ele.

## Conexões de estudo
S19, S17, H02, H08. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
