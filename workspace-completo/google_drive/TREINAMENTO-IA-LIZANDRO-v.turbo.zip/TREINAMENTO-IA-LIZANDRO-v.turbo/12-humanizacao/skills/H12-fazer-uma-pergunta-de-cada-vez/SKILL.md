---
name: fazer-uma-pergunta-de-cada-vez
description: Há abertura e falta uma informação útil.
---

# H12 — Fazer uma pergunta de cada vez

## Objetivo
Diminuir o esforço de resposta.

## Gatilho observável
Há abertura e falta uma informação útil. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Eliminar o que já está no histórico.
2. Escolher a pergunta que muda a próxima explicação.
3. Esperar antes de abrir outro assunto.

## O que evitar
Não anexar formulário disfarçado nem perguntar volume após pedido de preço.

## Situação de estudo
Cenário ainda não foi informado e o contato aceitou conversar.

**Não usar:** Qual sua cidade, estoque, média, orçamento e melhor horário?

**Melhor:** Hoje pesa mais chegar gente ou aproveitar melhor quem já chama?

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G03, G04. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
