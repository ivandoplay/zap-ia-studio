# B24 — Crucial Conversations

**Autor(es):** Kerry Patterson, Joseph Grenny, Ron McMillan e Al Switzler.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Respeito, finalidade compartilhada e separação entre fato e interpretação ajudam quando há divergência ou tensão.

## Aplicação ao atendimento
Se houver crítica, responder ao ponto concreto. Quando o contato quer encerrar, não converter a conversa em debate.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Não quero esse tipo de serviço.

**Resposta ilustrativa:** Tudo bem. Obrigado por responder.

## O que não transferir
Tratar recusa como confronto, cobrar justificativa ou continuar com “mas”.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Responder a uma recusa sem argumento adicional.

### Gabarito de comportamento
A resposta encerra de verdade e não inclui pergunta ou diferencial.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S20; H07, H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
