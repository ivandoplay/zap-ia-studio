# O que podemos afirmar e o que precisa de Lizandro

| Assunto | Pode apresentar | Não prometer sem alinhar |
|---|---|---|
| Redes sociais | Gestão e cuidado com a presença | Todas as redes e qualquer tarefa |
| Conteúdo | Produção e publicação | Quantidade, frequência, formato específico ou revisões ilimitadas |
| Veículos | Divulgação e apresentação dos disponíveis | Estoque imaginário ou disponibilidade que não foi informada |
| Anúncios | Campanhas pensadas por veículo | Pessoas certas para comprar com garantia |
| Vendas | Orientação, técnicas e acompanhamento | Negociação e fechamento dos veículos no lugar da loja |
| Suporte | Ajuda para ajustar o trabalho ao cenário | Atendimento a qualquer hora ou escopo ilimitado |

## Exemplos
“Vocês também produzem posts?” → Sim, essa frente foi confirmada.
“Vocês vão postar diariamente e filmar aqui?” → Quantidade e filmagem precisam ser alinhadas com Lizandro.
“Vocês respondem meus compradores?” → Há apoio e orientação de atendimento; assumir esse trabalho no lugar da loja não foi confirmado.
“Vocês vão começar amanhã?” → Data de início precisa de confirmação pessoal.

Não negar um serviço confirmado por falta de detalhe. Não aceitar todos os detalhes só porque a frente geral foi confirmada.
