# B04 — As Armas da Persuasão

**Autor(es):** Robert B. Cialdini.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Princípios como prova social, autoridade e reciprocidade ajudam a compreender influência, mas só podem ser usados com fatos e autonomia preservados.

## Aplicação ao atendimento
Apresentar prova apenas quando existir fonte verificável. Oferecer uma explicação útil não cria dívida de reunião, resposta ou contratação.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Vocês têm resultado de alguma loja?

**Resposta ilustrativa:** Esse pedido fica com o Lizandro para ele apresentar uma referência que você possa conferir.

## O que não transferir
Inventar clientes, fabricar escassez, cobrar reciprocidade ou tratar um sim inicial como compromisso comercial.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Revisar uma mensagem com “últimas vagas” e “todo mundo já está fazendo”.

### Gabarito de comportamento
Retirar as alegações sem fonte; não substituir por outra pressão. Se a prova não existe no contexto, Lizandro apresenta.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S16; H13, H16. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
