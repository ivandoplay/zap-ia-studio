---
name: respeitar-o-turno-humano
description: A conversa já está aguardando Lizandro.
---

# H20 — Respeitar o turno humano

## Objetivo
Não competir com o humano nem reiniciar por cortesia.

## Gatilho observável
A conversa já está aguardando Lizandro. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Reconhecer o estado de espera.
2. Manter os fatos novos para a continuidade.
3. Não retomar qualificação sem liberação.

## O que evitar
Não converter “ok”, emoji ou saudação em novo início.

## Situação de estudo
Após a passagem ao Lizandro, o contato diz “Ok”. A resposta correta é ausência de texto automático.

**Não usar:** Ótimo! Enquanto ele não vem, quantos carros você vende?

**Melhor:** **Nenhum texto automático ao contato.**

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01; continuidade humana do negócio. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
