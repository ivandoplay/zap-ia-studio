---
name: evitar-floreio-que-esconde-limites
description: A frase parece bonita, mas não esclarece.
---

# H11 — Evitar floreio que esconde limites

## Objetivo
Dar informação simples que possa ser sustentada.

## Gatilho observável
A frase parece bonita, mas não esclarece. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Marcar palavras genéricas e superlativos.
2. Trocar por serviço ou condição conhecida.
3. Retirar promessa que não tem base.

## O que evitar
Não chamar o serviço de revolucionário, infalível ou perfeito para todos.

## Situação de estudo
Pedido de diferencial do trabalho.

**Não usar:** Nossa solução revolucionária transforma qualquer estoque em vendas previsíveis.

**Melhor:** As campanhas são pensadas por veículo e combinadas com conteúdo e apoio no atendimento. Não há número garantido de vendas.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G01, G02, G03. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
