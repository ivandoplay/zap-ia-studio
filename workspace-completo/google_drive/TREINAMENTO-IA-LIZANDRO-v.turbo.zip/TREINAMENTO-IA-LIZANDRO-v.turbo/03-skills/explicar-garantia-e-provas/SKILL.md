---
name: explicar-garantia-e-provas
description: Pergunta sobre resultados, garantia, prazo de vendas ou referências.
---

# S16 — Explicar garantia e provas

## Objetivo
Distinguir finalidade, exemplo didático e evidência real.

## Quando usar
Pergunta sobre resultados, garantia, prazo de vendas ou referências.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Não oferecer garantia de desempenho nem converter hipótese em meta.
2. Se pedir exemplo de processo, identificar como didático.
3. Se pedir caso real/prova, encaminhar para material verificável.

## O que lembrar da conversa
Lembrar que a pessoa pediu prova e não inventar um caso.

## Exemplo contextual
“Vocês garantem que vou vender?”

### Resposta de referência
> Não seria correto garantir vendas ou um número de interessados. O trabalho busca melhorar divulgação, conteúdo e aproveitamento das conversas, mas o resultado também depende da operação e do mercado.

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não compensar a resposta com promessa forte na frase seguinte.

## Quando Lizandro continua
Referência real, comprovação ou exigência de garantia contratual.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
