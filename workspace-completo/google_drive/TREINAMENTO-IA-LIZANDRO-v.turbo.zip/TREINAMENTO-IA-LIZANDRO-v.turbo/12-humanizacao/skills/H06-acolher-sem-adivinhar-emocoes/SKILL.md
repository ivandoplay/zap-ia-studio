---
name: acolher-sem-adivinhar-emocoes
description: O contato descreve dificuldade ou experiência ruim.
---

# H06 — Acolher sem adivinhar emoções

## Objetivo
Reconhecer o relato sem diagnosticar sentimentos.

## Gatilho observável
O contato descreve dificuldade ou experiência ruim. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Retomar o acontecimento que ele relatou.
2. Não intensificar o problema.
3. Só fazer pergunta se houver abertura para continuar.

## O que evitar
Não inventar frustração, medo, sofrimento ou culpa da equipe.

## Situação de estudo
O contato disse que um anúncio anterior trouxe poucos contatos.

**Não usar:** Imagino a angústia que você sente vendo seu negócio afundar.

**Melhor:** Você contou que quase ninguém chamou naquela campanha. Sem olhar o que foi feito, não dá para apontar a causa.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G04, G05. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
