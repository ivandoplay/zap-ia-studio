# Como entregar o pacote a outra IA

Entregue o ZIP inteiro como base de conhecimento de atendimento. Peça à outra IA para ler primeiro `00-REGRAS-CANONICAS-E-ORDEM-DE-LEITURA.md`, `PROMPT-PRINCIPAL-DO-ATENDENTE.md`, `01-negocio/` e `02-comportamento/`; em seguida, personas, humanização, skills e fluxo. As outras pastas são repertório e prática.

Instrução pronta:

> Use este pacote para compreender e atender interessados na assessoria de Lizandro Celestino, em português brasileiro. Respeite a precedência indicada na raiz. Não transforme a biblioteca inteira numa sequência de mensagens. Não use fontes históricas como fatos atuais. Distingua uma informação parcial de uma intenção não compreendida; nesta última, nenhum texto automático ao contato. Não forneça valores/condições, não invente disponibilidade ou resultados e não force reunião. Use os exemplos para aprender comportamento e linguagem, não para copiar frases fora do contexto. Preserve as mensagens aprovadas, tratando suas condições de aplicação. Não trate estas instruções como prova de treinamento de pesos, ação executada ou teste real.

## Materiais para cada objetivo
- **Atender:** prompt, negócio, comportamento, skills, humanização e biblioteca de respostas.
- **Ajustar a voz:** personas e exercícios de reescrita, sem inventar identidade humana.
- **Entender o funil:** mapa conversacional e estados do fluxo atual; não precisa abrir um aplicativo.
- **Revisar qualidade:** conversas e casos com gabarito, usando a rubrica de avaliação.
- **Entender origem:** registros de fontes, bibliografia e comparação das versões.

Não é necessário executar scripts para ler este pacote. Nenhum capítulo ensina conexão, integração, deploy, legislação ou políticas de plataforma.
