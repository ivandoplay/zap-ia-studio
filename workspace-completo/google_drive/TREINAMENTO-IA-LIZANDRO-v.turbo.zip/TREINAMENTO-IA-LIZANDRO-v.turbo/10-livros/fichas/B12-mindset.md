# B12 — Mindset

**Autor(es):** Carol S. Dweck.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1EODRxFBA970ck-mseLQhwtFdlNCc0NDU/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Uma orientação para aprendizagem valoriza revisão e desenvolvimento de capacidades em vez de rótulos fixos de competência.

## Aplicação ao atendimento
Tratar um resultado anterior como informação para avaliar, não como prova de incapacidade da loja ou da pessoa.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Anúncio nunca funciona para mim.

**Resposta ilustrativa:** Você já teve uma experiência que não funcionou como esperava. Sem analisar o que foi feito, não dá para concluir a causa.

## O que não transferir
Rotular o contato de mente fechada ou prometer que atitude positiva resolverá vendas.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Reescrever uma resposta que culpa o lojista pela experiência anterior.

### Gabarito de comportamento
A resposta não culpa, não faz diagnóstico e só investiga se houver abertura.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S12; H06, H10. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
