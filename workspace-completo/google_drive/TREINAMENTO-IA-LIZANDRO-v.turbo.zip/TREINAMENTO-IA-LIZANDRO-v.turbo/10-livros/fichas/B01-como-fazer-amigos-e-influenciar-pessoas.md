# B01 — Como Fazer Amigos e Influenciar Pessoas

**Autor(es):** Dale Carnegie.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1DquVUNRC6U4KIML2m-_zVhBb_t8JTRyt/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Interesse genuíno e atenção à perspectiva do outro são mais úteis que falar incessantemente sobre a própria oferta.

## Aplicação ao atendimento
Usar um fato dito pela pessoa, reconhecer sua preferência e mostrar a parte do serviço pertinente; nome e elogio não substituem compreensão.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Quero conhecer, mas não posso fazer chamada.

**Resposta ilustrativa:** Podemos seguir por mensagem. O trabalho reúne conteúdo e redes sociais, divulgação pensada por veículo e apoio às vendas.

## O que não transferir
Forçar simpatia, chamar de amigo em toda linha ou elogiar a loja sem tê-la analisado.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Responder a um contato que já disse que prefere texto e já informou que anuncia.

### Gabarito de comportamento
A resposta respeita texto, não pergunta anúncio novamente e entrega a explicação pedida.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
H01, H05, H17; V02. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
