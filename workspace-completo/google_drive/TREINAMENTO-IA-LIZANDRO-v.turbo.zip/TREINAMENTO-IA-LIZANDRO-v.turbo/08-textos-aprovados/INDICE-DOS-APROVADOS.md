# M01–M13 aprovadas — índice

O JSON original foi copiado em bytes, sem normalização. Cada Markdown abaixo contém a mesma redação protegida dentro de um bloco de texto. Se o texto não couber no contexto, não enviar; não reescrever a fonte.

- [M01 — literal](M01-APROVADO-LITERAL.md)
- [M02 — literal](M02-APROVADO-LITERAL.md)
- [M03 — literal](M03-APROVADO-LITERAL.md)
- [M04 — literal](M04-APROVADO-LITERAL.md)
- [M05 — literal](M05-APROVADO-LITERAL.md)
- [M06 — literal](M06-APROVADO-LITERAL.md)
- [M07 — literal](M07-APROVADO-LITERAL.md)
- [M08 — literal](M08-APROVADO-LITERAL.md)
- [M09 — literal](M09-APROVADO-LITERAL.md)
- [M10 — literal](M10-APROVADO-LITERAL.md)
- [M11 — literal](M11-APROVADO-LITERAL.md)
- [M12 — literal](M12-APROVADO-LITERAL.md)
- [M13 — literal](M13-APROVADO-LITERAL.md)

M09 continua pessoal; M10 não é uma cobrança de visualização; M11 exige origem confirmada; M12 é hipótese, não promessa. A IA não usa identidade humana contida em uma redação manual para fingir ser Lizandro.
