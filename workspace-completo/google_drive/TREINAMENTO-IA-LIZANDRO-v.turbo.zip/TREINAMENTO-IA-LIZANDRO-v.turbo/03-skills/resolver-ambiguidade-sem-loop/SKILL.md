---
name: resolver-ambiguidade-sem-loop
description: Separar intenção compreendida com um dado faltante de intenção não compreendida; evitar respostas inventadas e ciclos.
---

# S26 — Complementar um dado ou pausar em silêncio

## Objetivo
Não tratar toda resposta curta como um problema. Completar somente o que falta numa intenção entendida; se não compreendeu a intenção, deixar Lizandro revisar sem texto automático.

## Quando usar
Há resposta curta, referência incompleta, dúvida de canal, informação parcial ou conteúdo cuja intenção não é confiável.

## Antes de decidir
Recuperar a última pergunta real, o histórico e o resumo de áudio fornecido pelo operador. Não usar a pergunta de outra etapa nem presumir um antecedente ausente.

## Como conduzir
1. Identificar se a intenção atual está clara.
2. Se o contato aceitou e falta apenas uma informação específica, pedir esse dado uma única vez.
3. Se a intenção não foi compreendida, pausar em silêncio para Lizandro desde já.
4. Se o complemento não resolveu, não reformular a mesma pergunta indefinidamente: pausar em silêncio.
5. Se “os dois” é a resposta ao gargalo, aceitar as duas necessidades; não exigir uma prioridade para avançar.

## Exemplo com contexto suficiente
Pergunta anterior: “Você prefere ligação ou mensagem?” Resposta: “Sim.”

> Você prefere seguir por mensagem ou por ligação?

## Exemplo sem contexto suficiente
Mensagem: “É daquela outra de ontem, mas ao contrário.” Não existe referência no histórico.

**Não há texto automático.** Lizandro revisa. Isso é uma instrução de comportamento, não uma frase ao contato.

## Limites
Não usar um pedido genérico de esclarecimento como reação automática ao desconhecido. Não prometer que alguém atende em minutos. Se o assunto for preço ou pedido de pessoa, a intenção já é clara: seguir a passagem humana correspondente, sem nova qualificação.

## Qualidade
Dado parcial não vira informação inventada; “sim” não vira ligação por suposição; pausa não vira mensagem; nenhuma pergunta é repetida depois de fracassar.
