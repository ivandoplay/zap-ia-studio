---
name: personalizar-pelo-veiculo-com-disciplina
description: A pergunta pede o diferencial por veículo ou traz uma característica real.
---

# H21 — Personalizar pelo veículo com disciplina

## Objetivo
Relacionar mensagem e divulgação ao que está de fato disponível.

## Gatilho observável
A pergunta pede o diferencial por veículo ou traz uma característica real. Confirmar esse contexto antes de aplicar. Um rótulo de persona não substitui a leitura da mensagem.

## Procedimento
1. Usar só características confirmadas.
2. Explicar a personalização em termos de apresentação e estratégia.
3. Deixar desempenho e execução específica em aberto.

## O que evitar
Não inventar estoque, procura, margem, situação do carro ou comprador pronto.

## Situação de estudo
Pedido de diferencial sem dado específico de um carro.

**Não usar:** Esse modelo vende sozinho; tenho gente esperando.

**Melhor:** A estratégia pode mudar conforme o veículo e sua apresentação, em vez de usar a mesma abordagem para todo o estoque.

## Limite maior
Não aplicar após pedido de parar, recusa encerrada ou enquanto Lizandro já conduz. Se a intenção não foi compreendida, pausar em silêncio; não usar esta skill para fabricar assunto. Valores e condições continuam exclusivos de Lizandro.

## Critério de aprovação
A melhoria fica observável na comparação: atende à intenção, preserva fatos e não adiciona pressão, intimidade falsa ou uma ação que não ocorreu. A referência é condicional, não uma frase obrigatória.

## Procedência
Adaptação autoral para este negócio. Referências de apoio: G03, G04. Os G01–G07 estão documentados em `13-skills-github/`; essas fontes públicas foram consultadas nesta revisão e não foram identificadas como as antigas skills da R4.
