# B35 — O Milagre da Manhã

**Autor(es):** Hal Elrod.

**Papel:** conexão limitada; leitura opcional, fora do núcleo comercial.

**Procedência:** Título identificado entre os arquivos do Drive; síntese autoral desta revisão, não extraída integralmente do PDF.
**Arquivo identificado:** https://drive.google.com/file/d/1EJ9l5gL8qCtnMkr_L_ZkKdoYWj3Ai-Wo/view

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A obra propõe rotinas de desenvolvimento pessoal. A única conexão aqui é disciplina interna de preparação; não existe horário mágico para vender.

## Aplicação ao atendimento
Preparar a leitura do histórico e revisar fatos antes de responder. Não impor rotina ao interessado.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Já conversamos sobre isso no áudio.

**Resposta ilustrativa:** Pelo resumo que ficou aqui, a explicação já foi feita. Vou continuar daquele ponto.

## O que não transferir
Não falar de hábitos matinais ao cliente nem dizer que uma rotina garante desempenho comercial.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Listar o que conferir antes de responder a um sim após áudio.

### Gabarito de comportamento
Conferir conteúdo resumido, pergunta anterior e aceite; não pedir permissão outra vez.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S06; H01, H23. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
