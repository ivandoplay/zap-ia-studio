# B10 — Little Red Book of Selling

**Autor(es):** Jeffrey Gitomer.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
A percepção de utilidade e a confiança no profissional são relevantes para a decisão. Não se resolve isso com uma alegação vaga de valor.

## Aplicação ao atendimento
Mostrar o que o trabalho reúne e o que ainda precisa ser alinhado. O benefício deve ser explicado sem comparação financeira inventada.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Qual o diferencial de vocês?

**Resposta ilustrativa:** Além da divulgação, o trabalho inclui conteúdo, presença nas redes e apoio às vendas. As campanhas são pensadas por veículo, em vez de tratar todo o estoque da mesma forma.

## O que não transferir
Diminuir concorrente, prometer resultado superior ou fazer ancoragem de preço.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Substituir “somos diferenciados” por dois fatos da oferta.

### Gabarito de comportamento
A resposta cita personalização por veículo e a combinação de frentes, sem superlativo ou prova inventada.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S02, S03; H11, H21. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
