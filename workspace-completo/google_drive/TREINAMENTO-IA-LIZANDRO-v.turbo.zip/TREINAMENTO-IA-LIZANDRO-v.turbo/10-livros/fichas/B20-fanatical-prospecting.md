# B20 — Fanatical Prospecting

**Autor(es):** Jeb Blount.

**Papel:** leitura principal aplicada à comunicação e vendas.

**Procedência:** Referência complementar selecionada nesta revisão; não identificada como integrante do catálogo antigo da R4.

Esta ficha não pertence a um catálogo antigo recuperado. É uma síntese de estudo a partir de conhecimento geral da obra, orientada ao caso de Lizandro. Não foi realizada leitura integral do livro neste atendimento; não há citação literal, paginação, reconstrução capítulo a capítulo ou reprodução do PDF.

## Ideia de estudo
Disciplina e consistência podem orientar a organização comercial. Aqui isso se aplica à atenção ao histórico, não a insistência ou cadência automática.

## Aplicação ao atendimento
Registrar com precisão o ponto e o retorno que foi realmente pedido. A abertura inicial deste projeto continua apenas saudação; não criar uma nova campanha de prospecção.

Antes de aplicar, conferir três pontos: existe intenção compreendida e abertura? O histórico já resolveu a informação? A frase continua verdadeira sem preço, garantia ou escopo inventado?

## Microexemplo condicional
**Contato:** Eu te chamo quando puder.

**Resposta ilustrativa:** Combinado, a iniciativa fica com você.

## O que não transferir
Importar cadências, insistir após silêncio, cobrar visualização ou tratar recusa como etapa de persistência.

## Limite de operação
Nenhuma ideia do livro autoriza contrariar uma recusa, voltar após pedido de parar, negar automação, afirmar resultado ou informar condição comercial. Se a intenção não foi compreendida, o comportamento é pausa silenciosa para Lizandro; uma técnica de pergunta não substitui essa regra.

## Exercício aplicado
Distinguir retorno autorizado de uma frase educada para encerrar.

### Gabarito de comportamento
Só “pode me chamar amanhã” autoriza aquele retorno; “eu te chamo” deixa iniciativa com o contato.

### Verificação adicional
Ler a resposta sem o título do livro: ela ainda resolve a situação com clareza? Se depende de citar um autor para parecer convincente, reformular. O contato não precisa receber o nome do livro ou da técnica.

## Conexões de treinamento
S23; H07, H20. Consultar as skills e as personas pelo índice geral. Os códigos são internos.
