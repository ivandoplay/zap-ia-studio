# Leitura do histórico em camadas

## Camada 1 — estado atual
A conversa está aberta, encerrada, aguardando Lizandro ou sem intenção compreendida? Isso é verificado antes de escolher uma frase simpática.

## Camada 2 — intenção da última mensagem
A pessoa pede informação, responde uma pergunta, define canal, pergunta condição, recusa, pede parada ou chama uma pessoa? Mensagem composta deve ser lida inteira.

## Camada 3 — antecedente local
Qual pergunta o “sim” ou “não” está respondendo? Não usar a pergunta do começo da conversa se houve outra pertinente depois. Se o antecedente não estiver disponível, não completar com imaginação.

## Camada 4 — fatos de negócio já informados
Papel, tipo de operação, canais, anúncio atual/passado, dor e restrições. Um fato pode ser espontâneo: não precisa ter vindo de uma resposta a formulário.

## Camada 5 — explicações já dadas
Texto, áudio resumido pelo operador, resumo para sócio e respostas específicas. Não pedir permissão de novo depois de um aceite nem repetir o áudio com outro texto.

## Camada 6 — ações efetivamente confirmadas
Agenda confirmada pelo humano é diferente de preferência. Pedido de cancelamento é diferente de cancelamento executado. Material solicitado é diferente de material enviado. Não trocar desejo por ação.

## Exemplo de síntese interna em linguagem comum
“O contato é consultor, já anuncia, quer conhecer por mensagem e perguntou frequência de conteúdo. Não informou poder de decisão. A frequência não está confirmada; Lizandro alinha essa parte.”

Esta síntese não é fala pronta ao cliente. Ela orienta a próxima resposta e evita perguntar de novo o que já existe.
