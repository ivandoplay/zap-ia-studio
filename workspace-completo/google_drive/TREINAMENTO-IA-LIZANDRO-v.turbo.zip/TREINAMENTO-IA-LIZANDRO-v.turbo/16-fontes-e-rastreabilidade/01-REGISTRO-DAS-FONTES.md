# Registro das fontes

## Materiais do próprio projeto
- Textos M01–M13 sincronizados, aprovados manualmente: preservados na pasta 08 e conferidos em bytes contra a V2.
- V1: biblioteca de 116 respostas, 45 situações e 24 conversas; conteúdo útil consolidado pela V2, sem capítulos técnicos/jurídicos.
- V2 entregue: 32 skills autorais, 116 respostas, 45 situações, 24 conversas, 112 exercícios e 26 pares de contraste; incorporada e revisada nesta v.turbo.
- TXT auditado R2: referência histórica anterior; não usado para sobrescrever um aprovado nem para declarar o backup atualizado.

## Backups recuperados
1. `fluxo.zip`, Drive `1JTIxo1U5D_xVOrAsxZB_emGX9kO9vjlo`: contém R4 de 22/10/2026 e um guia. O LZB é um arquivo compactado interno, não apenas um TXT renomeado.
2. `FUNIL-ALAVANCAGEM-DE-VENDAS-V4 (1).lzb`, Drive `1qq73ROI0ZbQbGF6wNHHsSkTVPEZmycVQ`: criação interna em 23/10/2026, referência selecionada. Textos e estrutura lidos; dois fluxos em rascunho.
3. `leadzy-local (1).zip`, Drive `1Qz6glo6UcjxKpTZRrySjcd17_sPu5grp`: 5.511.673 bytes e 61 entradas; conteúdo da extensão e recursos. Não contém Markdown/TXT de livros ou treinamento. Não foi redistribuído no ZIP de treinamento.

## Bibliografia
A descrição do R4 cita `LIVROS-30-APLICADOS-FUNIL-R4.md` e PLAYBOOK, mas não inclui os documentos. Foram identificados 15 PDFs de livros; isso não confirma a lista original. As 39 fichas presentes são sínteses autorais desta revisão, com cada origem marcada. PDFs completos não foram copiados.

## Skills públicas
Sete arquivos públicos, em três repositórios, consultados por URL e commit fixado nesta revisão. Não foram identificados como as skills antigas. As aplicações próprias em português e os filtros de uso constam na pasta 13.

## Campos de procedência
- **Protegido/aprovado:** preservação literal, com condição de uso.
- **Recuperado:** conteúdo efetivamente lido nos arquivos disponíveis.
- **Complementar:** novo repertório desta revisão, não fonte antiga reconstruída.
- **Autoral:** organização, síntese, exemplo ou exercício elaborado para o caso.
- **Não recuperado:** referência citada sem conteúdo disponível; não preenchida por adivinhação.
