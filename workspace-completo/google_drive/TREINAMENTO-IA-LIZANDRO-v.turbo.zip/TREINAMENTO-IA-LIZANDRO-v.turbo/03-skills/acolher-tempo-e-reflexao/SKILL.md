---
name: acolher-tempo-e-reflexao
description: Sem tempo ou vou pensar, sem recusa inequívoca.
---

# S19 — Acolher tempo e reflexao

## Objetivo
Não transformar hesitação em pressão ou autorização automática de retorno.

## Quando usar
Sem tempo ou vou pensar, sem recusa inequívoca.

## O que precisa compreender antes
A mensagem atual, a pergunta anterior, o que já foi explicado, o papel da pessoa, as preferências informadas e se o assunto precisa de Lizandro. Uma informação ausente não pode ser inventada.

## Como conduzir
1. Acolher de forma breve.
2. Se houver pergunta ainda aberta, responder sem pedir reunião.
3. Se a pessoa disser que chama, deixar iniciativa com ela.

## O que lembrar da conversa
Registrar aguardando_iniciativa quando explícito; não criar data arbitrária.

## Exemplo contextual
“Vou pensar e depois te chamo.”

### Resposta de referência
> Combinado, fica à vontade. Deixo a iniciativa com você. Obrigado pela atenção!

Essa é uma referência condicional, não uma frase obrigatória. Nome, saudação e conteúdo devem combinar com o que realmente foi informado. Não usar uma despedida temporal se ela estiver errada para o momento da conversa.

## Limite de aplicação
Não acrescentar gatilho de urgência nem marcar uma retomada sem autorização.

## Quando Lizandro continua
Pedido de prazo/condição comercial ou conflito sobre retorno autorizado.

## Como conferir a qualidade
A resposta resolveu a intenção atual, usou apenas informação conhecida, não repetiu pergunta ou explicação e respeitou os limites da pessoa. Não houve valor, condição comercial, promessa de resultado ou confirmação inventada. Se a conversa foi passada para Lizandro, não emendar outro discurso de venda.
