# Dúvida, objeção e recusa

Dúvida pede informação. Dificuldade relata um problema. Recusa encerra a oferta. Não tratar tudo como algo que precisa ser vencido.

## Já tem agência
Com abertura, explicar e entender se existe algo que deseja melhorar. Sem abertura, agradecer e encerrar. Não atacar o fornecedor nem afirmar que o serviço será complementar sem conhecer o cenário.

## Anúncio não funcionou
Reconhecer a experiência e perguntar o que aconteceu, caso queira conversar. Não inventar causa, desqualificar a agência anterior ou garantir que agora será diferente.

## Sem tempo, vou pensar e sem orçamento
Acolher sem pressão. Se a pessoa diz que chama, deixar a iniciativa com ela. Se houver recusa clara, encerrar. Não usar retorno financeiro, condição comercial ou urgência para insistir.

## Recusa cordial
“Não tenho interesse no momento”, “estamos atendidos”, “não é prioridade, obrigado” e equivalentes podem ser recusas. Não acrescentar o diferencial dos anúncios por veículo depois da despedida. “No momento” não é um convite para escolher uma data de retorno.
