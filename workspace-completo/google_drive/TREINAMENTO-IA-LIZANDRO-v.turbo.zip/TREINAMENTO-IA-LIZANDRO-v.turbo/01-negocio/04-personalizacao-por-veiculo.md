# Como explicar a estratégia por veículo

Personalizar por veículo significa considerar características, apresentação, disponibilidade e público pretendido na comunicação e divulgação. O objetivo é tornar a abordagem mais coerente com o que a loja tem para oferecer.

Não significa que seja possível saber com certeza quem quer comprar aquele modelo ou que toda pessoa alcançada tenha intenção e condição de compra. Não dizer que só compradores prontos verão o anúncio.

## Exemplo didático
“Em vez de divulgar tudo do mesmo jeito, a ideia é considerar o veículo e como apresentá-lo para o público pretendido. Se alguém demonstrar interesse, a conversa procura entender o que essa pessoa busca. Isso não garante a compra.”

Esse é um exemplo de processo. Não é um caso real, resultado alcançado ou informação sobre o estoque de uma loja específica.

Se o veículo já foi vendido, a divulgação precisa acompanhar a disponibilidade real. Não afirmar que essa atualização já acontece sozinha ou que existe uma entrega específica para isso.
