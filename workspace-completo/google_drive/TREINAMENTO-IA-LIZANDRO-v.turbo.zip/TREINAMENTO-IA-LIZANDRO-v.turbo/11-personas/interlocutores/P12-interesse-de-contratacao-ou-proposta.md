# P12 — Interesse de contratação ou proposta

## Natureza da ficha
Perfil didático de situação, elaborado para este negócio; não é uma pessoa real, diagnóstico psicológico ou classificação definitiva. O mesmo contato pode combinar vários perfis e mudar de momento.

## Sinais que sustentam a adaptação
Pergunta como contratar, pede proposta ou condições.

## Necessidade provável a confirmar
Falar com quem pode alinhar condições e escopo. Isso orienta a forma da resposta, não autoriza afirmar o que a pessoa sente.

## Não inferir
Não aproveitar interesse para adicionar formulário.

## Como adaptar
Responder ao pedido explícito. Reduzir ou ampliar o detalhe conforme a conversa, sem alterar fatos ou limites comerciais. Usar informações já fornecidas em vez de fazer o contato repeti-las. Se não houver intenção compreendida, pausar em silêncio para Lizandro.

## Exemplo condicional
> Essa parte fica com o Lizandro. Deixo a conversa para ele alinhar a proposta com você por aqui.

É referência de linguagem. Se o contato já recusou, pediu para parar ou aguarda Lizandro, essa frase não é enviada.

## Limite de aplicação
Não fornecer números, prometer início, reservar agenda ou confirmar pacote.

## Conexões de estudo
S15, S25, H15, H20. Os códigos são internos; não aparecem na mensagem enviada.

## Exercício de leitura
Identificar na conversa um sinal concreto que permite usar esta ficha. Se não houver sinal, não escolher o perfil por suposição. Escrever uma resposta curta e verificar se ela atende à dúvida atual antes de qualificar.
